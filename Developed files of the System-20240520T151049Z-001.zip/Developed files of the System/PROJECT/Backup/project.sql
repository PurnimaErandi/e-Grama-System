-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2021 at 01:06 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `aid_type`
--

CREATE TABLE `aid_type` (
  `aid_type_id` int(11) NOT NULL,
  `aid_type_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aid_type`
--

INSERT INTO `aid_type` (`aid_type_id`, `aid_type_name`) VALUES
(1, 'Samurdhi'),
(2, 'Covid-19 Special'),
(3, 'Welfare');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_request`
--

CREATE TABLE `certificate_request` (
  `request_id` int(11) NOT NULL,
  `reason_for_request` varchar(500) DEFAULT NULL,
  `request_date` datetime DEFAULT NULL,
  `request_status` varchar(32) DEFAULT NULL,
  `certificate_name` varchar(50) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `character_certificate`
--

CREATE TABLE `character_certificate` (
  `character_certificate_id` int(11) NOT NULL,
  `requested_person_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `divi_sec_div` varchar(100) DEFAULT NULL,
  `gn_div_name` varchar(150) DEFAULT NULL,
  `applicant_known_by_gn` int(11) DEFAULT NULL,
  `if_so_since_when` date DEFAULT NULL,
  `applicant_name` varchar(150) DEFAULT NULL,
  `applicant_address` varchar(225) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `civil_status` varchar(32) DEFAULT NULL,
  `sri_lankan_or_not` varchar(50) DEFAULT NULL,
  `religion` varchar(45) DEFAULT NULL,
  `present_ocupation` varchar(50) DEFAULT NULL,
  `period_of_residence` varchar(45) DEFAULT NULL,
  `nic` varchar(12) DEFAULT NULL,
  `no_of_electotial_reg` varchar(45) DEFAULT NULL,
  `name_of_father` varchar(225) DEFAULT NULL,
  `purpose` varchar(500) DEFAULT NULL,
  `period_of_residence_in_gn` varchar(45) DEFAULT NULL,
  `nature_of_other_evidence` varchar(100) DEFAULT NULL,
  `applicant_has_been_convicted` varchar(100) DEFAULT NULL,
  `interest_in_public_activities` varchar(225) DEFAULT NULL,
  `hisorher_character` varchar(500) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `reg_no` varchar(45) DEFAULT NULL,
  `issuer` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `contact_us_id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `subject` varchar(225) DEFAULT NULL,
  `message` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `death_certificate`
--

CREATE TABLE `death_certificate` (
  `death_certificate_id` int(11) NOT NULL,
  `requested_person_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `gn_division` varchar(128) DEFAULT NULL,
  `reg_division` varchar(150) DEFAULT NULL,
  `death_date` date DEFAULT NULL,
  `death_place` varchar(250) DEFAULT NULL,
  `person_nic` varchar(12) DEFAULT NULL,
  `full_name` varchar(500) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `nationality` varchar(150) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `profession` varchar(150) DEFAULT NULL,
  `cause` varchar(500) DEFAULT NULL,
  `person_bound_to_give_info` varchar(150) DEFAULT NULL,
  `address_of_bounded_person` varchar(500) DEFAULT NULL,
  `regis_no` varchar(45) DEFAULT NULL,
  `issuer` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `disaster_management`
--

CREATE TABLE `disaster_management` (
  `disaster_management_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `remark` varchar(1024) DEFAULT NULL,
  `loc_latitude` double DEFAULT NULL,
  `loc_longitude` double DEFAULT NULL,
  `disaster_type` varchar(45) DEFAULT NULL,
  `damages` varchar(1024) DEFAULT NULL,
  `other_details` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(225) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `location` varchar(225) DEFAULT NULL,
  `is_public` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `feedback_type` varchar(45) DEFAULT NULL,
  `feedback` varchar(1024) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

CREATE TABLE `house` (
  `house_no` int(11) NOT NULL,
  `house_status` varchar(45) DEFAULT NULL,
  `house_type` varchar(45) DEFAULT NULL,
  `walls` varchar(45) DEFAULT NULL,
  `floor` varchar(45) DEFAULT NULL,
  `roofs` varchar(45) DEFAULT NULL,
  `house_built_date` date DEFAULT NULL,
  `other_details` varchar(250) DEFAULT NULL,
  `radio` tinyint(4) DEFAULT NULL,
  `television` tinyint(4) DEFAULT NULL,
  `landline_phones` tinyint(4) DEFAULT NULL,
  `mobile_phones` tinyint(4) DEFAULT NULL,
  `desktop_computer` tinyint(4) DEFAULT NULL,
  `laptop` tinyint(4) DEFAULT NULL,
  `internet_connections` tinyint(4) DEFAULT NULL,
  `washing_machine` tinyint(4) DEFAULT NULL,
  `refrigerator` tinyint(4) DEFAULT NULL,
  `air_conditioner` tinyint(4) DEFAULT NULL,
  `gas_cooker` tinyint(4) DEFAULT NULL,
  `rice_cooker` tinyint(4) DEFAULT NULL,
  `property_idproperty` int(11) DEFAULT NULL,
  `house_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `parent_child_mapping`
--

CREATE TABLE `parent_child_mapping` (
  `mapping_id` int(11) NOT NULL,
  `child_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `child_regNo` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `idperson` int(11) NOT NULL,
  `nameof_person` varchar(200) DEFAULT NULL,
  `house_no` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `dateof_birth` date DEFAULT NULL,
  `birth_place` varchar(45) DEFAULT NULL,
  `telephone_no` int(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `is_alive` tinyint(4) DEFAULT NULL,
  `religions` varchar(45) DEFAULT NULL,
  `nationality` varchar(45) DEFAULT NULL,
  `nic` varchar(12) DEFAULT NULL,
  `education` varchar(45) DEFAULT NULL,
  `occupation` varchar(45) DEFAULT NULL,
  `phyMental_health` varchar(128) DEFAULT NULL,
  `vehicles` varchar(128) DEFAULT NULL,
  `it_knowledge` varchar(128) DEFAULT NULL,
  `lang_knowledge` varchar(128) DEFAULT NULL,
  `other_skills` varchar(100) DEFAULT NULL,
  `is_child` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`idperson`, `nameof_person`, `house_no`, `status`, `gender`, `dateof_birth`, `birth_place`, `telephone_no`, `email`, `is_alive`, `religions`, `nationality`, `nic`, `education`, `occupation`, `phyMental_health`, `vehicles`, `it_knowledge`, `lang_knowledge`, `other_skills`, `is_child`) VALUES
(1, 'Zianji Luminans', 'No 489', 'Single', 'Female', '1990-06-20', 'Ragama', 764950457, 'zianji@gmail.com', 1, 'Catholic', 'Sinhalese', '906221258v', '1-5 Primary', 'Private Sector', '[\"Normal\"]', '[\"Car\"]', '[\"Microsoft Office\",\"Programming Languages\"]', '[\"Sinhala\",\"English\"]', 'Sports', 0);

-- --------------------------------------------------------

--
-- Table structure for table `privilage`
--

CREATE TABLE `privilage` (
  `privilage_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `prv_func_id` int(11) DEFAULT NULL,
  `prv_subfunc_id` int(11) DEFAULT NULL,
  `create` tinyint(4) DEFAULT NULL,
  `read` tinyint(4) DEFAULT NULL,
  `modify` tinyint(4) DEFAULT NULL,
  `delete` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `privilage`
--

INSERT INTO `privilage` (`privilage_id`, `role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) VALUES
(46, 1, 1, 1, 1, 1, 1, 1),
(47, 1, 1, 2, 1, 1, 1, 1),
(48, 1, 1, 3, 1, 1, 1, 1),
(49, 1, 1, 4, 1, 1, 1, 1),
(50, 1, 2, 5, 1, 1, 1, 1),
(51, 1, 2, 6, 1, 1, 1, 1),
(52, 1, 2, 7, 1, 1, 1, 1),
(53, 1, 3, 8, 1, 1, 1, 1),
(54, 1, 3, 9, 1, 1, 1, 1),
(55, 1, 3, 10, 1, 1, 1, 1),
(56, 1, 4, 11, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `privilage_function`
--

CREATE TABLE `privilage_function` (
  `privilage_function_id` int(11) NOT NULL,
  `privilage_function_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `privilage_function`
--

INSERT INTO `privilage_function` (`privilage_function_id`, `privilage_function_name`) VALUES
(1, 'systemData'),
(2, 'certificates'),
(3, 'userManagement'),
(4, 'disasterRecoveryNode');

-- --------------------------------------------------------

--
-- Table structure for table `privilage_subfunction`
--

CREATE TABLE `privilage_subfunction` (
  `privilage_subfunction_id` int(11) NOT NULL,
  `privilage_subfunction_name` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `privilage_subfunction`
--

INSERT INTO `privilage_subfunction` (`privilage_subfunction_id`, `privilage_subfunction_name`) VALUES
(1, 'personalDetails'),
(2, 'propertyManagement'),
(3, 'workPlan'),
(4, 'aidInfo'),
(5, 'charCert'),
(6, 'deathCert'),
(7, 'residCert'),
(8, 'users'),
(9, 'userRoles'),
(10, 'myProfile'),
(11, 'disasterRecovery');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `idproperty` int(11) NOT NULL,
  `grama_niladhari_office` varchar(45) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `purchase_of_land` varchar(45) DEFAULT NULL,
  `house_latitude` float DEFAULT NULL,
  `house_longitude` float DEFAULT NULL,
  `water` tinyint(4) DEFAULT NULL,
  `lights` tinyint(4) DEFAULT NULL,
  `toilets` tinyint(4) DEFAULT NULL,
  `garbage` tinyint(4) DEFAULT NULL,
  `major_crops` varchar(45) DEFAULT NULL,
  `villagestreet_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `public_assistance`
--

CREATE TABLE `public_assistance` (
  `idpublic_assistance` int(11) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `donation` varchar(100) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `other_details` varchar(500) DEFAULT NULL,
  `person_id` int(11) NOT NULL,
  `account_no` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `residence_certificate`
--

CREATE TABLE `residence_certificate` (
  `residence_certificate_id` int(11) NOT NULL,
  `requested_person_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `div_name` varchar(100) DEFAULT NULL,
  `person_name` varchar(225) DEFAULT NULL,
  `permanent_residence` varchar(500) DEFAULT NULL,
  `nic` varchar(12) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `residing_gnd` varchar(255) DEFAULT NULL,
  `purpose` varchar(500) DEFAULT NULL,
  `applicant_name` varchar(255) DEFAULT NULL,
  `gn_division` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `role_name`) VALUES
(1, 'Administrator'),
(2, 'Super Admin'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `special_aids`
--

CREATE TABLE `special_aids` (
  `special_aids_id` int(11) NOT NULL,
  `house_no` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `aid_type_id` int(11) DEFAULT NULL,
  `account_no` varchar(50) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `place` varchar(128) DEFAULT NULL,
  `other` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `iduser` int(11) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_uname` varchar(45) NOT NULL,
  `user_password` varchar(500) NOT NULL,
  `user_email` varchar(45) NOT NULL,
  `user_imgPath` varchar(500) DEFAULT NULL,
  `user_nic` varchar(15) DEFAULT NULL,
  `user_role_iduser_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `user_fullname`, `user_uname`, `user_password`, `user_email`, `user_imgPath`, `user_nic`, `user_role_iduser_role`) VALUES
(1, 'Admin', 'admin', '$2y$10$8qcnL4RH8Ij6FTpvDw2j4ejJs3oTUeKNFPFAD.LCMLQSI7u4bNLF2', 'egramasystem@gmail.com', './img/user2.png', 'nic', 2),
(5, 'Zianji Luminans', 'zianji', '$2y$10$s533te08K6MsREpsf1EC9.onxO1Po0VTPVg9WevnQQpRXG2OT3epm', 'zianji@gmail.com', NULL, '906221258v', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_request`
--

CREATE TABLE `user_request` (
  `request_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `nic` varchar(12) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(10) DEFAULT NULL,
  `request_status` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_request`
--

INSERT INTO `user_request` (`request_id`, `name`, `email`, `nic`, `address`, `contact_no`, `request_status`) VALUES
(1, 'Zianji Luminans', 'zianji@gmail.com', '906221258v', 'No 489,\r\nNarangodapaluwa, Batuwatta.', '0764950457', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `vote_removal_mapping`
--

CREATE TABLE `vote_removal_mapping` (
  `map_id` int(11) NOT NULL,
  `person_id` int(11) DEFAULT NULL,
  `remark` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `work_history`
--

CREATE TABLE `work_history` (
  `idwork_history` int(11) NOT NULL,
  `work_history_province` varchar(45) DEFAULT NULL,
  `work_history_district` varchar(45) DEFAULT NULL,
  `work_history_divisional_secretariat` varchar(45) DEFAULT NULL,
  `gn_name` varchar(128) DEFAULT NULL,
  `work_history_address` varchar(45) DEFAULT NULL,
  `work_history_telephone_no` int(11) DEFAULT NULL,
  `work_history_start_date_of_duty` date DEFAULT NULL,
  `other_details` varchar(500) DEFAULT NULL,
  `user_iduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `work_plan`
--

CREATE TABLE `work_plan` (
  `idwork_plan` int(11) NOT NULL,
  `work_plan_date` date DEFAULT NULL,
  `work_plan_time` time DEFAULT NULL,
  `work_plan_description` varchar(1024) DEFAULT NULL,
  `work_plan_type` varchar(45) DEFAULT NULL,
  `user_iduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aid_type`
--
ALTER TABLE `aid_type`
  ADD PRIMARY KEY (`aid_type_id`);

--
-- Indexes for table `certificate_request`
--
ALTER TABLE `certificate_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `character_certificate`
--
ALTER TABLE `character_certificate`
  ADD PRIMARY KEY (`character_certificate_id`),
  ADD KEY `fk_char_cert_person_id_idx` (`requested_person_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`contact_us_id`);

--
-- Indexes for table `death_certificate`
--
ALTER TABLE `death_certificate`
  ADD PRIMARY KEY (`death_certificate_id`),
  ADD KEY `fk_death_cert_person_id_idx` (`requested_person_id`);

--
-- Indexes for table `disaster_management`
--
ALTER TABLE `disaster_management`
  ADD PRIMARY KEY (`disaster_management_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `house`
--
ALTER TABLE `house`
  ADD PRIMARY KEY (`house_no`),
  ADD KEY `fk_house_property1_idx` (`property_idproperty`);

--
-- Indexes for table `parent_child_mapping`
--
ALTER TABLE `parent_child_mapping`
  ADD PRIMARY KEY (`mapping_id`),
  ADD KEY `fk_child_idx` (`child_id`),
  ADD KEY `fk_parent_idx` (`parent_id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`idperson`);

--
-- Indexes for table `privilage`
--
ALTER TABLE `privilage`
  ADD PRIMARY KEY (`privilage_id`),
  ADD KEY `fk_role_idx` (`role_id`),
  ADD KEY `fk_func_idx` (`prv_func_id`),
  ADD KEY `fk_subfunc_idx` (`prv_subfunc_id`);

--
-- Indexes for table `privilage_function`
--
ALTER TABLE `privilage_function`
  ADD PRIMARY KEY (`privilage_function_id`);

--
-- Indexes for table `privilage_subfunction`
--
ALTER TABLE `privilage_subfunction`
  ADD PRIMARY KEY (`privilage_subfunction_id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`idproperty`);

--
-- Indexes for table `public_assistance`
--
ALTER TABLE `public_assistance`
  ADD PRIMARY KEY (`idpublic_assistance`),
  ADD KEY `fk_public_assistance_person1_idx` (`person_id`);

--
-- Indexes for table `residence_certificate`
--
ALTER TABLE `residence_certificate`
  ADD PRIMARY KEY (`residence_certificate_id`),
  ADD KEY `fk_resi_cert_person_id_idx` (`requested_person_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `user_role_name_UNIQUE` (`role_name`);

--
-- Indexes for table `special_aids`
--
ALTER TABLE `special_aids`
  ADD PRIMARY KEY (`special_aids_id`),
  ADD KEY `fk_special_aids_type_idx` (`aid_type_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`),
  ADD UNIQUE KEY `user_email_UNIQUE` (`user_email`),
  ADD KEY `fk_user_user_role_idx` (`user_role_iduser_role`);

--
-- Indexes for table `user_request`
--
ALTER TABLE `user_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `vote_removal_mapping`
--
ALTER TABLE `vote_removal_mapping`
  ADD PRIMARY KEY (`map_id`),
  ADD KEY `fk_vote_person_idx` (`person_id`);

--
-- Indexes for table `work_history`
--
ALTER TABLE `work_history`
  ADD PRIMARY KEY (`idwork_history`),
  ADD KEY `fk_work_history_user1_idx` (`user_iduser`);

--
-- Indexes for table `work_plan`
--
ALTER TABLE `work_plan`
  ADD PRIMARY KEY (`idwork_plan`),
  ADD KEY `fk_work_plan_user1_idx` (`user_iduser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aid_type`
--
ALTER TABLE `aid_type`
  MODIFY `aid_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `certificate_request`
--
ALTER TABLE `certificate_request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `character_certificate`
--
ALTER TABLE `character_certificate`
  MODIFY `character_certificate_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `contact_us_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `death_certificate`
--
ALTER TABLE `death_certificate`
  MODIFY `death_certificate_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disaster_management`
--
ALTER TABLE `disaster_management`
  MODIFY `disaster_management_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `house`
--
ALTER TABLE `house`
  MODIFY `house_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parent_child_mapping`
--
ALTER TABLE `parent_child_mapping`
  MODIFY `mapping_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `idperson` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `privilage`
--
ALTER TABLE `privilage`
  MODIFY `privilage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `privilage_function`
--
ALTER TABLE `privilage_function`
  MODIFY `privilage_function_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `privilage_subfunction`
--
ALTER TABLE `privilage_subfunction`
  MODIFY `privilage_subfunction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `idproperty` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `public_assistance`
--
ALTER TABLE `public_assistance`
  MODIFY `idpublic_assistance` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `residence_certificate`
--
ALTER TABLE `residence_certificate`
  MODIFY `residence_certificate_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `special_aids`
--
ALTER TABLE `special_aids`
  MODIFY `special_aids_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_request`
--
ALTER TABLE `user_request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vote_removal_mapping`
--
ALTER TABLE `vote_removal_mapping`
  MODIFY `map_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `work_history`
--
ALTER TABLE `work_history`
  MODIFY `idwork_history` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `work_plan`
--
ALTER TABLE `work_plan`
  MODIFY `idwork_plan` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `character_certificate`
--
ALTER TABLE `character_certificate`
  ADD CONSTRAINT `fk_char_cert_person_id` FOREIGN KEY (`requested_person_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `death_certificate`
--
ALTER TABLE `death_certificate`
  ADD CONSTRAINT `fk_death_cert_person_id` FOREIGN KEY (`requested_person_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `house`
--
ALTER TABLE `house`
  ADD CONSTRAINT `fk_house_property1` FOREIGN KEY (`property_idproperty`) REFERENCES `property` (`idproperty`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `parent_child_mapping`
--
ALTER TABLE `parent_child_mapping`
  ADD CONSTRAINT `fk_child` FOREIGN KEY (`child_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_parent` FOREIGN KEY (`parent_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `privilage`
--
ALTER TABLE `privilage`
  ADD CONSTRAINT `fk_func` FOREIGN KEY (`prv_func_id`) REFERENCES `privilage_function` (`privilage_function_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_subfunc` FOREIGN KEY (`prv_subfunc_id`) REFERENCES `privilage_subfunction` (`privilage_subfunction_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `public_assistance`
--
ALTER TABLE `public_assistance`
  ADD CONSTRAINT `fk_public_assistance_person1` FOREIGN KEY (`person_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `residence_certificate`
--
ALTER TABLE `residence_certificate`
  ADD CONSTRAINT `fk_resi_cert_person_id` FOREIGN KEY (`requested_person_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `special_aids`
--
ALTER TABLE `special_aids`
  ADD CONSTRAINT `fk_special_aids_aid_type` FOREIGN KEY (`aid_type_id`) REFERENCES `aid_type` (`aid_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_user_role` FOREIGN KEY (`user_role_iduser_role`) REFERENCES `role` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `vote_removal_mapping`
--
ALTER TABLE `vote_removal_mapping`
  ADD CONSTRAINT `fk_vote_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`idperson`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `work_history`
--
ALTER TABLE `work_history`
  ADD CONSTRAINT `fk_work_history_user1` FOREIGN KEY (`user_iduser`) REFERENCES `user` (`iduser`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `work_plan`
--
ALTER TABLE `work_plan`
  ADD CONSTRAINT `fk_work_plan_user1` FOREIGN KEY (`user_iduser`) REFERENCES `user` (`iduser`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
