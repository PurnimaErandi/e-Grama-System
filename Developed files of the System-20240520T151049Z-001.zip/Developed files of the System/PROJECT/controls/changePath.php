<?php

session_start();

$_SESSION['adminCurrentPagePath'] = $_GET['path'];
