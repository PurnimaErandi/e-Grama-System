<?php

session_start();
$_SESSION['adminLogId'] = "";
$_SESSION['admin_fullName'] = "";
$_SESSION['admin_profileImage'] ="";
$_SESSION['admin_role'] ="";
session_destroy();
