<?php

include '../../DB/conn.php';;

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['id'];
$personname = $_POST["personname"];
$hseno = $_POST["hseno"];
$status = $_POST["status"];
$gender = $_POST["gender"];
$date = $_POST["date"];
$place = $_POST["place"];
$idNo = $_POST["idNo"];
$telno = $_POST["telno"];
$email = $_POST["email"];
$alive = $_POST["alive"];
$religion = $_POST["religion"];
$nationality = $_POST["nationality"];
$education = $_POST["education"];
$occupation = $_POST["occupation"];
$oskills = $_POST["oskills"];
$isChild = $_POST["isChild"];
$parentId = $_POST["parentId"];

$query = "UPDATE `person` SET
`nameof_person`   ='$personname',
`house_no` ='$hseno',
`status`    ='$status',
`gender`  ='$gender',
`dateof_birth`   ='$date',
`birth_place`  ='$place',
`nic`        ='$idNo',
`telephone_no`        ='$telno',
`email`        ='$email',
`is_alive`        ='$alive',
`religions`        ='$religion',
`nationality`        ='$nationality',
`education`        ='$education',
`occupation`        ='$occupation',
`other_skills`        ='$oskills',
`is_child`  =   $isChild
WHERE `idperson` = $id";

$query_update = "UPDATE `parent_child_mapping` SET 
`parent_id` = $parentId 
WHERE `child_id` = $id";

if($isChild == true){
    mysqli_query($connection, $query_update);
}

if(mysqli_query($connection, $query)){
    echo "Personal Details updated successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}