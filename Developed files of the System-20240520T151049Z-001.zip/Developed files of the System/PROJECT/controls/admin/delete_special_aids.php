<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];
$id = $_POST["id"];

$query = "DELETE FROM `special_aids` WHERE `special_aids_id` = $id";

if(mysqli_query($connection, $query)){
    echo "Special aid data deleted successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}