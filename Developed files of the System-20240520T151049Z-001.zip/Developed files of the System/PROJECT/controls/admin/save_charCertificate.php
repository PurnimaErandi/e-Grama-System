<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$tempDate = '1000-01-01 00:00:00';

$requested_person_id = $_POST['requested_person_id'];
$created_date = date('Y-m-d H:i:s');
$expire_date = date('Y-m-d H:i:s', strtotime($created_date. ' + 6 months'));
$district = $_POST["districtList"];
$divi_sec_div = $_POST["divSecList"];
$gn_div_name = $_POST["divNum"];
$applicant_known_by_gn = $_POST["gnKnown"];
$if_so_since_when = isset($_POST["sinceDate"]) ? $_POST["sinceDate"] : $tempDate;
$applicant_name = $_POST["name"];
$applicant_address = $_POST["address"];
$age = $_POST["age"];
$civil_status = $_POST["civilStat"];
$sri_lankan_or_not = $_POST["isSL"];
$religion = $_POST["religion"];
$present_ocupation = $_POST["occu"];
$period_of_residence = $_POST["res"];
$nic = $_POST["nic"];
$no_of_electotial_reg = $_POST["elecReg"];
$name_of_father = $_POST["fatherNameAddr"];
$purpose = $_POST["certPurpose"];
$period_of_residence_in_gn = $_POST["esidPeriod"];
$nature_of_other_evidence = $_POST["natureResEvd"];
$applicant_has_been_convicted = $_POST["convByLaw"];
$interest_in_public_activities= $_POST["act"];
$hisorher_character = $_POST["charc"];
$remark= $_POST["remark"];
$reg_no = $_POST["regNum"];
$issuer = $_POST["issueBy"];
$date = $created_date;

$query = "INSERT INTO `character_certificate` (
  `requested_person_id`,
  `created_date`,
  `expire_date`,
  `district`,
  `divi_sec_div`,
  `gn_div_name`,
  `applicant_known_by_gn`,
  `if_so_since_when`,
  `applicant_name`,
  `applicant_address`,
  `age`,
  `civil_status`,
  `sri_lankan_or_not`,
  `religion`,
  `present_ocupation`,
  `period_of_residence`,
  `nic`,
  `no_of_electotial_reg`,
  `name_of_father`,
  `purpose`,
  `period_of_residence_in_gn`,
  `nature_of_other_evidence`,
  `applicant_has_been_convicted`,
  `interest_in_public_activities`,
  `hisorher_character`,
  `remark`,
  `reg_no`,
  `issuer`,
  `date`
)
VALUES
  (
    $requested_person_id,
    '$created_date',
    '$expire_date',
    '$district',
    '$divi_sec_div',
    '$gn_div_name ',
    $applicant_known_by_gn,
    '$if_so_since_when',
    '$applicant_name',
    '$applicant_address',
    '$age',
    '$civil_status',
    '$sri_lankan_or_not',
    '$religion',
    '$present_ocupation',
    '$period_of_residence',
    '$nic',
    '$no_of_electotial_reg',
    '$name_of_father', 
    '$purpose',
    '$period_of_residence_in_gn',
    '$nature_of_other_evidence',
    '$applicant_has_been_convicted',
    '$interest_in_public_activities',  
    '$hisorher_character',
    '$remark',
    '$reg_no', 
    '$issuer',    
    '$date'
)";

if(mysqli_query($connection, $query)){
    echo "Character certificate successfully saved!";
}else{
    echo "Error: ".mysqli_error($connection);
}
