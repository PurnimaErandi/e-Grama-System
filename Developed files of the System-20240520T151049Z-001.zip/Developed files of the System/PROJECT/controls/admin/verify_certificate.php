<?php

include '../../DB/conn.php';
include '../../mail_configurations/mailConfig.php';

session_start();
global $connection;
$conn = $connection;

$reqId = $_POST['reqId'];
$status = $_POST['status'];

$certName;
$deathNic;
$nic = getPersonNic(getRequestedUserId($reqId));
$personId = getPersonId($nic);
$a = array();

$user = getUserData($personId);

/* Reject any certificate */
if($status == 'rejected'){
    if(updateRequest($status, $reqId)){
        /* send granted mail here */
        $mail = fopen("../../email_templates/user-certificaterReq-reject.html", "r") or die("Unable to open file!");
        $msg = fread($mail, filesize("../../email_templates/user-certificaterReq-reject.html"));
        fclose($mail);
        $x = getUserDataForDeathCert($reqId);
        sendEmail($x['email'], $x['name'], $msg, "Certificate Rejected");

        $a = array("title"=>"Request Rejected", "msg"=>"This request is discarded!", "status"=>"success");
    }
    else{
        $a = array("title"=>"Action Failed", "msg"=>"Request action failed!", "status"=>"error");
    }
}

/* Character certificate */
if($status == 'granted' && $certName == 'character_certificate'){
    if($personId == -1){
        $a = array("title"=>"Person Not Found", "msg"=>"This person does not exist in eGrama", "status"=>"error");
    }
    else if(isExistCertificate($personId, $certName)){
        updateRequest($status, $reqId);
        /* send granted mail here */
        $mail = fopen("../../email_templates/grant-charCertificate.html", "r") or die("Unable to open file!");
        $msg = fread($mail, filesize("../../email_templates/grant-charCertificate.html"));
        fclose($mail);

        sendEmail($user['email'], $user['name'], $msg, "Character Certificate Granted");

        $a = array("title"=>"Request Granted", "msg"=>"This request is granted", "status"=>"success");
    }
    else{
        $a = array("title"=>"Certificate Not Exists", "msg"=>"Certificate does not exist. Please create new one.", "status"=>"warning");
    }
}

/* Death certificate */
if($status == 'granted' && $certName == 'death_certificate'){
    if(isExistDeadPerson($deathNic)){
        if(isExistCertificateByNic($deathNic, $certName) || isExistCertificateByChildRegNo($deathNic, $certName)){
            $d = getUserDataForDeathCert($reqId);
            updateRequest($status, $reqId);

            /* send granted mail here */
            $mail = fopen("../../email_templates/grant-deathCertificate.html", "r") or die("Unable to open file!");
            $msg = fread($mail, filesize("../../email_templates/grant-deathCertificate.html"));
            fclose($mail);

            sendEmail($d['email'], $d['name'], $msg, "Death Certificate Granted");
            $a = array("title"=>"Request Granted", "msg"=>"This request is granted", "status"=>"success");
        }
        else{
            $a = array("title"=>"Certificate Not Exists", "msg"=>"Certificate does not exist. Please create new one.", "status"=>"warning");
        }
    }
    else{
        $a = array("title"=>"Demised Person Not Found", "msg"=>"No demised person found for this NIC", "status"=>"error");
    }
}

/* Resident certificate */
if($status == 'granted' && $certName == 'residence_certificate'){
    if(isExistCertificate($personId, $certName)){
        updateRequest($status, $reqId);
         /* send granted mail here */
         $mail = fopen("../../email_templates/grant-resiCertificate.html", "r") or die("Unable to open file!");
         $msg = fread($mail, filesize("../../email_templates/grant-resiCertificate.html"));
         fclose($mail);
        
         sendEmail($user['email'], $user['name'], $msg, "Residence Certificate Granted");
        $a = array("title"=>"Request Granted", "msg"=>"This request is granted", "status"=>"success");
    }
    else{
        $a = array("title"=>"Certificate Not Exists", "msg"=>"Certificate does not exist. Please create new one.", "status"=>"warning");
    }
}

echo json_encode($a);

function getRequestedUserId($id){
    global $conn;
    global $certName;
    global $deathNic;
    $q = "SELECT * FROM `certificate_request` WHERE `request_id` = $id";
    $res = $conn->query($q);
    $userId = "";

    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $userId = $row["person_id"];
            $certName = $row["certificate_name"];
            $deathNic = $row["reason_for_request"];
        }
    }
    return $userId;
}

function isExistDeadPerson($deathNic){
    global $conn;
    global $personId;
    $q = "SELECT * FROM `person` WHERE `nic` = '$deathNic' AND `is_alive` = 0";
    $res = $conn->query($q);
    $adult_death = mysqli_num_rows($res) > 0;

    $q = "SELECT * FROM `person` p INNER JOIN `parent_child_mapping` m 
    ON p.idperson = m.child_id 
    WHERE m.child_regNo = '".$deathNic."' AND p.is_alive = 0";
    $res = $conn->query($q);
    $child_death = mysqli_num_rows($res) > 0;

    $q = "SELECT parent_id FROM `parent_child_mapping` WHERE `child_regNo` = '".$deathNic."'";
    $res = $conn->query($q);
    $parent_id = 0;
    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $parent_id = $row["parent_id"];
        }
    }
    $child_of_parent = $parent_id == $personId;

    return $adult_death || ($child_death && $child_of_parent);
}

function isExistPerson($pId){
    global $conn;
    $q = "SELECT * FROM `person` WHERE `idperson` = $pId";
    $res = $conn->query($q);
    return mysqli_num_rows($res) > 0;
}

function getPersonNic($userId){
    global $conn;
    $q = "SELECT * FROM `user` WHERE `iduser` = $userId";
    $res = $conn->query($q);
    $nic = "";

    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $nic = $row["user_nic"];
        }
    }
    return $nic;
}

function getPersonId($nic){
    global $conn;
    $q = "SELECT * FROM `person` WHERE `nic` = '$nic'";
    $res = $conn->query($q);
    $personId = "";

    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $personId = $row["idperson"];
        }
        return $personId;
    }
    else{
        return -1;
    }
}

function isExistCertificate($personId, $certificateName){
    global $conn;
    $q = "SELECT * FROM `$certificateName` WHERE `requested_person_id` = $personId";
    $res = $conn->query($q);
    $nic = "";

    return mysqli_num_rows($res) > 0;
}

function isExistCertificateByNic($deathNic, $certificateName){
    global $conn;
    $q = "SELECT * FROM `$certificateName` WHERE `person_nic` = '$deathNic'";
    $res = $conn->query($q);
    return mysqli_num_rows($res) > 0;
}

function isExistCertificateByChildRegNo($deathNic, $certificateName){
    global $conn;
    $q = "SELECT child_id FROM `parent_child_mapping` WHERE `child_regNo` = '".$deathNic."'";
    $res = $conn->query($q);
    $child_id = 0;
    if (mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $child_id = $row["child_id"];
        }
    }

    if($child_id == 0) { return false; }

    $q = "SELECT * FROM `$certificateName` WHERE `requested_person_id` = $child_id";
    $res = $conn->query($q);
    return mysqli_num_rows($res) > 0;
}

function updateRequest($status, $reqId){
    global $conn;
    $q = "UPDATE `certificate_request` SET `request_status` = '$status' "
            . "WHERE `request_id` = $reqId";
    $res = $conn->query($q);
    return mysqli_query($conn, $q);
}

function getUserData($personId){
    $q = "SELECT p.`email`, p.`nameof_person` FROM `person` p WHERE p.`idperson` = $personId";
    global $conn;
    $res = $conn->query($q);
    if($res->num_rows > 0){
        $r = array();
        while($row = $res->fetch_assoc()){
            $r = array(
                "email" => $row["email"],
                "name" => $row["nameof_person"]
            );
        }
        return $r;
    }
}

function getUserDataForDeathCert($reqId){
    $q = "SELECT p.* FROM `certificate_request` r INNER JOIN `user` p ON r.`person_id` = p.`iduser` 
    WHERE r.`request_id` = $reqId";
    global $conn;
    $res = $conn->query($q);
    if($res->num_rows > 0){
        $r = array();
        while($row = $res->fetch_assoc()){
            $r = array(
                "name" => $row["user_fullname"],
                "email" => $row["user_email"]
            );
        }
        return $r;
    }
}