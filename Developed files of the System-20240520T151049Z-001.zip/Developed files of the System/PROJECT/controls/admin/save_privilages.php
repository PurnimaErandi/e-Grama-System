<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();
    $role = $_POST['role'];

    $r = json_decode($role);

    if(isExistRole($r->roleName)){
        echo "Role name already exists!";
    }
    else{
        if(addRole($r->roleName)){
            addSystemDataPrivilages($r->functions->systemData);
            addCertificatePrivilages($r->functions->certificates);
            addUserManagePrivilages($r->functions->userManagement);
            addRecoveryPrivilages($r->functions->disasterRecoveryNode);
            echo "New role added successfully!";
        }
        else{
            echo "Server encountered an error!";
        }
    }

    function addRole($roleName){
        global $conn;
        $q1 = "INSERT INTO `role` (`role_name`) VALUES ('{$roleName}')";
        return mysqli_query($conn, $q1);
    }

    function addSystemDataPrivilages($sys){
        global $r;
        global $conn;
        $roleId = getRoleId($r->roleName);
        $prvId = getFunctionId($sys->funcName);
        $prvSubId1 = getSubfunctionId($sys->s1);
        $prvSubId2 = getSubfunctionId($sys->s2);
        $prvSubId3 = getSubfunctionId($sys->s3);
        $prvSubId4 = getSubfunctionId($sys->s4);

        $d1 = $sys->personalDetails;
        $d2 = $sys->propertyManagement;
        $d3 = $sys->workPlan;
        $d4 = $sys->aidInfo;

        $q1 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId1.", ".bv($d1[0]).", ".bv($d1[1]).", ".bv($d1[2]).", ".bv($d1[3]).")";

        $q2 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId2.", ".bv($d2[0]).", ".bv($d2[1]).", ".bv($d2[2]).", ".bv($d2[3]).")";

        $q3 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId3.", ".bv($d3[0]).", ".bv($d3[1]).", ".bv($d3[2]).", ".bv($d3[3]).")";

        $q4 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId4.", ".bv($d4[0]).", ".bv($d4[1]).", ".bv($d4[2]).", ".bv($d4[3]).")";

        mysqli_query($conn, $q1);
        mysqli_query($conn, $q2);
        mysqli_query($conn, $q3);
        mysqli_query($conn, $q4);
    }

    function addCertificatePrivilages($cer){
        global $r;
        global $conn;
        $roleId = getRoleId($r->roleName);
        $prvId = getFunctionId($cer->funcName);
        $prvSubId1 = getSubfunctionId($cer->s1);
        $prvSubId2 = getSubfunctionId($cer->s2);
        $prvSubId3 = getSubfunctionId($cer->s3);

        $d1 = $cer->charCert;
        $d2 = $cer->deathCert;
        $d3 = $cer->residCert;

        $q1 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId1.", ".bv($d1[0]).", ".bv($d1[1]).", ".bv($d1[2]).", ".bv($d1[3]).")";

        $q2 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId2.", ".bv($d2[0]).", ".bv($d2[1]).", ".bv($d2[2]).", ".bv($d2[3]).")";

        $q3 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId3.", ".bv($d3[0]).", ".bv($d3[1]).", ".bv($d3[2]).", ".bv($d3[3]).")";

        mysqli_query($conn, $q1);
        mysqli_query($conn, $q2);
        mysqli_query($conn, $q3);
    }

    function addUserManagePrivilages($mng){
        global $r;
        global $conn;
        $roleId = getRoleId($r->roleName);
        $prvId = getFunctionId($mng->funcName);
        $prvSubId1 = getSubfunctionId($mng->s1);
        $prvSubId2 = getSubfunctionId($mng->s2);
        $prvSubId3 = getSubfunctionId($mng->s3);

        $d1 = $mng->users;
        $d2 = $mng->userRoles;
        $d3 = $mng->myProfile;

        $q1 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId1.", ".bv($d1[0]).", ".bv($d1[1]).", ".bv($d1[2]).", ".bv($d1[3]).")";

        $q2 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId2.", ".bv($d2[0]).", ".bv($d2[1]).", ".bv($d2[2]).", ".bv($d2[3]).")";

        $q3 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId3.", ".bv($d3[0]).", ".bv($d3[1]).", ".bv($d3[2]).", ".bv($d3[3]).")";

        mysqli_query($conn, $q1);
        mysqli_query($conn, $q2);
        mysqli_query($conn, $q3);
    }

    function addRecoveryPrivilages($mng){
        global $r;
        global $conn;
        $roleId = getRoleId($r->roleName);
        $prvId = getFunctionId($mng->funcName);
        $prvSubId1 = getSubfunctionId($mng->s1);

        $d1 = $mng->disasterRecovery;

        $q1 = "INSERT INTO `privilage` (`role_id`, `prv_func_id`, `prv_subfunc_id`, `create`, `read`, `modify`, `delete`) 
        VALUES (".$roleId.", ".$prvId.", ".$prvSubId1.", ".bv($d1[0]).", ".bv($d1[1]).", ".bv($d1[2]).", ".bv($d1[3]).")";

        mysqli_query($conn, $q1);
    }
    
    function getRoleId($roleName){
        global $conn;
        $id = 0;
        $q = "SELECT `role_id` FROM `role` WHERE `role_name` = '{$roleName}'";
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $id = $row["role_id"];
            }
        }
        return $id;
    }

    function isExistRole($roleName){
        global $conn;
        $id = 0;
        $q = "SELECT `role_id` FROM `role` WHERE `role_name` = '{$roleName}'";
        $res = $conn->query($q);
        return $res->num_rows > 0;
    }

    function getFunctionId($functionName){
        global $conn;
        $id = 0;
        $q = "SELECT `privilage_function_id` FROM `privilage_function` WHERE `privilage_function_name` = '{$functionName}'";
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $id = $row["privilage_function_id"];
            }
        }
        return $id;
    }

    function getSubfunctionId($subfunctionName){
        global $conn;
        $id = 0;
        
        $q = "SELECT `privilage_subfunction_id` 
        FROM `privilage_subfunction` 
        WHERE `privilage_subfunction_name` = '{$subfunctionName}'";
        
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $id = $row["privilage_subfunction_id"];
            }
        }
        return $id;
    }

    function bv($obj){
        if($obj == ''){ return 0; } else { return 1; }
    }
?>