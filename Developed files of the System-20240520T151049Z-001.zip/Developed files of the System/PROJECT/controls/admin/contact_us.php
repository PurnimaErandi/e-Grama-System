<?php

include '../../DB/conn.php';

global $connection;

$name = $_POST["name"];
$email= $_POST["email"];
$subject= $_POST["subject"];
$message= $_POST["message"];


$query = "INSERT INTO `contact_us` (
  `name`,
  `email`,
  `subject`,
  `message`
)
VALUES
  (
    '$name',
    '$email',
    '$subject',
    '$message'

  )";

if(mysqli_query($connection, $query)){
    echo "Your message received successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}