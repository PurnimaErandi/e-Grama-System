<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['dataId'];

$date = $_POST['date'];
$remark = $_POST['remark'];
$latitude = $_POST['locLt'];
$longitude = $_POST['locLg'];
$dis_type = $_POST['disaster'];
$damages = $_POST['damages'];
$other = $_POST['other'];

$query = "UPDATE `disaster_management` SET
  `date` = '$date',
  `remark` = '$remark',
  `loc_latitude` = $latitude,
  `loc_longitude` = $longitude,
  `disaster_type` = '$dis_type',
  `damages` = '$damages',
  `other_details` = '$other' 
WHERE `disaster_management_id` = $id";

if(mysqli_query($connection, $query)){
    echo "Disaster Details updated successfully!";
}
else{
    echo "Error: ".mysqli_error($connection);
}

