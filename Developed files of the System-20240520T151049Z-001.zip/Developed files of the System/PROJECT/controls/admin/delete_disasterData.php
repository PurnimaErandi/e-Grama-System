<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['dataId'];


$query = "DELETE FROM `disaster_management` 
WHERE `disaster_management_id` = $id";

if(mysqli_query($connection, $query)){
    echo "Disaster Details deleted successfully!";
}
else{
    echo "Error: ".mysqli_error($connection);
}