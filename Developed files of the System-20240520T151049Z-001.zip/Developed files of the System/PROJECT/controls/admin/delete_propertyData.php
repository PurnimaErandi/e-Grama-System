<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = $_POST['Id'];

    $query = "DELETE FROM `property` 
    WHERE `idproperty` = $id";

    if(mysqli_query($connection, $query)){
        echo "Property Details deleted successfully!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>