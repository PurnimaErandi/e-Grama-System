<?php
    include '../../DB/conn.php';
    global $connection;
    session_start();
    $id = $_POST['Id'];
    $r;

    $query = "SELECT * FROM `work_history` WHERE `idwork_history` = $id";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $r = array(
                'province' => $row['work_history_province'],
                'district' => $row['work_history_district'],
                'division' => $row['work_history_divisional_secretariat'],
                'name' => $row['gn_name'],
                'address' => $row['work_history_address'],
                'telno' => $row['work_history_telephone_no'],
                'date' => $row['work_history_start_date_of_duty'],
                'odetails' => $row['other_details']
                
            );
        }
        echo json_encode($r);
    }
?>