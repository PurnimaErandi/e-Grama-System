<?php

include '../../DB/conn.php';
include '../../mail_configurations/mailConfig.php';

global $connection;
$conn = $connection;
$reqId = $_POST["id"];

    $q = "DELETE FROM `user_request` WHERE `request_id` = $reqId";
    $data = getRequestData($reqId);

    if(mysqli_query($conn, $q)){
        $mail = fopen("../../email_templates/user-req-reject.html", "r") or die("Unable to open file!");
        $msg = fread($mail, filesize("../../email_templates/user-req-reject.html"));
        fclose($mail);

        sendEmail($data['email'], $data['name'], $msg, "Account Request Rejected");

        $r = array("sts" => 1, "msg"=>"Request successfully rejected!");
        echo json_encode($r);
    }
    else{
        $r = array("sts" => 1, "msg"=>"Delete failure!");
        echo json_encode($r);
    }

function getRequestData($reqId){
    $q = "SELECT * FROM `user_request` WHERE `request_id` = $reqId";
    global $conn;
    $res = $conn->query($q);
    if($res->num_rows > 0){
        $r = array();
        while($row = $res->fetch_assoc()){
            $r = array(
                "email" => $row["email"],
                "name" => $row["name"]
            );
        }
        return $r;
    }
}