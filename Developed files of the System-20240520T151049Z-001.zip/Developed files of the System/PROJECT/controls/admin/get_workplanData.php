<?php
    include '../../DB/conn.php';
    global $connection;
    session_start();
    $id = $_POST['Id'];
    $r;

    $query = "SELECT * FROM `work_plan` WHERE `idwork_plan` = $id";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $r = array(
                'date' => $row['work_plan_date'],
                'time' => $row['work_plan_time'],
                'type' => $row['work_plan_type'],
                'desc' => $row['work_plan_description']
            );
        }
        echo json_encode($r);
    }
?>