<?php

include '../../DB/conn.php';
session_start();
global $connection;
$conn = $connection;

$sts = $_POST['status'];

$q = "SELECT c.*, u.user_fullname FROM `certificate_request` c INNER JOIN `user` u "
        . "ON c.person_id = u.iduser "
        . "WHERE `request_status` = '$sts'";
$res = $conn->query($q);
$requests = array();

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $r = array(
            "Id" => $row["request_id"],
            "certificate" => $row["certificate_name"],
            "reason" => $row["reason_for_request"],
            "date" => $row["request_date"],
            "status" => $row["request_status"],
            "requestor" => $row["user_fullname"]
        );
        
        array_push($requests, $r);
    }
}
    
echo json_encode($requests);
