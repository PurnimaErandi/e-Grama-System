<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $data = array();

    $q = "SELECT a.*, t.aid_type_name FROM `special_aids` a INNER JOIN `aid_type` t "
            . "ON a.aid_type_id = t.aid_type_id;";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array(
                "Id" => $row["special_aids_id"],
                "HouseNo" => $row["house_no"],
                "PersonName" => $row["name"],
                "AidType" => $row["aid_type_name"],
                "AccNo" => $row["account_no"],
                "Place" => $row["place"],
                "Date" => $row["date"],
                "Amount" => $row["amount"],
                "Other" => $row["other"]
            );
            array_push($data, $r);
        }
    }
    
    echo json_encode($data);
?>
