<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $data = array();

    // Query for gender

    $q = "SELECT `gender`, COUNT(`gender`) AS `count` FROM `person` 
        GROUP BY `gender`";
    $res = $conn->query($q);
    
    $r = array();
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r[$row['gender']] = intval($row['count']);
        }
        $data['genderWise'] = $r;
    }

    //Query for religion

    $q = "SELECT `religions`, COUNT(`religions`) AS `count`  FROM `person`
        GROUP BY `religions`";
    $res = $conn->query($q);
    
    $r = array();
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r[$row['religions']] = intval($row['count']);
        }
        $data['religionWise'] = $r;
    }

    //Query for nationality

    $q = "SELECT `nationality`, COUNT(`nationality`) AS `count`  FROM `person`
        GROUP BY `nationality`
        ORDER BY `count` DESC";
    $res = $conn->query($q);
    
    $r = array();
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r[$row['nationality']] = intval($row['count']);
        }
        $data['nationalityWise'] = $r;
    }

    //Query for is_alive

    $q = "SELECT `is_alive`, COUNT(`is_alive`) AS `count`  FROM `person`
        GROUP BY `is_alive`
        ORDER BY `count` DESC";
    $res = $conn->query($q);
    
    $r = array();
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r[$row['is_alive'] == "0" ? 'dead' : 'alive'] = intval($row['count']);
        }
        $data['aliveWise'] = $r;
    }

    //Query for education

    $q = "SELECT `education`, COUNT(`education`) AS `count`  FROM `person`
        GROUP BY `education`";
        $res = $conn->query($q);
    
    $r = array();
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r[$row['education']] = intval($row['count']);
        }
        $data['educationWise'] = $r;
    }

    //Query for occupation

    $q = "SELECT `occupation`, COUNT(`occupation`) AS `count`  FROM `person`
        GROUP BY `occupation`";
        $res = $conn->query($q);
    
    $r = array();
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r[$row['occupation']] = intval($row['count']);
        }
        $data['occupationWise'] = $r;
    }
    
    echo json_encode($data);
?>