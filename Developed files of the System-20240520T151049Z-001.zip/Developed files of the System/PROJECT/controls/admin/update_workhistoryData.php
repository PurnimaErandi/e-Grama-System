<?php

include '../../DB/conn.php';;

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['id'];
$province = $_POST["province"];
$district = $_POST["district"];
$division = $_POST["division"];
$name = $_POST["name"];
$address = $_POST["address"];
$telephone = $_POST["telno"];
$date = $_POST["date"];
$other = $_POST["odetails"];

$query = "UPDATE `work_history` SET
`work_history_province`   ='$province',
`work_history_district`   ='$district',
`work_history_divisional_secretariat` ='$division',
`gn_name`    ='$name',
`work_history_address`  ='$address',
`work_history_telephone_no`  ='$telephone',
`work_history_start_date_of_duty` ='$date',
`other_details`        ='$other' 
WHERE `idwork_history` = $id";


if(mysqli_query($connection, $query)){
    echo "Work History Details updated successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}

