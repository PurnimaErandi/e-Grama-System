<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $data = array();

    $q = "SELECT p.`idperson`, p.`nameof_person`, p.`house_no`, p.`gender`, p.`dateof_birth`, p.`telephone_no`, p.`nic`, v.`remark` 
    FROM `person` p LEFT JOIN `vote_removal_mapping` v 
    on p.`idperson` = v.`person_id` WHERE p.`is_alive` = 1 
    AND p.`dateof_birth` <= (SELECT (NOW() - INTERVAL 18 YEAR)) 
    ORDER BY p.`nameof_person` ASC";

    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array(
                "Id" => $row['idperson'],
                "Name" => $row['nameof_person'],
                "Address" => $row['house_no'],
                "Nic" => $row['nic'],
                "IsRemoved" => $row['remark'] == null ? boolval(false) : boolval(true),
                "Remark" => $row['remark'] == null ? '' : $row['remark'],
                "DoB" => $row['dateof_birth'],
                "Gender" => $row['gender'],
                "TelNo" => $row['telephone_no']
            );
            array_push($data, $r);
        }
    }
    
    echo json_encode($data);
?>