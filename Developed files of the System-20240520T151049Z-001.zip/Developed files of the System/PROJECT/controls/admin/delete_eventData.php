<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];
$id = $_POST['Id'];

$query = "DELETE FROM `event` WHERE `event_id` = $id";

if(mysqli_query($connection, $query)){
    echo "Event deleted successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}