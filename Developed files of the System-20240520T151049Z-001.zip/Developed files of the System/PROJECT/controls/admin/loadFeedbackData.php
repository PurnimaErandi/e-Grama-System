<?php

include '../../DB/conn.php';

global $connection;
$conn = $connection;

$q = "SELECT * FROM `feedback` f LEFT JOIN `user` u on 
f.`sender_id` = u.`iduser`";
$res = $conn->query($q);
$data = array();

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $r = array(
            "sender" => $row["user_fullname"] == null ? "Anonymous" : $row["user_fullname"],
            "date" => $row["date"],
            "type" => $row["feedback_type"],
            "comment" => $row["feedback"]
        );
        
        array_push($data, $r);
    }
}
    
echo json_encode($data);

?>