<?php

include '../../DB/conn.php';;

global $connection;
session_start();
$adminId = $_SESSION['LogId'];


$province = $_POST["provnce"];
$district = $_POST["distrct"];
$division = $_POST["divisionalsec"];
$gnname = $_POST["nameofgn"];
$address = $_POST["address"];
$telephone = $_POST["teleno"];
$dutydate = $_POST["sdateofduty"];
$other = $_POST["odetails"];

$query = "INSERT INTO `work_history` (
  `work_history_province`,
  `work_history_district`,
  `work_history_divisional_secretariat`,
  `gn_name`,
  `work_history_address`,
  `work_history_telephone_no`,
  `work_history_start_date_of_duty`,
  `other_details`,
  `user_iduser`
)
VALUES
  (
    '$province',
    '$district',
    '$division',
    '$gnname ',
    '$address',
    '$telephone',
    '$dutydate',
    '$other',   
    '$adminId'
  )";

if(mysqli_query($connection, $query)){
    echo "1";
}else{
    echo "Error: ".mysqli_error($connection);
}

