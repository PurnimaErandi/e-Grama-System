<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];


$requested_person_id = $_POST['requested_person_id'];
$created_date = date('Y-m-d H:i:s');
$expire_date = date('Y-m-d H:i:s', strtotime($created_date. ' + 6 months'));
$div_sec_name = $_POST["divSecList"];
$person_name = $_POST["personName"];
$permanent_residence = $_POST["residence"];
$nic= $_POST["nic"];
$date_of_birth = $_POST["dob"];
$age = $_POST["age"];
$residing_gnd = $_POST["residingGND"];
$purpose = $_POST["purpose"];
$applicant_name = $_POST["appName"];
$gn_division = $_POST["gndivision"];

$query = "INSERT INTO `residence_certificate` (
  `requested_person_id`,
  `created_date`,
  `expire_date`,
  `div_name`,
  `person_name`,
  `permanent_residence`,
  `nic`,
  `date_of_birth`,
  `age`,
  `residing_gnd`,
  `purpose`,
  `applicant_name`,
  `gn_division`
)
VALUES
  (
    $requested_person_id,
    '$created_date',
    '$expire_date',
    '$div_sec_name',
    '$person_name',
    '$permanent_residence',
    '$nic',
    '$date_of_birth',
    '$age',
    '$residing_gnd',
    '$purpose',  
    '$applicant_name',
    '$gn_division'
)";

if(mysqli_query($connection, $query)){
    echo "Residence certificate successfully saved!";
}else{
    echo "Error: ".mysqli_error($connection);
}
