<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$username = $_POST["uname"];
$password = $_POST["pword"];
$fullname = $_POST["fullname"];
$email = $_POST["email"];
$nic = $_POST["nic"];
$userrole = $_POST["urole"];
$imagepath = "./img/users/profile/";
$encpass = password_hash($password, PASSWORD_DEFAULT);

uploadFile();

$query = "INSERT INTO `user` (
  `user_fullname`,
  `user_uname`,
  `user_password`,
  `user_email`,
  `user_imgPath`,
  `user_nic`,
  `user_role_iduser_role`
)
VALUES
  (
    '$fullname',
    '$username',
    '$encpass',
    '$email',
    '$imagepath',
    '$nic',
    '$userrole'
)";

if(mysqli_query($connection, $query)){
    echo "1";
}else{
    echo "Error: ".mysqli_error($connection);
}

function uploadFile(){
    global $imagepath;
    //$path = "./img/users/profile/";
    $path = "./../img/users/profile/";
    $file = $path.basename($_FILES["profpic"]["name"]);
    $imagepath = $file;
    $file = ".".$file;  
    $type = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    if($type != null){
        $size = getimagesize($_FILES["profpic"]["tmp_name"]);
        if($size !== false)
            move_uploaded_file($_FILES["profpic"]["tmp_name"], $file);
    }
}