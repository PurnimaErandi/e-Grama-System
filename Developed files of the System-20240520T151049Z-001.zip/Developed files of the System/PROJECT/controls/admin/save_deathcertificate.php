<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$tempDate = '1000-01-01 00:00:00';
$requested_person_id = $_POST['requested_person_id'];
$created_date = date('Y-m-d H:i:s');
$gn_division = $_POST["gnDiv"];
$reg_division = $_POST["regDiv"];
$death_date = $_POST["deathDate"];
$death_place = $_POST["place"];
$person_nic = $_POST["nicno"];
$full_name = $_POST["fullname"];
$gender = $_POST["gender"];
$nationality = $_POST["nationality"];
$age = $_POST["age"];
$profession = $_POST["profession"];
$cause = $_POST["reason"];
$person_bound_to_give_info= $_POST["nameinfo"];
$address_of_bounded_person = $_POST["addressinfo"];
$regis_no = $_POST["regNum"];
$issuer = $_POST["issueBy"];

$q = "INSERT INTO `death_certificate` (
    `requested_person_id`,
    `created_date`,
    `gn_division`,
    `reg_division`,
    `death_date`,
    `death_place`,
    `person_nic`,
    `full_name`,
    `gender`,
    `nationality`,
    `age`,
    `profession`,
    `cause`,
    `person_bound_to_give_info`,
    `address_of_bounded_person`,
    `regis_no`,
    `issuer`
    
) VALUES (

    $requested_person_id,
    '$created_date',
    '$gn_division',
    '$reg_division',
    '$death_date',
    '$death_place',
    '$person_nic',
    '$full_name',
    '$gender',
    '$nationality',
    '$age',
    '$profession',
    '$cause ',
    '$person_bound_to_give_info',
    '$address_of_bounded_person',
    '$regis_no',
    '$issuer'
    
)";

if(mysqli_query($connection, $q)){
    echo "Death certificate successfully saved!";
}else{
    echo "Error: ".mysqli_error($connection);
}