<?php
include '../../DB/conn.php';

global $connection;
$conn = $connection;
session_start();
$id = $_SESSION['LogId'];

$q = "SELECT * FROM `user` WHERE `iduser` = $id";
$res = $conn->query($q);
if($res->num_rows > 0){
    while($row = $res->fetch_assoc()){
        $name = $row["user_fullname"];
        $email = $row["user_email"];
        $image = $row["user_imgPath"];
    }
}

$data = Array("title"=>$name, "email"=>$email, "image"=>$image);
echo json_encode($data);

