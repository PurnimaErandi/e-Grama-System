<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $id = $_POST["person_id"];

    $data = array();
    $r;

    $q = "SELECT * FROM `public_assistance` WHERE `person_id`= $id";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array(
                "type" => $row["type"],
                "donation" => $row["donation"],
                "amount" => $row["amount"],
                "place" => $row["place"],
                "other_details" => $row["other_details"],
                "account_no" => $row["account_no"]
            );
            array_push($data, $r);
        }
    }
    
    echo json_encode($data);
?>
