<?php
    include '../../DB/conn.php';
    global $connection;
    session_start();
    $id = $_POST['Id'];
    $r;

    $query = "SELECT * FROM `house` WHERE `house_no` = $id";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $r = array(
                'husestatus' => $row['house_status'],
                'husetype' => $row['house_type'],
                'walls' => $row['walls'],
                'floor' => $row['floor'],
                'roof' => $row['roofs'],
                'date' => $row['house_built_date'],
                'odetails' => $row['other_details'],
                'radio' => $row['radio'],
                'tv' => $row['television'],
                'landphone' => $row['landline_phones'],
                'mobphone' => $row['mobile_phones'],
                'desktop' => $row['desktop_computer'],
                'laptop' => $row['laptop'],
                'internet' => $row['internet_connections'],
                'washmachine' => $row['washing_machine'],
                'refrig' => $row['refrigerator'],
                'aircondi' => $row['air_conditioner'],
                'gascook' => $row['gas_cooker'],
                'ricecook' => $row['rice_cooker'],
                'housename' => $row['house_name']
                
            );
        }
        echo json_encode($r);
    }
?>