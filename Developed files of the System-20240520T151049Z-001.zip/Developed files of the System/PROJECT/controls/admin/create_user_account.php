<?php

include '../../DB/conn.php';
include '../../mail_configurations/mailConfig.php';

global $connection;
$conn = $connection;
$reqid = $_POST["Id"];
$uName = $_POST["uName"];

$q = "SELECT * FROM `user_request` WHERE `request_id` = $reqid AND `request_status` = 'pending'";
    $res = $conn->query($q);
    
    if (mysqli_num_rows($res) > 0) {
        $nic;
        $email;
        $name;
        $msg = "None";
        
        while ($row = mysqli_fetch_assoc($res)) {
            $nic = $row["nic"];
            $email = $row["email"];
            $name = $row["name"];
        }
        if(updateRequestStatus($reqid)){
            $msg = createAccount($nic, $email, $name, $uName);
        }
    }
    echo $msg;

function createAccount($nic, $email, $name, $uname){
    global $conn;
    $pass = generateRandomText(8);
    $roleId = 3;
    $hash_pass = password_hash($pass, PASSWORD_DEFAULT);
    
    $q = "INSERT INTO `user` (`user_fullname`, `user_uname`, `user_password`, `user_email`, `user_nic`, `user_role_iduser_role`) "
            . "VALUES ('$name', '$uname', '$hash_pass', '$email', '$nic', '$roleId')";
    
    if(mysqli_query($conn, $q)){

        $mail = fopen("../../email_templates/user-req-accept.html", "r") or die("Unable to open file!");
        $msg = fread($mail, filesize("../../email_templates/user-req-accept.html"));
        fclose($mail);

        $msg = str_replace("#username#", $uname, $msg);
        $msg = str_replace("#password#", $pass, $msg);

        sendEmail($email, $uname, $msg, "Account Request Accepted");
        
        return $pass;
    }
    else{
        return "Create failure!";
    }
}

function generateRandomText($length = 16){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function updateRequestStatus($id){
    global $conn;
    $q = "UPDATE `user_request` SET `request_status` = 'approved' WHERE `request_id` = $id";
    return mysqli_query($conn, $q);
}


