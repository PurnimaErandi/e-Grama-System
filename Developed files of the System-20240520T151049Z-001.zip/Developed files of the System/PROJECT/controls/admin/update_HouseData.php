<?php

include '../../DB/conn.php';;

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['id'];
$husestatus = $_POST["husestatus"];
$husetype = $_POST["husetype"];
$walls = $_POST["walls"];
$floor = $_POST["floor"];
$roof = $_POST["roof"];
$date = $_POST["date"];
$odetails = $_POST["odetails"];
$radio = $_POST["radio"];
$tv = $_POST["tv"];
$landphone = $_POST["landphone"];
$mobphone = $_POST["mobphone"];
$desktop = $_POST["desktop"];
$laptop = $_POST["laptop"];
$internet = $_POST["internet"];
$washmachine = $_POST["washmachine"];
$refrig = $_POST["refrig"];
$aircondi = $_POST["aircondi"];
$gascook = $_POST["gascook"];
$ricecook = $_POST["ricecook"];
$housename = $_POST["housename"];

$query = "UPDATE `house` SET
`house_status`   ='$husestatus',
`house_type` ='$husetype',
`walls`    ='$walls',
`floor`  ='$floor',
`roofs`   ='$roof',
`house_built_date`  ='$date',
`other_details`        ='$odetails',
`radio`        ='$radio',
`television`        ='$tv',
`landline_phones`        ='$landphone',
`mobile_phones`        ='$mobphone',
`desktop_computer`        ='$desktop',
`laptop`        ='$laptop',
`internet_connections`        ='$internet',
`washing_machine`        ='$washmachine',
`refrigerator`        ='$refrig',
`air_conditioner`        ='$aircondi',
`gas_cooker`        ='$gascook',
`rice_cooker`        ='$ricecook',
`house_name`        ='$housename'
WHERE `house_no` = $id";


if(mysqli_query($connection, $query)){
    echo "House Details updated successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}

