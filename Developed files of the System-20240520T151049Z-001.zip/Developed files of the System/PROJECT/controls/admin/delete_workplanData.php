<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = $_POST['Id'];

    $query = "DELETE FROM `work_plan` 
    WHERE `idwork_plan` = $id";

    if(mysqli_query($connection, $query)){
        echo "Work plan Details deleted successfully!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>