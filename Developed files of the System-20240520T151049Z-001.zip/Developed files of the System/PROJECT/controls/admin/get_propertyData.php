<?php
    include '../../DB/conn.php';
    global $connection;
    session_start();
    $id = $_POST['Id'];
    $r;

    $query = "SELECT * FROM `property` WHERE `idproperty` = $id";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $r = array(
                'gnoffice' => $row['grama_niladhari_office'],
                'address' => $row['address'],
                'purchaseland' => $row['purchase_of_land'],
                'lati' => $row['house_latitude'],
                'long' => $row['house_longitude'],
                'water' => $row['water'],
                'lights' => $row['lights'],
                'toilets' => $row['toilets'],
                'garbage' => $row['garbage'],
                'crops' => $row['major_crops'],
                'streetname' => $row['villagestreet_name']
                
            );
        }
        echo json_encode($r);
    }
?>