<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];


$date = $_POST["date"];
$time = $_POST["time"];
$type = $_POST["typeofwork"];
$description = $_POST["descriptn"];

$query = "INSERT INTO `work_plan` (
  `work_plan_date`,
  `work_plan_time`,
  `work_plan_description`,
  `work_plan_type`,
  `user_iduser`
)
VALUES
  (
    '$date',
    '$time',
    '$description',
    '$type',
    '$adminId'
  )";

if(mysqli_query($connection, $query)){
    echo "1";
}else{
    echo "Error: ".mysqli_error($connection);
}