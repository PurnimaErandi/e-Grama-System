<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = $_POST['Id'];

    $query = "DELETE FROM `person` 
    WHERE `idperson` = $id";

    if(mysqli_query($connection, $query)){
        echo "Personal details deleted successfully!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>