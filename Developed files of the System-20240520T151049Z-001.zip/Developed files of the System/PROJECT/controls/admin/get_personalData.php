<?php
    include '../../DB/conn.php';
    global $connection;
    session_start();
    $id = $_POST['Id'];
    $r;

    $query = "SELECT p.*, m.`parent_id` FROM `person` p 
    LEFT JOIN `parent_child_mapping` m 
    ON p.`idperson` = m.`child_id` 
    WHERE `idperson` = $id";

    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $isChild = $row['is_child'] == '1' ? true : false;

            $r = array(
                'personname' => $row['nameof_person'],
                'hseno' => $row['house_no'],
                'status' => $row['status'],
                'gender' => $row['gender'],
                'date' => $row['dateof_birth'],
                'place' => $row['birth_place'],
                'idNo' => $row['nic'],
                'telno' => $row['telephone_no'],
                'email' => $row['email'],
                'alive' => $row['is_alive'],
                'religion' => $row['religions'],
                'nationality' => $row['nationality'],
                'education' => $row['education'],
                'occupation' => $row['occupation'],
                'oskills' => $row['other_skills'],
                'isChild' => $isChild,
                'parentId' => $row['parent_id']
            );
        }
        echo json_encode($r);
    }
?>