<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $data = array();

    $q = "SELECT * FROM `role` WHERE `role_name` <> 'Super Admin'";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array("roleId"=>$row["role_id"], "roleName"=>$row["role_name"]);
            array_push($data, $r);
        }
    }
    
    echo json_encode($data);
?>