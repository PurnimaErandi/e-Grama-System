<?php

include '../../DB/conn.php';

global $connection;
$conn = $connection;

$q = "SELECT `rate`, COUNT(`rate`) AS `count`
    FROM `feedback`
    GROUP BY `rate`
    ORDER BY `rate` ASC;";

$res = $conn->query($q);
$dataset = array();

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $pair = array(
            "rateIndex"  => intval($row['rate']),
            "count" => intval($row['count'])
        );
        array_push($dataset, $pair);
    }
}
    
echo json_encode($dataset);

?>