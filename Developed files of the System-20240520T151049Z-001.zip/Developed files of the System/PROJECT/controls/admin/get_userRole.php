<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$q = "SELECT * FROM `role` WHERE `role_name` <> 'Super Admin'";
$r = mysqli_query($connection, $q);
$roles = array();
if (mysqli_num_rows($r) > 0) {
    while ($row = mysqli_fetch_assoc($r)) {
        $roleId = $row['role_id'];
        $role = $row['role_name'];
        
        $roles[] = array("roleId" => $roleId, "role" => $role);
    }
}

echo json_encode($roles);