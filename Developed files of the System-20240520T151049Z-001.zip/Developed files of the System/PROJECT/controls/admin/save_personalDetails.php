<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

    
    $nameof_person      = $_POST["persname"];
    $house_no           = $_POST["houseno"];
    $status             = $_POST["stts"];
    $gender             = $_POST["gndr"];
    $dateof_birth       = $_POST["dob"];
    $birth_place        = $_POST["birthplace"];
    $telephone_no       = $_POST["telno"];
    $email              = $_POST["email"];
    $is_alive           = $_POST["isAlive"] == '1' ? 1 : 0;
    $religions          = $_POST["relgns"];
    $nationality        = $_POST["natnalty"];
    $nic                = $_POST["nic"];
    $education          = $_POST["edctn"];
    $occupation         = $_POST["occptn"];
    $phyMental_health   = $_POST["physcal"];
    $vehicles           = $_POST["vehicls"];
    $lang_knowledge     = $_POST["langknlg"];
    $it_knowledge       = $_POST["itknlg"];
    $other_skills       = $_POST["otherskills"];
    $aid                = $_POST["aidlist"];
    $is_child           = $_POST["isChild"];
    $guardian_id        = $_POST["guardian"];

$query ="INSERT INTO `project`.`person` (
  `nameof_person`,
  `house_no`,
  `status`,
  `gender`,
  `dateof_birth`,
  `birth_place`,
  `telephone_no`,
  `email`,
  `is_alive`,
  `religions`,
  `nationality`,
  `nic`,
  `education`,
  `occupation`,
  `phyMental_health`,
  `vehicles`,
  `lang_knowledge`,
  `it_knowledge`,
  `other_skills`,
  `is_child`
  
)
VALUES
  (
    '$nameof_person',
    '$house_no',
    '$status',
    '$gender',
    '$dateof_birth',
    '$birth_place',
    '$telephone_no',
    '$email', 
    '$is_alive',
    '$religions',
    '$nationality',
    '$nic',    
    '$education',
    '$occupation',
    '$phyMental_health',
    '$vehicles',
    '$lang_knowledge',
    '$it_knowledge',
    '$other_skills',
     $is_child
    
  )";

mysqli_query($connection, $query);

if($is_child != 1){
  $q = "SELECT `idperson` FROM `person` WHERE `nameof_person` = '$nameof_person' AND `house_no` = '$house_no' AND `telephone_no` = '$telephone_no'";
  $r = mysqli_query($connection, $q);
  $id = 0;
  if (mysqli_num_rows($r) > 0) {
      while ($row = mysqli_fetch_assoc($r)) {
          $id = $row['idperson'];
      }
  }

  $aidArray = json_decode($aid, true);
  $msg = 1;

  foreach($aidArray as $a=>$v){
      $q1 = "INSERT INTO `project`.`public_assistance` (
          `type`,
          `donation`,
          `account_no`,
          `amount`,
          `place`,
          `other_details`,
          `person_id`
        )
        VALUES
          (
            '".$v["type"]."',
            '".$v["donationNo"]."',
            '".$v["account"]."',
            '".$v["amount"]."',
            '".$v["place"]."',
            '".$v["details"]."',
            $id
          );";
      
      $msg = null;
      if(mysqli_query($connection, $q1)){
          $msg = 1;
      }else{
          $msg = "Error: ".mysqli_error($connection);
          break;
      }
  }

  echo $msg;
}
else{
  $q = "SELECT * FROM `person` WHERE `is_child` = 1 ORDER BY `idperson` DESC LIMIT 1";
  $r = mysqli_query($connection, $q);
  $msg = 'not-executed-yet';
  $child_id = 0;
  if (mysqli_num_rows($r) > 0) {
      while ($row = mysqli_fetch_assoc($r)) {
          $child_id = $row['idperson'];
      }
  }
  else{
    $msg = "Error: ".mysqli_error($connection);
  }

  $uid = uniqid();
  $qchild = "INSERT INTO `parent_child_mapping` (
    `child_id`,
    `parent_id`,
    `child_regNo`
  ) VALUES (
    $child_id,
    $guardian_id,
    '$uid'
  )";

  if(mysqli_query($connection, $qchild)){
    $msg = 1;
  }
  else{
    $msg = "Error: ".mysqli_error($connection);
  }

  echo $msg;
}



