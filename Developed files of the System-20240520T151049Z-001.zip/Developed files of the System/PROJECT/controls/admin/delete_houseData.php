<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = $_POST['Id'];

    $query = "DELETE FROM `house` 
    WHERE `house_no` = $id";

    if(mysqli_query($connection, $query)){
        echo "House Details deleted successfully!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>