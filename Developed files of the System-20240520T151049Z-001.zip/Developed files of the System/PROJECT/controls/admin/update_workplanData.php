<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = $_POST['id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $type = $_POST['type'];
    $desc = $_POST['desc'];

    $query = "UPDATE `work_plan` SET 
    `work_plan_date` = '$date',
    `work_plan_time` = '$time',
    `work_plan_type` = '$type',
    `work_plan_description` = '$desc' 
    WHERE `idwork_plan` = $id";

    if(mysqli_query($connection, $query)){
        echo "Work plan Details updated successfully!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>