<?php

include '../../DB/conn.php';

global $connection;
$conn = $connection;

$name = $_POST["name"];
$nic = $_POST["nic"];
$email = $_POST["email"];
$address = $_POST["address"];
$phone = $_POST["phone"];

if(isAvailableRequest()){
    echo "You have already requesetd an account using this NIC or Email address. Please wait until admin responds to your request.";
}
else{
    if(isRegisteredUser()){
        if(createRequest()){
            echo "Your request has been submitted! You will be notified once your request is finished.";
        }
        else{
            echo "Request creation failed!";
        }
    }
    else{
        echo "You have not registered with eGrama System!";
    }
}

function isAvailableRequest(){
    global $conn;
    global $nic; global $email;
    $q = "SELECT * FROM `user_request` WHERE `request_status` = 'pending' AND (`nic` = '$nic' OR `email` = '$email')";
    $res = $conn->query($q);
    
    return $res->num_rows > 0;
}

function isRegisteredUser(){
    global $conn;
    global $nic;
    $q = "SELECT * FROM `person` WHERE `nic` = '$nic'";
    $res = $conn->query($q);
    
    return $res->num_rows > 0;
}

function createRequest(){
    global $conn;
    global $name; global $email; global $nic; global $address; global $phone; 
    $status = 'pending';
    $q = "INSERT INTO `user_request` (`name`, `email`, `nic`, `address`, `contact_no`, `request_status`) VALUES ('$name', '$email', '$nic', '$address', '$phone', '$status')";
    
    return mysqli_query($conn, $q);
}

