<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();
    
    $id = $_POST["roleId"];

    $systemData = array();
    $certificates = array();
    $userManagement = array();
    $disasterRecoveryNode = array();
  
    function getSystemData(){
        global $conn; global $id; global $systemData; global $x;

        $q = "SELECT r.`role_id`, r.`role_name`, p.`create`, p.`read`, p.`modify`, p.`delete`, 
        f.`privilage_function_name`, s.`privilage_subfunction_name` FROM `role` r INNER JOIN `privilage` p 
        ON r.`role_id` = p.`role_id` INNER JOIN `privilage_subfunction` s
        ON s.`privilage_subfunction_id` = p.`prv_subfunc_id` INNER JOIN `privilage_function` f
        ON f.`privilage_function_id` = p.`prv_func_id` WHERE r.`role_id` = $id AND f.`privilage_function_name` = 'systemData'";  
        
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $r = array($row["privilage_subfunction_name"] =>
                    array(bv($row["create"]), bv($row["read"]), bv($row["modify"]), bv($row["delete"]))
                );
                $systemData = array_merge($systemData, $r);
            }
        }
    }

    function getCertificates(){
        global $conn; global $id; global $certificates;

        $q = "SELECT r.`role_id`, r.`role_name`, p.`create`, p.`read`, p.`modify`, p.`delete`, 
        f.`privilage_function_name`, s.`privilage_subfunction_name` FROM `role` r INNER JOIN `privilage` p 
        ON r.`role_id` = p.`role_id` INNER JOIN `privilage_subfunction` s
        ON s.`privilage_subfunction_id` = p.`prv_subfunc_id` INNER JOIN `privilage_function` f
        ON f.`privilage_function_id` = p.`prv_func_id` WHERE r.`role_id` = $id AND f.`privilage_function_name` = 'certificates'";  
        
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $r = array($row["privilage_subfunction_name"] =>
                array(bv($row["create"]), bv($row["read"]), bv($row["modify"]), bv($row["delete"]))
                );
                $certificates = array_merge($certificates, $r);
            }
        }
    }

    function getuserManage(){
        global $conn; global $id; global $userManagement;

        $q = "SELECT r.`role_id`, r.`role_name`, p.`create`, p.`read`, p.`modify`, p.`delete`, 
        f.`privilage_function_name`, s.`privilage_subfunction_name` FROM `role` r INNER JOIN `privilage` p 
        ON r.`role_id` = p.`role_id` INNER JOIN `privilage_subfunction` s
        ON s.`privilage_subfunction_id` = p.`prv_subfunc_id` INNER JOIN `privilage_function` f
        ON f.`privilage_function_id` = p.`prv_func_id` WHERE r.`role_id` = $id AND f.`privilage_function_name` = 'userManagement'";  
        
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $r = array($row["privilage_subfunction_name"] =>
                array(bv($row["create"]), bv($row["read"]), bv($row["modify"]), bv($row["delete"]))
                );
                $userManagement = array_merge($userManagement, $r);
            }
        }
    }

    function getDisasterManage(){
        global $conn; global $id; global $disasterRecoveryNode;

        $q = "SELECT r.`role_id`, r.`role_name`, p.`create`, p.`read`, p.`modify`, p.`delete`, 
        f.`privilage_function_name`, s.`privilage_subfunction_name` FROM `role` r INNER JOIN `privilage` p 
        ON r.`role_id` = p.`role_id` INNER JOIN `privilage_subfunction` s
        ON s.`privilage_subfunction_id` = p.`prv_subfunc_id` INNER JOIN `privilage_function` f
        ON f.`privilage_function_id` = p.`prv_func_id` WHERE r.`role_id` = $id AND f.`privilage_function_name` = 'disasterRecoveryNode'";  
        
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $r = array($row["privilage_subfunction_name"] =>
                array(bv($row["create"]), bv($row["read"]), bv($row["modify"]), bv($row["delete"]))
                );
                $disasterRecoveryNode = array_merge($disasterRecoveryNode, $r);
            }
        }
    }
    
    function bv($x){
        return $x == "1" ? true : false;
    }

    getSystemData();
    getCertificates();
    getuserManage();
    getDisasterManage();
  
    $data = array(
        "roleId" => $id,
        "functions" => array(
            "systemData" => $systemData,
            "certificates" => $certificates, 
            "userManagement" => $userManagement, 
            "disasterRecoveryNode" => $disasterRecoveryNode
        )
    );

    echo json_encode($data);
?>