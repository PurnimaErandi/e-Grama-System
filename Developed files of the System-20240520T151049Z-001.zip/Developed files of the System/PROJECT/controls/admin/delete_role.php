<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();
    $id = $_POST['roleId'];

    if(deletePrivilages($id) && deleteRole($id)){
        echo "User role successfully deleted!";
    }
    else{
        echo "Delete failed due to server error!";
    }

    function deletePrivilages($roleId){
        global $conn;
        $q = "DELETE FROM `privilage` WHERE `role_id` = $roleId";
        return mysqli_query($conn, $q);
    }

    function deleteRole($roleId){
        global $conn;
        $q = "DELETE FROM `role` WHERE `role_id` = $roleId";
        return mysqli_query($conn, $q);
    }
?>