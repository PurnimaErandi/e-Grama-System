<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$grama_niladhari_office = $_POST["gnoffice"];
$address                = $_POST["address"];
$purchase_of_land       = $_POST["purchofland"];
$house_latitude         = $_POST["lati"];
$house_longitude        = $_POST["long"];
$water                  = $_POST["water"];
$lights                 = $_POST["lights"];
$toilets                = $_POST["toilets"];
$garbage                = $_POST["garbage"];
$major_crops            = $_POST["mcrops"];
$villagestreet_name     = $_POST["villstrtname"];


            
$query ="INSERT INTO `property` (
  `grama_niladhari_office`,
  `address`,
  `purchase_of_land`,
  `house_latitude`,
  `house_longitude`,
  `water`,
  `lights`,
  `toilets`,
  `garbage`,
  `major_crops`,
  `villagestreet_name`
)

VALUES
  (
    '$grama_niladhari_office',
    '$address',
    '$purchase_of_land',
    '$house_latitude',
    '$house_longitude',
    '$water',
    '$lights',
    '$toilets',
    '$garbage',
    '$major_crops',
    '$villagestreet_name'    
  )";

if(mysqli_query($connection, $query)){
    echo "1";
}else{
    echo "Error: ".mysqli_error($connection);
}

