<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = intval($_POST['dataId']);
    $remark = $_POST['remark'];

    if(isExistRecord($id)){
        $q = "UPDATE `vote_removal_mapping` SET 
        `remark` = '$remark' WHERE `person_id` = $id";
        if(mysqli_query($connection, $q)){
            echo "Vote entry updated!";
        }
        else{
            echo "Error: ".mysqli_error($connection);
        }
    }
    else{
        $q = "INSERT INTO `vote_removal_mapping` (`person_id`, `remark`) 
        VALUES ($id, '$remark')";
        if(mysqli_query($connection, $q)){
            echo "Vote entry updated!";
        }
        else{
            echo "Error: ".mysqli_error($connection);
        }
    }

    function isExistRecord($id){
        global $connection;
        $q = "SELECT * FROM `vote_removal_mapping` 
        WHERE `person_id` = $id";

        $res = $connection->query($q);
        return $res->num_rows > 0;
    }

?>