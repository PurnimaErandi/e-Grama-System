<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];


$accountNo = $_POST['accNo'];
$aidTypeId = $_POST['aidType'];
$amount = $_POST['amount'];
$date = $_POST['date'];
$house_no = $_POST['houseNo'];
$name = $_POST['pName'];
$place = $_POST['place'];
$other = $_POST['other'];

$query = "INSERT INTO `special_aids` (
  `account_no`,
  `aid_type_id`,
  `amount`,
  `date`,
  `house_no`,
  `name`,
  `other`,
  `place`
)
VALUES
  (
    '$accountNo',
    $aidTypeId,
    $amount,
    '$date',
    '$house_no',
    '$name',
    '$other',
    '$place'
  )";

if(mysqli_query($connection, $query)){
    echo "Special aid saved successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}

