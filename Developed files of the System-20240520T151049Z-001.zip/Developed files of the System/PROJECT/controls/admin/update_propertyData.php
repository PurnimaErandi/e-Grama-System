<?php

include '../../DB/conn.php';;

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['id'];
$gnoffice = $_POST["gnoffice"];
$address = $_POST["address"];
$purchase = $_POST["purchofland"];
$lati = $_POST["lati"];
$long = $_POST["long"];
$water = $_POST["water"];
$lights = $_POST["lights"];
$toilets = $_POST["toilets"];
$garbage = $_POST["garbage"];
$crops = $_POST["crops"];
$streetname = $_POST["streetname"];

$query = "UPDATE `property` SET
`grama_niladhari_office`   ='$gnoffice',
`address`   ='$address',
`purchase_of_land` ='$purchase',
`house_latitude`    ='$lati',
`house_longitude`  ='$long',
`water`   ='$water',
`lights`  ='$lights',
`toilets`        ='$toilets',
`garbage`        ='$garbage',
`major_crops`        ='$crops',
`villagestreet_name`        ='$streetname'
WHERE `idproperty` = $id";


if(mysqli_query($connection, $query)){
    echo "Property Details updated successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}

