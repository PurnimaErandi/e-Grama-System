<?php

include '../../DB/conn.php';

global $connection;
$conn = $connection;
$reqid = $_POST["Id"];
$requests = array();

echo json_encode(isVerified($reqid));

function isVerified($id){
    global $conn;
    $q = "SELECT * FROM `user_request` WHERE `request_id` = $id AND `request_status` = 'pending'";
    $res = $conn->query($q);
    
    if (mysqli_num_rows($res) > 0) {
        $nic = "";
        while ($row = mysqli_fetch_assoc($res)) {
            $nic = $row["nic"];
            $email = $row["email"];
            $name = $row["name"];
        }
    }
    
    $q1 = "SELECT * FROM `person` WHERE `nic` = '$nic'";
    $res = $conn->query($q1);
    
    if (mysqli_num_rows($res) > 0) {
        $result = array(
            "Id" => $id,
            "msg" => "Account is verified and available in system database",
            "isSuccess" => 1,
            "password" => ""
        );
        return $result;
    }
    else{
        $result = array(
            "Id" => $id,
            "msg" => "User not found in system database",
            "isSuccess" => 0,
            "password" => "null"
        );
        return $result;
    }
}
