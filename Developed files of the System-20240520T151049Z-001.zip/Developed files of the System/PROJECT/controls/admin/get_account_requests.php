<?php

include '../../DB/conn.php';

global $connection;
$conn = $connection;

$q = "SELECT * FROM `user_request` WHERE `request_status` = 'pending'";
$res = $conn->query($q);
$requests = array();

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $r = array(
            "Id" => $row["request_id"],
            "Name" => $row["name"],
            "Email" => $row["email"],
            "NIC" => $row["nic"],
            "Address" => $row["address"],
            "ContactNo" => $row["contact_no"],
        );
        
        array_push($requests, $r);
    }
}
    
echo json_encode($requests);

