<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = $_POST['Id'];

    $query = "DELETE FROM `work_history` 
    WHERE `idwork_history` = $id";

    if(mysqli_query($connection, $query)){
        echo "Work History Details deleted successfully!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>