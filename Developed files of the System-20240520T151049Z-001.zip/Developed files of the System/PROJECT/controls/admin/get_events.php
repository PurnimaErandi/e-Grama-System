<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();
    $filter = $_POST['status'];

    $data = array();

    $q = "SELECT * FROM `event`";

    if($filter == 'pub'){
        $q = "SELECT * FROM `event` WHERE `is_public` = 1";
    }

    if($filter == 'prv'){
        $q = "SELECT * FROM `event` WHERE `is_public` = 0";
    }

    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array(
                "Id" => $row['event_id'],
                "Name" => $row['event_name'],
                "Date" => $row['date'],
                "StartTime" => $row['start_time'],
                "EndTime" => $row['end_time'],
                "Location" => $row['location'],
                "IsPublic" => $row['is_public']
            );
            
            array_push($data, $r);
        }
    }
    
    echo json_encode($data);
?>