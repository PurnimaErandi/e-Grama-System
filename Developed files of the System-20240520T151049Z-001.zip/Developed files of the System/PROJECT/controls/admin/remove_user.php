<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$userId = $_POST['userId'];
//$user_imgPath = '';

$q = "SELECT `user_imgPath` FROM `user` WHERE `iduser` = $userId";
$r = mysqli_query($connection, $q);
if (mysqli_num_rows($r) > 0) {
    while ($row = mysqli_fetch_assoc($r)) {
        $user_imgPath = $row['user_imgPath'];
    }
}

$query = "DELETE FROM `user` WHERE `iduser` = $userId";

if(mysqli_query($connection, $query)){
    removeFile();
    echo "1";
}else{
    echo "Error: ".mysqli_error($connection);
}

function removeFile(){
    global $user_imgPath;
    //$user_imgPath = str_replace("/..", "", $user_imgPath);
    unlink(".".$user_imgPath);
}