<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $data = array();

    $q = "SELECT * FROM `disaster_management`";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array(
                "Id" => $row['disaster_management_id'],
                "Date" => $row['date'],
                "Remark" => $row['remark'],
                "Latitude" => floatval($row['loc_latitude']),
                "Longitude" => floatval($row['loc_longitude']),
                "DisasterType" => $row['disaster_type'],
                "Damages" => $row['damages'],
                "Other" => $row['other_details'],
            );
            
            array_push($data, $r);
        }
    }
    
    echo json_encode($data);
?>