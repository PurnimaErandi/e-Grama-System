<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();

    $id = $_POST['dataId'];

    $q = "SELECT * FROM `disaster_management` WHERE `disaster_management_id` = $id";

    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $r = array(
                "Id" => $row['disaster_management_id'],
                "Date" => $row['date'],
                "Remark" => $row['remark'],
                "Latitude" => floatval($row['loc_latitude']),
                "Longitude" => floatval($row['loc_longitude']),
                "DisasterType" => $row['disaster_type'],
                "Damages" => $row['damages'],
                "Other" => $row['other_details'],
            );
        }
    }
    
    echo json_encode($r);
?>