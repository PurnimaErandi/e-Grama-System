<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];


$date = $_POST['date'];
$remark = $_POST['remark'];
$latitude = $_POST['locLt'];
$longitude = $_POST['locLg'];
$dis_type = $_POST['disaster'];
$damages = $_POST['damages'];
$other = $_POST['other'];

$query = "INSERT INTO `disaster_management` (
  `date`,
  `remark`,
  `loc_latitude`,
  `loc_longitude`,
  `disaster_type`,
  `damages`,
  `other_details`
)
VALUES
  (
    '$date',
    '$remark',
    $latitude,
    $longitude,
    '$dis_type',
    '$damages',
    '$other'
  )";

if(mysqli_query($connection, $query)){
    echo "Disaster Details saved successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}
