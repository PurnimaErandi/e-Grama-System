<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

$id = $_POST['Id'];

$accountNo = $_POST['accNo'];
$aidTypeId = $_POST['aidType'];
$amount = $_POST['amount'];
$date = $_POST['date'];
$house_no = $_POST['houseNo'];
$name = $_POST['pName'];
$place = $_POST['place'];
$other = $_POST['other'];

$query = "UPDATE `special_aids` SET 
`account_no` = '$accountNo',
`aid_type_id` = $aidTypeId,
`amount` = $amount,
`date` = '$date',
`house_no` = '$house_no',
`name` = '$name',
`other` = '$other',
`place` = '$place' 
WHERE `special_aids_id` = $id";

if(mysqli_query($connection, $query)){
    echo "Aid Details updated successfully!";
}
else{
    echo "Error: ".mysqli_error($connection);
}
