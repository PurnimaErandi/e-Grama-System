<?php

    include '../../DB/conn.php';

    global $connection;
    session_start();
    $adminId = $_SESSION['LogId'];

    $id = intval($_POST['dataId']);

    $q = "DELETE FROM `vote_removal_mapping` 
    WHERE `person_id` = $id";

    if(mysqli_query($connection, $q)){
        echo "Person removed from vote restriction!";
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }

?>