<?php

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];


$name = $_POST["name"];
$date= $_POST["date"];
$sTime= $_POST["sTime"];
$eTime= $_POST["eTime"];
$location = $_POST["loc"];
$isPublic = $_POST["pub"];

$isPublic = $isPublic == "true" ? 1 : 0;

$query = "INSERT INTO `event` (
  `event_name`,
  `date`,
  `start_time`,
  `end_time`,
  `location`,
  `is_public`
)
VALUES
  (
    '$name',
    '$date',
    '$sTime',
    '$eTime',
    '$location',
    '$isPublic'
  )";

if(mysqli_query($connection, $query)){
    echo "New event added successfully!";
}else{
    echo "Error: ".mysqli_error($connection);
}