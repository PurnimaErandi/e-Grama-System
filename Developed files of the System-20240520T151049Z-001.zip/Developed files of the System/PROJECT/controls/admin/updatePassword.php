<?php
include '../../DB/conn.php';

global $connection;
$conn = $connection;
session_start();

$newPassword = $_POST["password"];
$oldPassword = $_POST["oldPassword"];
$id = $_SESSION['LogId'];

if(password_verify($oldPassword, getOldPassword())){
    $newPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $q = "UPDATE `user` SET `user_password` = '$newPassword' WHERE `iduser` = $id";
    if(mysqli_query($conn, $q)){
        echo 'Password successfully updated!';
    }
    else{
        echo 'Password update failded due to server error!';
    }
}
else{
    echo 'Old password is incorrect!';
}

function getOldPassword(){
    global $conn;
    global $id;
    $password;
    $q = "SELECT `user_password` FROM `user` WHERE `iduser` = $id";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $password = $row["user_password"];
        }
    }
    return $password;
}

