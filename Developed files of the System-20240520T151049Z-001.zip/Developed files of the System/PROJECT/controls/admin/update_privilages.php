<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();
    $prev = $_POST['privilage'];

    $p = json_decode($prev);


    if(addSystemDataPrivilages($p->functions->systemData) & 
    addCertificatePrivilages($p->functions->certificates) &
    addUserManagePrivilages($p->functions->userManagement) &
    addRecoveryPrivilages($p->functions->disasterRecoveryNode)){    
        echo "User privilages successfully updated!";
    }
    else{
        echo "Update failed due to server error";
    }

    function addSystemDataPrivilages($sys){
        global $p;
        global $conn;
        $prvId = getFunctionId($sys->funcName);
        $prvSubId1 = getSubfunctionId($sys->s1);
        $prvSubId2 = getSubfunctionId($sys->s2);
        $prvSubId3 = getSubfunctionId($sys->s3);
        $prvSubId4 = getSubfunctionId($sys->s4);

        $d1 = $sys->personalDetails;
        $d2 = $sys->propertyManagement;
        $d3 = $sys->workPlan;
        $d4 = $sys->aidInfo;

        $q1 = "UPDATE `privilage` SET
        `create` = ".bv($d1[0]).", `read` = ".bv($d1[1]).",
        `modify` = ".bv($d1[2]).", `delete` = ".bv($d1[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId1;

        $q2 = "UPDATE `privilage` SET
        `create` = ".bv($d2[0]).", `read` = ".bv($d2[1]).",
        `modify` = ".bv($d2[2]).", `delete` = ".bv($d2[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId2;

        $q3 = "UPDATE `privilage` SET
        `create` = ".bv($d3[0]).", `read` = ".bv($d3[1]).",
        `modify` = ".bv($d3[2]).", `delete` = ".bv($d3[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId3;

        $q4 = "UPDATE `privilage` SET
        `create` = ".bv($d4[0]).", `read` = ".bv($d4[1]).",
        `modify` = ".bv($d4[2]).", `delete` = ".bv($d4[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId4;

        return
        mysqli_query($conn, $q1) && mysqli_query($conn, $q2) &&
        mysqli_query($conn, $q3) && mysqli_query($conn, $q4);
    }

    function addCertificatePrivilages($cer){
        global $p;
        global $conn;
        $prvId = getFunctionId($cer->funcName);
        $prvSubId1 = getSubfunctionId($cer->s1);
        $prvSubId2 = getSubfunctionId($cer->s2);
        $prvSubId3 = getSubfunctionId($cer->s3);

        $d1 = $cer->charCert;
        $d2 = $cer->deathCert;
        $d3 = $cer->residCert;

        $q1 = "UPDATE `privilage` SET
        `create` = ".bv($d1[0]).", `read` = ".bv($d1[1]).",
        `modify` = ".bv($d1[2]).", `delete` = ".bv($d1[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId1;

        $q2 = "UPDATE `privilage` SET
        `create` = ".bv($d2[0]).", `read` = ".bv($d2[1]).",
        `modify` = ".bv($d2[2]).", `delete` = ".bv($d2[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId2;

        $q3 = "UPDATE `privilage` SET
        `create` = ".bv($d3[0]).", `read` = ".bv($d3[1]).",
        `modify` = ".bv($d3[2]).", `delete` = ".bv($d3[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId3;

        return
        mysqli_query($conn, $q1) && mysqli_query($conn, $q2) &&
        mysqli_query($conn, $q3);
    }

    function addUserManagePrivilages($mng){
        global $p;
        global $conn;
        $prvId = getFunctionId($mng->funcName);
        $prvSubId1 = getSubfunctionId($mng->s1);
        $prvSubId2 = getSubfunctionId($mng->s2);
        $prvSubId3 = getSubfunctionId($mng->s3);

        $d1 = $mng->users;
        $d2 = $mng->userRoles;
        $d3 = $mng->myProfile;

        $q1 = "UPDATE `privilage` SET
        `create` = ".bv($d1[0]).", `read` = ".bv($d1[1]).",
        `modify` = ".bv($d1[2]).", `delete` = ".bv($d1[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId1;

        $q2 = "UPDATE `privilage` SET
        `create` = ".bv($d2[0]).", `read` = ".bv($d2[1]).",
        `modify` = ".bv($d2[2]).", `delete` = ".bv($d2[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId2;

        $q3 = "UPDATE `privilage` SET
        `create` = ".bv($d3[0]).", `read` = ".bv($d3[1]).",
        `modify` = ".bv($d3[2]).", `delete` = ".bv($d3[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId3;

        return
        mysqli_query($conn, $q1) && mysqli_query($conn, $q2) &&
        mysqli_query($conn, $q3);
    }

    function addRecoveryPrivilages($mng){
        global $p;
        global $conn;
        $prvId = getFunctionId($mng->funcName);
        $prvSubId1 = getSubfunctionId($mng->s1);

        $d1 = $mng->disasterRecovery;

        $q1 = "UPDATE `privilage` SET
        `create` = ".bv($d1[0]).", `read` = ".bv($d1[1]).",
        `modify` = ".bv($d1[2]).", `delete` = ".bv($d1[3])."
        WHERE `role_id` = ".$p->roleId." 
        AND `prv_func_id` = ".$prvId."
        AND `prv_subfunc_id` = ".$prvSubId1;

        return mysqli_query($conn, $q1);
    }
    
    function getFunctionId($functionName){
        global $conn;
        $id = 0;
        $q = "SELECT `privilage_function_id` FROM `privilage_function` WHERE `privilage_function_name` = '{$functionName}'";
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $id = $row["privilage_function_id"];
            }
        }
        return $id;
    }

    function getSubfunctionId($subfunctionName){
        global $conn;
        $id = 0;
        
        $q = "SELECT `privilage_subfunction_id` 
        FROM `privilage_subfunction` 
        WHERE `privilage_subfunction_name` = '{$subfunctionName}'";
        
        $res = $conn->query($q);
        if($res->num_rows > 0){
            while($row = $res->fetch_assoc()){
                $id = $row["privilage_subfunction_id"];
            }
        }
        return $id;
    }

    function bv($obj){
        if($obj == ''){ return 0; } else { return 1; }
    }
?>