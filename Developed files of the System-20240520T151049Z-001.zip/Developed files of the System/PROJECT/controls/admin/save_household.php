<?php

//echo "connection income";

include '../../DB/conn.php';

global $connection;
session_start();
$adminId = $_SESSION['LogId'];

    $addressI_id     = $_POST["address_id"];
    $house_status    = $_POST["husestates"];
    $house_type      = $_POST["husetype"];
    $walls           = $_POST["wals"];
    $floor           = $_POST["flr"];
    $roofs           = $_POST["roofs"];
    $house_built_date= $_POST["date"];
    $other_details   = $_POST["text"];
    $radio           = $_POST["radio"];
    $television      = $_POST["television"];
    $landline_phones = $_POST["landline"];
    $mobile_phones   = $_POST["mobilephone"];
    $desktop_computer= $_POST["deskcomputer"];
    $laptop          = $_POST["laptop"];
    $internet_connections = $_POST["internconnctn"];
    $washing_machine      = $_POST["washmachine"];
    $refrigerator         = $_POST["refrigertr"];
    $air_conditioner      = $_POST["aircondtner"];
    $gas_cooker           = $_POST["gascooker"];
    $rice_cooker          = $_POST["ricecooker"];
    $house_name           = $_POST["hname"];

$query = "INSERT INTO `project`.`house` (
  
  `house_status`,
  `house_type`,
  `walls`,
  `floor`,
  `roofs`,
  `house_built_date`,
  `other_details`,
  `radio`,
  `television`,
  `landline_phones`,
  `mobile_phones`,
  `desktop_computer`,
  `laptop`,
  `internet_connections`,
  `washing_machine`,
  `refrigerator`,
  `air_conditioner`,
  `gas_cooker`,
  `rice_cooker`,
  `property_idproperty`,
  `house_name`
)
VALUES
  (
    
    '$house_status',
    '$house_type',
    '$walls',
    '$floor',
    '$roofs',
    '$house_built_date',
    '$other_details',
    '$radio',
    '$television',
    '$landline_phones',
    '$mobile_phones',
    '$desktop_computer',
    '$laptop',
    '$internet_connections',
    '$washing_machine',
    '$refrigerator',
    '$air_conditioner',
    '$gas_cooker',
    '$rice_cooker',
    '$addressI_id',
    '$house_name'
  )";


if(mysqli_query($connection, $query)){
    echo "1";
}else{
    echo "Error: ".mysqli_error($connection);
}

