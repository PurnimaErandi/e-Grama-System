<?php

include '../../DB/conn.php';

global $connection;
session_start();
$userId = $_SESSION['LogId'];

if(isset($_SESSION['LogId']))
    echo $userId;
else
    echo 'User not logged in!';

?>