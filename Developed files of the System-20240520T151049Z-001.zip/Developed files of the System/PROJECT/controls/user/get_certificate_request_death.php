<?php

include '../../DB/conn.php';
session_start();
global $connection;
$conn = $connection;

$sts = $_POST['status'];
$userId = $_SESSION['LogId'];

$q = "SELECT * FROM `certificate_request` "
        ."WHERE `person_id` = $userId AND `request_status` = '$sts' AND `certificate_name` = 'death_certificate'";
$res = $conn->query($q);
$requests = array();

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $r = array(
            "Id" => $row["request_id"],
            "certificate" => $row["certificate_name"],
            "reason" => $row["reason_for_request"],
            "date" => $row["request_date"],
            "status" => $row["request_status"]
        );
        
        array_push($requests, $r);
    }
}
    
echo json_encode($requests);
