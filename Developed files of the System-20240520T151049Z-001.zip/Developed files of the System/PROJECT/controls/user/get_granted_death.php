<?php
    session_start();
    include '../../DB/conn.php';
    global $connection;
    $conn = $connection;

    $id = $_POST['id'];
    
    $_SESSION['deathNic'] = getDeathNic($id);
    echo '/project/content/admin/death_certificate.php';

    function getDeathNic($id){
        global $conn;
        global $certName;
        $q = "SELECT * FROM `certificate_request` WHERE `request_id` = $id";
        $res = $conn->query($q);
        $deathNic="";

        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
                $deathNic = $row["reason_for_request"];
            }
        }
        return $deathNic;
    }
?>