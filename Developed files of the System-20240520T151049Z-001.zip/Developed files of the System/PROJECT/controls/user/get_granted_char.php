<?php
    session_start();
    include '../../DB/conn.php';
    global $connection;
    $conn = $connection;

    $id = $_POST['id'];
    $certName = $_POST['certname'];
    $nic = getPersonNic(getRequestedUserId($id));
    $personId = getPersonId($nic);
    
    $_SESSION['personId'] = $personId;
    echo '/project/content/admin/char_certificate.php';


    function getRequestedUserId($id){
        global $conn;
        global $certName;
        $q = "SELECT * FROM `certificate_request` WHERE `request_id` = $id";
        $res = $conn->query($q);
        $userId="";

        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
                $userId = $row["person_id"];
                $certName = $row["certificate_name"];
            }
        }
        return $userId;
    }

    function getPersonNic($userId){
        global $conn;
        $q = "SELECT * FROM `user` WHERE `iduser` = $userId";
        $res = $conn->query($q);
        $nic="";

        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
                $nic = $row["user_nic"];
            }
        }
        return $nic;
    }

    function getPersonId($nic){
        global $conn;
        $q = "SELECT * FROM `person` WHERE `nic` = '$nic'";
        $res = $conn->query($q);
        $personId="";

        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
                $personId = $row["idperson"];
            }
        }
        return $personId;
    }

?>