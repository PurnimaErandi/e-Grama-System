<?php

include '../../DB/conn.php';

global $connection;
session_start();
$userId = $_SESSION['LogId'];

$rate = $_POST['rate'];
$type = $_POST['type'];
$feedback = $_POST['feedback'];
$senderId = $_POST['isAnnonymous'] == 'true' ? 0 : $userId;
$date = date("Y/m/d");


$query = "INSERT INTO `feedback` (
  `rate`,
  `feedback_type`,
  `feedback`,
  `sender_id`,
  `date`
)
VALUES
  (
    $rate,
    '$type',
    '$feedback',
    $senderId,
    '$date'
  )";

if(mysqli_query($connection, $query)){
    $a = array("title"=>"Feedback Sent", "msg"=>"Your feedback successfully posted!", "s"=>"success");
    echo json_encode($a);
}
else{
    $a = array("title"=>"Feedback Failed", "msg"=>mysqli_error($connection), "s"=>"error");
    echo json_encode($a);
}