<?php
    include '../../DB/conn.php';
    global $connection;
    session_start();
    $userId = $_SESSION['LogId'];

    $request_id = $_POST['request_id'];

    $query = "DELETE FROM `certificate_request` WHERE `request_id` = $request_id";

    if(mysqli_query($connection, $query)){
        $a = array("title"=>"Action Complete!", "msg"=>"Request successfully deleted!", "s"=>"success");
        echo json_encode($a);
    }
    else{
        $a = array("title"=>"Action Fail!", "msg"=>"Request could not be deleted!", "s"=>"error");
        echo json_encode($a);
    }
?>