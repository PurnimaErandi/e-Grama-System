<?php

include '../../DB/conn.php';

global $connection;
session_start();
$userId = $_SESSION['LogId'];

$reason = $_POST['reason'];
$personId = $userId;
$date = date('Y-m-d');
$certName = $_POST['certName'];
$status = 'pending';

if(isAlreadyRequetsed()){
    $a = array("title"=>"Request Already Sent","msg"=>"You already requested this certificate!", "s"=>"warning");
    echo json_encode($a);
}
else{

    $query = "INSERT INTO `certificate_request` (
      `certificate_name`,
      `person_id`,
      `reason_for_request`,
      `request_date`,
      `request_status`
    )
    VALUES
      (
        '$certName',
        '$personId',
        '$reason',
        '$date',
        '$status'
      )";

    if(mysqli_query($connection, $query)){
        $a = array("title"=>"Request Sent", "msg"=>"Request successfully sent! <br/>You will be notified!", "s"=>"success");
        echo json_encode($a);
    }
    else{
        echo "Error: ".mysqli_error($connection);
    }
}

function isAlreadyRequetsed(){
    global $connection;
    global $status;
    global $userId;
    $q = "SELECT * FROM `certificate_request` WHERE `person_id` = $userId AND `request_status` = '$status'";
    
    $res = $connection->query($q);

    return mysqli_num_rows($res) > 0;
}