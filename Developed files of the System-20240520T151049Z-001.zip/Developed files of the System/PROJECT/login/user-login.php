<?php
session_start();
if (isset($_SESSION['LogId'])) {
    if ($_SESSION['LogId'] != '') {
        header('Location:../user-index.php');
    }
}
?> 

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js" type="text/javascript"></script>
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="../css/styleStartup.css">
        <link href="../css/custome/style.css" rel="stylesheet">

        <link href="../css/custome/animation.css" rel="stylesheet">
        <script src="../js/custome/userMainFunc.js"></script>
        <script src="../js/custome/alert.js"></script>
       

        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

        <title>Login</title>
        <style>
            body{
                background: url('https://images6.alphacoders.com/689/689305.jpg') no-repeat center fixed;
                background-size: cover;
            }
            .block-well{
                width:670px;
                max-width: 90vw;
                padding: 20px;
                position: absolute;
                background-color: #fff;
                border-radius: 5px;
                color:black;
                top: 50%;
                left: 50%;
                -ms-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
            }
            .customBtn{
                background-color:#002752;
                color:#fff;
                border-radius: 0;
                height:30px;
            }
            .customBtn{
                background-color:#004085;
            }
        </style>
    </head>
    <body>
        <div class="overlayMsg" id="alertPoint">
            <div id="alert" class="zoomInDown">
                <a class="btn btn-danger" id="alertCloseTop" style="float: right;"><i class="fa fa-close"></i></a>

                <div style="margin-top: 20px;padding: 20px;">
                    <center>
                        <p id="alertMsg">
                        </p>
                    </center>
                    <center id="customizedBtn">
                        <a class="btn btn-primary" id="alertClose" >Ok</a>
                    </center>
                </div>
            </div>
        </div>
        <div class='block-well zoomIn' style="min-height:360px; max-height:550px;box-shadow: 2px 2px 4px 4px;">
            <center><h2><b>WELCOME TO  E-GRAMA SYSTEM!</b></h2> </center>
            <hr>
            <p>Please login to continue</p>
            <form id='loginToDash' enctype="multipart/form-data" method="POST" role="form" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']);
?> ">
                <div class='form-group'>
                    <input type='text' class='form-control' name='admin_login_mail' placeholder="Username" >
                </div>
                <span class="val" id="username" style="color: red; margin-bottom: 1rem; display:inline-block"></span>

                <div class='form-group'>
                    <input type='password' class='form-control' name='admin_login_password' placeholder="Password">
                </div>
                <span class="val" id="password" style="color: red; margin-bottom: 1rem; display:inline-block"></span>

                <h6 id="server-val" style="color: red;"> 
                    <?php
                    include '../DB/conn.php';
                    global $connection;
                    if (isset($_POST['admin_login_mail']) && isset($_POST['admin_login_password'])) {
                        $uname = $_POST['admin_login_mail'];
                        $password = $_POST['admin_login_password'];

                        $query = "SELECT
                                `user`.`user_fullname`
                                ,`user`.`user_password`
                                ,`user`.`iduser`
                                , r.`role_name`
                                , r.`role_id`
                                , `user`.`user_nic`
                                , `user`.`user_email`
                            FROM
                                `project`.`user`
                                INNER JOIN `project`.`role` r
                                ON (`user`.`user_role_iduser_role` = r.`role_id`)
                            WHERE `user`.`user_uname` = '$uname' AND r.role_name = 'User'";

                        $result = mysqli_query($connection, $query);
                        $row = mysqli_fetch_array($result);

                        if (mysqli_num_rows($result) == 1) {
                            if (password_verify($password, $row['user_password'])) {

                                $_SESSION['LogId'] = $row['iduser'];
                                $_SESSION['fullName'] = $row['user_fullname'];
                                $_SESSION['email'] = $row['user_email'];
                                $nic = $row['user_nic'];

                                if(!isExistPerson($row['user_email'], $nic)){
                                    $_SESSION['LogId'] = null;
                                    echo('Cannot login because your person profile does not exist!');
                                }
                                else{
                                    header('Location:../user-index.php');
                                }
                                
                            } else {
                                echo "Invalid password";
                            }
                        } else {
                            echo "Invalid username";
                        }
                    }

                    function isExistPerson($email, $nic){
                        global $connection;
                        $q = "SELECT * FROM `person` WHERE `email` = '$email' AND `nic` = '$nic'";
                        $r = mysqli_query($connection, $q);
                        return mysqli_num_rows($r) > 0;
                    }
                    ?>

                </h6>
                <input type='submit' class='btn btn-primary btn-block' value='Login'>
                <input type='button' class='btn btn-success btn-block' onclick='location.href = "../home.html"' value='Home' style="margin-top: 20px;">
            </form>
            <br>

            <center>
                &COPY; <script>document.write(new Date().getFullYear())</script> |  All Rights Reserved.
            </center>
        </div>
        <script>
            const form = document.getElementById('loginToDash');
            
            var uErr = false;
            var pErr = false;

            form.addEventListener('submit', e => {
                $('#server-val').html('');

                var u = $('input[name="admin_login_mail"]').val();
                var p = $('input[name="admin_login_password"]').val();
                
                if(u == ''){
                    e.preventDefault();
                    $('#username').html('Username is required');
                }
                else
                    $('#username').html('');

                if(p == ''){
                    e.preventDefault();
                    $('#password').html('Password is required');
                }
                else
                    $('#password').html('');
            });

            $('input[name="admin_login_mail"]').on('keyup change', () => {
                if($('input[name="admin_login_mail"]').val() == ''){
                    $('#username').html('Username is required');
                }
                else
                    $('#username').html('');
            });

            $('input[name="admin_login_password"]').on('keyup change', () => {
                if($('input[name="admin_login_password"]').val() == ''){
                    $('#password').html('Password is required');
                }
                else
                    $('#password').html('');
            });
        </script>
    </body>
</html>
