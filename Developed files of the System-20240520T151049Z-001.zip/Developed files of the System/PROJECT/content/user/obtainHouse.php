<div class="container" style="background-color:#e6eafc">
        <br>
        <h3 class="heading" style="text-align:center"><b>Obtaining Housing Relief in the Case of Damage Sustained in Disaster</b></h3>
        <hr>

        <!-- Obtaining Housing Relief in the Case of Damage Sustained in Disaster -->
        <div class="section">
            <div class="section-content">
                    <div class="row">
                            <ol>
                                <li><b>Eligibility:</b> Complete or partial damage to one’s only house due to national disaster.</li><br>
                                <li><b>Process of Submitting Applications: </b>Immediately on occurrence of the disaster the form Nation Disaster Relief No.07 should be obtained from the Grama Niladhari and handed over to the Grama Niladhari duly perfected</li><br>
                                <li><b>Places From Where Application can be Obtained:</b> Area Grama Niladhari office / Divisional secretariat</li><br>
                                <li><b>Fees Payable for Obtaining Application:</b> No fees in charged.</li><br>
                                <li><b>Time at Which Applications Submitted:</b> Immediately after the disaster.</li><br>
                                <li><b>Fees Payable for Obtaining the Service:</b> No fees charged</li><br>
                                <li><b>Time Taken to Provide the Service (Ordinary Service and Priority Service): </b> With in one week recommendation of Grama Niladhari</li><br>
                                <li><b>Supporting Documents Required</b> </li><br>
                                    <ul style="list-style-type:disc;">
                                        <li>National disaster relief service form no 7, NDRS with recommendation by Grama Niladhari , Social Services Officer (Form No7 NDRS with recommendation by Grama Niladhari, Social Services Officer.)</li><br>
                                        <li>Valuation letter of Damage properties.</li><br>
                                        <li>Confirm letter of land/ of house</li><br>
                                    </ul>
                                <li><b>Officers in charge of the Service</b> </li><br>
                                    <ul style="list-style-type:disc;">
                                        <li>Divisional Secretary</li><br>
                                        <li>Assistant Divisional Secretary</li><br>
                                    </ul>
                                <li><b>Exception or Instances Deviation From the Above Requirement and Special Information:</b> Not applicable</li><br>
                            </ol>
                    </div>
            </div>
        </div>
        <hr>
        <!--Organization Information-->
        <div class="col-lg-12">
            <div style="text-align:center;">
                <h6><b>Organization Information</b></h6>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group col-lg-9" style="float:left">
                        <p style="font-size: 1em;">
                            National Disaster Relief Services Centre,<br>
                            Vidya Mawatha,<br>
                            Colombo 7.<br>
                        </p>        
                    </div>
                    <div class="form-group col-lg-3" style="float:left">
                        <p style="font-size: 1em;" >
                            <b>Telephones:</b>+94112665258<br>
                            <b>Fax Nos:</b>+94112665702<br>
                            <b>Website:</b> www.ndrsc.gov.lk
                        </p>        
                    </div>
                </div>
            </div>    
        </div>
        <br>

</div>