<div class="col-lg-12">
    <h2>Registered Organizations</h2>
    <hr>
    <br>
    
    <div class="table-responsive">
        <table class="table table-striped ">
            <thead class="thead-dark">
                <tr>
                <th scope="col">#</th>
                <th scope="col">GN Division</th>
                <th scope="col">Name of the Organization</th>
                <th scope="col">Address</th>
                <th scope="col">Register No</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>214-Western Narangodapaluwa</td>
                    <td>Samagi Funaral Aid Society</td>
                    <td>Western Narangodapaluwa</td>
                    <td>WA/KURU/POPI/SA.SE.SA/341/187</td>
                </tr>
                <tr>
                    <th scope="row">2</th>
                    <td></td>
                    <td>Sirisagabo Elder's Organization</td>
                    <td>Western Narangodapaluwa</td>
                    <td>NWP/2011/06/6127085</td>
                </tr>
                <tr>
                    <th scope="row">3</th>
                    <td></td>
                    <td>Narangodapaluwa Farmer's Organization</td>
                    <td>Western Narangodapaluwa</td>
                    <td>DAD/17/14/37</td>
                </tr>
                <tr>
                    <th scope="row">4</th>
                    <td></td>
                    <td>Perakum Welfare Society</td>
                    <td>Western Narangodapaluwa</td>
                    <td>WA/KURU/POPI/SA.SE.SA/340/47</td>
                </tr>
                <tr>
                    <th scope="row">5</th>
                    <td></td>
                    <td>Dimuthu Women Working Organization</td>
                    <td>Western Narangodapaluwa</td>
                    <td>WB/KURU/POPI/338/056</td>
                </tr>
                <tr>
                    <th scope="row">6</th>
                    <td></td>
                    <td>Prabhashwara Youth Society</td>
                    <td>Western Narangodapaluwa</td>
                    <td>WAYA/KURU/POPI/5027</td>
                </tr>
                <tr>
                    <th scope="row">7</th>
                    <td></td>
                    <td>Suhada Rural Develoment Society</td>
                    <td>Western Narangodapaluwa</td>
                    <td> KU/1681</td>
                </tr>
                <tr>
                    <th scope="row">8</th>
                    <td>215-Eastern Narangodapaluwa</td>
                    <td>Saliya Funeral Aid Society</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>WA/KURU/POPI/SA.SE.SA/344/217</td>
                </tr>
                <tr>
                    <th scope="row">9</th>
                    <td></td>
                    <td> Gemunu Welfair Society</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>WAPA/KURU/POPI/SA.SE.SA/345/230</td>
                </tr>
                <tr>
                    <th scope="row">10</th>
                    <td></td>
                    <td>United Farmer's Organization</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>WAPA/KURU/529/GASAN/07</td>
                </tr>
                <tr>
                    <th scope="row">11</th>
                    <td></td>
                    <td>Shakthi Women Society</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>WB/KURU/POLPI/355/050</td>
                </tr>
                <tr>
                    <th scope="row">12</th>
                    <td></td>
                    <td>Agro Crop Manufacturers organization</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>DAD/17/13/74</td>
                </tr>
                <tr>
                    <th scope="row">13</th>
                    <td></td>
                    <td>Rural Development Society</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>NWPN/MSW/RD/PV/58</td>
                </tr>
                <tr>
                    <th scope="row">13</th>
                    <td></td>
                    <td>Mathika Matha Women Society</td>
                    <td>Eastern Narangodapaluwa</td>
                    <td>WAPO/KURU/POPI/SASESA/41178</td>
                </tr>
            </tbody>
        </table>
    </div>
<style>
    h4 {
        font-size: 1.2rem;
    }
    h5{
       font-size: 1.1rem;  
    }
    .data-container{
        height: 250px;
        background-color: white;
        padding: 10px;
        border-radius: 5px;
        box-shadow: 0px 0px 4px 5px rgba(5,5,5,0.1);
        overflow-y: scroll;
    }  
    
</style>    