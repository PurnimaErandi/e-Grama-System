
    <div class="container">
        
        <div class="row header">
            <div class="col-md-8 header-topic">
                Request Death Certificate
            </div>
            <div class="col-md-4 header-button-box">
                <button title="Request New Certificate" class="req-cert" id="req-cert"><i class="fa fa-share-square"></i></button>
            </div>
        </div>

        <div class="row">
            <div class="col-1" style="text-align:right">
                Status
            </div>
            <div class="col-11">
                <select class="form-control form-control-sm" id="status">
                    <option value="pending">Pending</option>
                    <option value="granted">Granted</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
        </div>
        
        <div class="content">
            <table class="table table-striped" id="data">
                <thead>
                    <tr>
                        <th scope="col">Action</th>
                        <th scope="col">Certificate</th>
                        <th scope="col">Description</th>
                        <th scope="col">Date</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody class="req-table">
    
                </tbody>
            </table>
        </div>
        <div class="banner hide">
            <div class="banr-cont">
                <div>
                    <i class="fa fa-exclamation-triangle"></i>
                </div>
                <div>
                    No pending account requests
                </div>
            </div>
        </div>

    </div>

    <style>
        .header{
            margin: 10px 0;
            margin-bottom: 30px;
            background-color: #eee;
            border-radius: 10px;
        }

        .header-topic{
            line-height: 3;
            font-size: 1.2rem;
            font-weight: 500;
        }

        .header-button-box{
            text-align: right;
            line-height: 3;
        }

        .req-cert{
            border: none;
            background-color: argb(0 0 0 0);
            color: rgb(100, 100, 100);
            font-size: 1.2rem;
            transition: 0.4s;
            cursor: pointer;
        }

        .req-cert:hover{
            color: #17b857;
        }
        .content{
            overflow-y: auto;
            margin: 15px;
        }
        .banner{
            background-color: #eee;
            padding: 20px;
            margin: auto 20px;
            text-align: center;
            font-size: 1rem;
            font-weight: 500;
            color: #555;
            border-radius: 7px;
        }
        .banner .icon{
            margin: auto;
        }
        .banner i{
            font-size: 2rem;
            color: orange;
        }
        .hide{
            display: none;
        }
        .ver{
            border: none;
            background-color: inherit;
            width: 32px;
            height: 32px;
            color: #17b857;
            border-radius: 16px;
            transition: 0.5s;
            cursor: pointer;
        }
        .ver:hover{
            background-color: #17b857;
            color: white;
        }
        .rem{
            border: none;
            background-color: inherit;
            width: 32px;
            height: 32px;
            color: #e22a2a;
            border-radius: 16px;
            transition: 0.5s;
            cursor: pointer;
        }
        .rem:hover{
            background-color: #e22a2a;
            color: white;
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(() => {
            loadRequests("pending");

            $('#status').change(() => { loadRequests($("#status").val())})
            $('#req-cert').click(() => { sendRequest(); })
        })

        function loadRequests(status){
            var x;
            var dt = new FormData();
            dt.append('status', status);
            
            $.ajax({
                type: 'post',
                url: './controls/user/get_certificate_request_death.php',
                processData: false,
                contentType: false,
                cache: false,
                data: dt,
                success: function(res){
                    x = JSON.parse(res);
                },
                error: function(){
                    alert('No');
                },
                complete: function(){
                    fillItems(x);
                }
            });
        }

        function fillItems(a){
            var b = $('.banner');
            if(a == undefined || a == null){
                b.show();
                return;
            }
            var tb = $('.req-table');
            tb.empty();

            $.each(a, i => {
                var btns = '', status = '', title = '';
                if(a[i].status == 'granted')
                    btns = `<button title="View" class="ver" onclick="view(${a[i].Id})"><i class="fa fa-eye"></i></button>`;

                switch(a[i].status){
                    case 'pending': status = `<span class="badge badge-warning">Pending</span>`; title = 'Cancel Request'; break;
                    case 'granted': status = `<span class="badge badge-success">Granted</span>`; title = 'Delete'; break;
                    case 'rejected': status = `<span class="badge badge-danger">Rejetced</span>`; title = 'Delete'; break;
                    default: status = `<span class="badge badge-secondary">${a[i].status}</span>`; title = 'Delete'; break;
                }

                var row = `
                <tr>
                    <td>
                        ${btns}
                        <button title="${title}" class="rem" onclick="remove(${a[i].Id})"><i class="fa fa-minus-circle"></i></button>
                    </td>
                    <td>${a[i].certificate}</td>
                    <td>${a[i].reason}</td>
                    <td>${a[i].date.toString().replace('00:00:00', '')}</td>
                    <td>${status}</td>
                </tr>`;
                tb.append(row);
            });
        }

        function verify(id){
            Swal.fire({
                title: 'Respond to Request',
                text: 'Do you want to grant this certificate to the user?',
                showDenyButton: true,
                showCloseButton: true,
                confirmButtonText: 'Yes',
                denyButtonText: 'No',
                confirmButtonColor: '#17b857',
                allowEscapeKey: false,
                allowOutsideClick: false
            }).then(r => {
                if(r.isConfirmed){
                    Swal.fire({ 
                        title: `Id ${id} Confirmed`,
                        confirmButtonColor: '#17b857'
                    });
                }
                else if(r.isDenied){
                    Swal.fire({
                        title: `Id ${id} Denied`,
                        confirmButtonColor: '#dd3333'
                    });
                }
            });
        }

        function view(id){
            var data = new FormData();
            data.append('id', id);

            $.ajax({
                type: 'post',
                url: './controls/user/get_granted_death.php',
                processData: false,
                contentType: false,
                data: data,
                cache: false,
                success: function(res){
                    window.open(res);
                },
                error: function(){
                    alert('No');
                }
            })
        }

        function remove(id){
            var data = new FormData();
            data.append('request_id', id);

            $.ajax({
                type: 'POST',
                url: './controls/user/delete_certificate_request.php',
                contentType: false,
                processData: false,
                data: data,
                success: function(res){
                    var r = JSON.parse(res);
                    Swal.fire({
                        title: r.title,
                        html: r.msg,
                        icon: r.s,
                        showCloseButton: false,
                        confirmButtonColor: '#495057',
                        allowEscapeKey: false,
                        allowOutsideClick: false,
                        timer: 3000
                    });
                },
                error: function(){
                    Swal.fire({
                        title: 'Something went wrong!',
                        html: 'Could not communicate with server!',
                        icon: 'error',
                        showCloseButton: false,
                        confirmButtonColor: '#17b857',
                        allowEscapeKey: false,
                        allowOutsideClick: false,
                    });
                }
            });
        }

        async function sendRequest(){
            const { value: rsn } = await Swal.fire({
                title: 'Request Certificate',
                html: `Add NIC of demised person<br/>(Enter Child Registration No if a child)`,
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: '#17b857',
                confirmButtonText: 'Send Request',
                input: 'text',
                inputPlaceholder: 'NIC or Child Reg No',
                inputValidator: (value) => {
                    if (!value) {
                        return 'Demised person\'s NIC/RegNo is required'
                    }
                },
                inputAttributes: {
                    'autocomplete': 'off'
                }
            });

            if(rsn){
                var d;
                var x = new FormData();
                x.append('reason', rsn);
                x.append('certName', 'death_certificate');

                $.ajax({
                    type: 'post',
                    url: './controls/user/send_certificate_request.php',
                    processData: false,
                    contentType: false,
                    data: x,
                    cache: false,
                    success: function(res){
                        d = JSON.parse(res);
                    },
                    error: function(){
                        alert('No');
                    },
                    complete: function(){
                        Swal.fire({
                            title: d.title,
                            html: `${d.msg}`,
                            icon: d.s,
                            showConfirmButton: false
                        });
                    }
                });
            }
        }
    </script>