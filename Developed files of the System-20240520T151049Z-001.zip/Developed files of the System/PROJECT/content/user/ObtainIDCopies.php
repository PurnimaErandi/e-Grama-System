    <div class="container" style="background-color:#e6eafc">
        <br>
        <h3 class="heading" style="text-align:center"><b>Obtaining Duplicate Identity Card Copies</b></h3>
        <hr>
        <div class="sub-text">
            <h5><b>Request for a Duplicate in respect of a lost ID card.</b></h5>
        </div>
        <br>
            <!-- Obtaining an Application -->
            <div style="margin-left: 3px;">
                <div class="section">
                        <div class="section-heading" style="font-size:1rem;!important;"><b>Obtaining an Application</b></div><br>
                        <div class="section-content" style="margin-left: 20px;">
                            <div class="row">
                                <ol>
                                        <li>From the Grama Niladhari of the applicant’s residential area;</li><br>
                                        <li>From the Estate superintendant (if the applicant resides in an estate);</li> 
                                </ol>
                            </div>
                        </div>
                </div>
            </div>
            <!-- Documents required obtaining a duplicate ID: -->
            <div style="margin-left: 3px;">
                <div class="section">
                        <div class="section-heading" style="font-size:1rem;!important;"><b>Documents required obtaining a duplicate ID:</b></div><br>
                        <div class="section-content" style="margin-left: 20px;">
                            <div class="row">
                                <ol>
                                        <li>Duly completed RPD Form 7.</li><br>
                                        <li>Original copy of the complaint lodged in the Police Station to state that the NIC has been lost. This complaint should be lodged during last six month.</li><br>
                                        <li>Five colour photographs of the size of 1 ⅜” X ⅞”.</li><br>
                                        <li>Stamps to a value of Rs. 15/=.</li><br>
                                        <li>riginals of Birth Certificate, Probable Age Certificate or the “results of search of registers”.</li><br>
                                            <p>(Applicant who forward the “results of search of registers”, need to be submitted an affidavit obtained from Justice of Peace (JP) and two or more following documents along with to confirm the date of birth.)</p>
                                        <ul style="list-style-type:disc;"> 
                                            <li>School leaving certificate</li>
                                            <li>Certificate of Baptism</li>
                                            <li>Copies of Birth certificates of children of the applicant, (if the date of birth of the applicant indicated )</li>
                                            <li>Extract of the birth certificate of the applicant</li>
                                            <li>Citizenship certificate of Sri Lanka (if the date of birth indicated)</li>
                                            <li>Estate leaving certificate (if the date of birth indicated)</li>
                                            <li>Certified copies of relevant pages of the Passport</li>
                                            <li>Registration card issued by the Estate Superintendent</li>
                                            <li>Horoscope (if available)</li>
                                        </ul><br>
                                        <li>Applicants, who wish to include their occupation/designation in the ID card, should submit a service certificate obtained during the last three months. Professionals also need to submit documentary evidence, in case if they wish to include their profession in the ID card.(I.e. Engineers, Doctors, Accountants, Lawyers should submit relevant Degree certificates). In case of the Businessmen, they need to submit a certified copy of the Business Registration certificate.</li><br>
                                        <li>Documentary evidence such as Passport, Bank Book, Driving License etc. to certify that the number of lost ID has been used in the past.</li><br>
                                        <li>Grama Niladhari certificate to confirm the residential place.</li><br>
                                        <li>Procedure to be confirm the Priest status of applicants-</li><br>
                                        <ul style="list-style-type:disc;">    
                                            <li>Buddhist cleric should submit the “Certificate of Ordain” or “Upasampada Certificate” issued by the Department of Buddhist Affairs</li> 
                                            <li>“Dasasil Matha” should submit the registration certificate issued by the Department of Buddhist Affairs</li>
                                            <li>Islamic priest should submit the certificate issued by the Department of Islamic Religious Affairs</li>
                                            <li>Hindu priest should submit the certificate issued by the Department of Hindu Religious Affairs</li>
                                            <li>Catholic priest should submit certificate issued by the head of relevant catholic religious chapters</li>
                                        </ul>
                                </ol>
                            </div>
                        </div>
                </div>
            </div>
            <hr>
            <!--Organization Information-->
            <div class="col-lg-12">
                <div style="text-align:center;">
                    <h6><b>Organization Information</b></h6>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group col-lg-9" style="float:left">
                            <p style="font-size: 1em;">
                                    Department of Registration of Persons,<br>
                                    10th Floor,<br>
                                    "Suhurupaya",<br>
                                    Sri Subhuthipura Road,<br>
                                    Battaramulla.<br><br>
                            </p>        
                        </div>
                        <div class="form-group col-lg-3" style="float:left">
                            <p style="font-size: 1em;" >
                                Mr. T.D. Koralegedara<br>
                                <b>Telephones:</b>+94-11-5226100<br>
                                <b>Fax Nos:</b>+94-11-2862290<br>
                                <b>Email:</b>info@drp.gov.lk<br>
                                <b>Website:</b> www.drp.gov.lk
                            </p>        
                        </div>
                    </div>
                </div>    
            </div>
        <br>
    </div>