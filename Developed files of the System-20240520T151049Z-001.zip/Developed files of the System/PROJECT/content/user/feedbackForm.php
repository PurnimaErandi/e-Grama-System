
    <div class="container">
        <h2>Feedback</h2>
        <hr>
        <div class="feedback-container">
            <div class="feedback-header"><b><span>eGrama</span></b></div>
            <div class="feedback-body">
                <div class="text center">
                    <h6>We would like to hear your thoughts, suggestions,
                    compliments and complaints with anything so we can 
                    improve!.</h6>
                </div>
                <br />
                <div class="text center">
                    <b>What is your thought?</b>
                </div>
                <br />
                <div class="feedback-buttons">
                    <button data-mood="1" id="m1" class="fbtn"><i class="fa fa-angry _1"></i></button>
                    <button data-mood="2" id="m2" class="fbtn"><i class="fa fa-frown-open _2"></i></button>
                    <button data-mood="3" id="m3" class="fbtn"><i class="fa fa-meh _3"></i></button>
                    <button data-mood="4" id="m4" class="fbtn"><i class="fa fa-smile _4"></i></button>
                    <button data-mood="5" id="m5" class="fbtn"><i class="fa fa-grin _5"></i></button>
                </div>
                <div class="val center" id="moodVal"></div>

                <hr>

                <div class="row center">
                    <div class="col-12">
                        <label><b>Please select your feedback category below.</b></label>
                        <select class="form-control" id="type">
                            <option value="" disabled selected>- Please Select -</option>
                            <option value="Suggestion">Suggestion</option>
                            <option value="Complement">Complement</option>
                            <option value="Complaint">Complaint</option>
                        </select>
                        <span class="val" id="typeVal"></span>
                    </div>
                </div>

                <hr>

                <div class="row center">
                    <div class="col-12">
                        <label><b>Please leave your feedback below.</b></label>
                        <textarea class="form-control" id="feed" placeholder="Your Feedback..."></textarea>
                        <span class="val" id="feedVal"></span>
                    </div>
                </div>
                
                <div class="row right">
                    <div class="col-12">
                        <div class="control-box">
                            <input type="checkbox" id="sendAnon"> <label style="margin-right: 20px;" for="sendAnon">Send anonymously</label>
                            <button class="action-btn" id="submit"><b>Submit</b></button>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="css/feedback.css">
    <script src="js/feedback.js"></script>
