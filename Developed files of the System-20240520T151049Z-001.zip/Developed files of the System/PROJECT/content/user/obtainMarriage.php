
<div class="container" style="background-color:#e6eafc">
    <br>
    <h3 class="heading" style="text-align:center"><b>Obtain a Certified Copy of the Certificate of Marriage</b></h3>
    <hr>
    <br>

    <!-- Obtain a Certified Copy of the Certificate of Marriage -->
    <div>
        <div class="section" >
            <div class="sub-text" style="margin-left:-2px;"></div>       
                <div class="section-content" style="margin-left:20px;">
                    <div class="row">
                        <ol>
                            <li>Refer the certificate of marriage application to the Divisional Secretariat of the area where the registration took place.</li><br>
                            <li>Application can obtain from any Divisional Secretariat.</li><br>
                            <li>Fees chargeable</li><br>
                                <ul style="list-style-type:disc;">
                                    <li>Where the date of  registration or the no. of the entry is given the fee for one copy of the certificate is Rs.100.00</li><br>
                                    <li>Where the date of  registration or the no. of the entry is not given and a search of registers not exceeding two years is involved fee for one copy of the certificate is Rs.200.00</li><br>
                                </ul>
                            <li>Required fee should submit to the Divisional Secretariat.</li><br>
                            <li>Duly filled the certificate of marriage application should be submit to the Divisional Secretariat.</li><br>
                            <li>If you like to obtain the certificate of marriage by post, submit a stamped envelop with the application.</li><br>
                            <li>f the marriage is registered, a certificate of marriage will be send and if the marriage is not registered a letter to the effect will be send.</li><br>
                        </ol>
                    </div>
                    <hr>
                    <!--Organization Information-->
                    <div class="col-lg-12">
                        <div style="text-align:center;">
                            <h6><b>Organization Information</b></h6>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group col-lg-7" style="float:left">
                                    <p style="font-size: 1em;">
                                        Department of Registrar General,<br>
                                        No: 234 /A3,<br>
                                        Denzil Kobbakaduwa Mawatha,<br>
                                        Battaramulla.<br><br>
                                    </p>        
                                </div>
                                <div class="form-group col-lg-5" style="float:left">
                                    <p style="font-size: 1em;" >
                                        Ms. Buddhika Nilanthi Ranaweera<br>
                                        <b>Telephones:</b>+94-11-2889488 / +94-11-2889489<br>
                                        <b>Fax Nos:</b>+94-11-2889491<br>
                                        <b>Email:</b>info@rgd.gov.lk<br>
                                        <b>Website:</b> www.rgd.gov.lk<br>
                                    </p>        
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
        </div>
        <br>
</div>