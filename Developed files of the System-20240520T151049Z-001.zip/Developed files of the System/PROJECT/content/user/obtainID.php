    <div class="container" style="background-color:#e6eafc">
        <br>
        <h3 class="heading" style="text-align:center"><b>Obtaining a New Identity Card</b></h3>
        <hr>
        <div class="sub-text">
            <h5>Obtaining a National Identity Card (NIC) for the first time.</h5>
        </div>
        <br>
        
        <!-- 1. Eligibility criteria to apply for ID -->
        <div style="margin-left: 20px;">
            <div class="section">
                    <div class="section-heading" style="font-size:1rem;!important;">1. Eligibility criteria to apply for an ID for the first time</div>
                    <div class="section-content">
                        <div class="row">
                            <ul style="list-style-type:disc;">
                                    <li>Should be a citizen of Sri Lanka.</li>
                                    <li>Should be attained 16 years of age.</li> 
                            </ul>
                        </div>
                    </div>
            </div>
            <!-- 2. Obtaining an Application -->
            <div class="section">
                    <div class="section-heading">2. Obtaining an Application</div>
                    <div class="section-content">
                        <div class="row">
                            <ul style="list-style-type:disc;">
                                    <li>From the Grama Niladhari of the applicant’s residential area;</li>
                                    <li>From the Estate superintendant (if the applicant resides in an estate);</li>
                                    <li>From the School Principal or the “Parivenadhipathi” of the respective Pirivena in the case of school applications.</li> 
                            </ul>
                        </div>
                        <p>Completed application along with the relevant documents should be handed over to the above respective officers as appropriate.</p>
                    </div>
            </div>
        </div>
         <!-- 3. Necessary documents-->
        <div>
            <div class="section" >
                    <div class="sub-text" style="margin-left:-2px;">
                        <h5>Necessary documents to be submitted to obtain an ID for the first time:</h5>
                    </div>
                        
                    <div class="section-content" style="margin-left:20px;">
                        <div class="row">
                            <ol>
                                    <li>Duly completed RPD Form 1.</li>
                                    <li>Applicants under 50 years of age should compulsorily submit the Birth Certificate (BC) or the Probable Age Certificate issued by the Additional District Registrar in order to obtain an ID card.</li>

                                        <ul style="list-style-type:disc;">
                                            <li>The Department considers 1st of July of the respective year as the date of birth in respect of the applicants who submit probable age certificates.</li>
                                        </ul>

                                    <li>Applicants over 50 years of age and do not possess the birth certificate or the probable age certificate, could submit two or more following alternative documents along with the results of search of registers and an Affidavit to confirm the age.</li> 

                                        <ul style="list-style-type:disc;">
                                            <li>School leaving certificate</li>
                                            <li>Certificate of Baptism</li>
                                            <li>Copies of Birth certificates of children of the applicant, (if the date of birth of the applicant indicated )</li>
                                            <li>Extract of the birth certificate of the applicant</li>
                                            <li>Citizenship certificate of Sri Lanka (if the date of birth indicated)</li>
                                            <li>Estate leaving certificate (if the date of birth indicated)</li>
                                            <li>Certified copies of relevant pages of the Passport</li>
                                            <li>Registration card issued by the Estate Superintendent</li>
                                            <li>Horoscope (if available)</li>
                                        </ul>

                                    <li>Applicants born in a foreign country should submit the citizenship certificates issued by the Department of Immigration & Emigration of Sri Lanka.</li>
                                    <li>Women applicants, who wish to include husband’s family name in the ID card need to submit the original & a copy of the marriage certificate.</li>
                                    <li>Five colour photographs of the size of 1 ⅜” X ⅞”.</li>
                                    <li>Stamp fees</li>

                                        <ul style="list-style-type:disc;">
                                                <li>Stamps to a value of Rs. 3/= for the applicants under 17 years of age.</li>
                                                <li>Stamps to a value of Rs. 13/= for the applicants over 17 years of age.</li>  
                                        </ul>
                                    
                                    <li>Applicants, who wish to include their occupation/designation in the ID card, should submit a service certificate obtained during the last three months. Professionals also need to submit documentary evidence, in case if they wish to include their profession in the ID card. (I.e. Engineers, Doctors, Accountants, Lawyers should submit relevant Degree certificates). In case of the Businessmen, they need to submit a certified copy of the Business Registration certificate.</li>
                                    <li>Procedure to confirm the Priest status of applicants-</li>    

                                        <ul style="list-style-type:disc;">
                                                <li>Buddhist cleric should submit the “Certificate of Ordain” or “Upasampada Certificate” issued by the Department of Buddhist Affairs</li>
                                                <li>“Dasasil Matha” should submit the registration certificate issued by the Department of Buddhist Affairs</li>  
                                                <li>Islamic priest should submit the certificate issued by the Department of Islamic Religious Affairs</li>
                                                <li>Hindu priest should submit the certificate issued by the Department of Hindu Religious Affairs</li>
                                                <li>Catholic priest should submit certificate issued by the head of relevant catholic religious chapters</li>
                                        </ul>
                            </ol>
                        <br>
                        </div>
                        
                    </div>
            </div>
        </div>
        <hr>
        <!--Organization Information-->
        <div class="col-lg-12">
            <div style="text-align:center;">
                <h6><b>Organization Information</b></h6>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group col-lg-9" style="float:left">
                        <p style="font-size: 1em;">
                                Department of Registration of Persons,<br>
                                10th Floor,<br>
                                "Suhurupaya",<br>
                                Sri Subhuthipura Road,<br>
                                Battaramulla.<br><br>
                        </p>        
                    </div>
                    <div class="form-group col-lg-3" style="float:left">
                        <p style="font-size: 1em;" >
                            Mr. T.D. Koralegedara<br>
                            <b>Telephones:</b>+94-11-5226100<br>
                            <b>Fax Nos:</b>+94-11-2862290<br>
                            <b>Email:</b>info@drp.gov.lk<br>
                            <b>Website:</b> www.drp.gov.lk
                        </p>        
                    </div>
                </div>
            </div>    
        </div>
    <br>
    </div>
