<h2>Change Account Password</h2>
    <hr>
    <div class="container">
    
        <div class="box">
        
            <?php
                include '../../DB/conn.php';

                global $connection;
                $conn = $connection;
                session_start();
                $id = $_SESSION['LogId'];
                $email;
                
                $q = "SELECT * FROM `user` WHERE `iduser` = $id";
                $res = $conn->query($q);
                if($res->num_rows > 0){
                    while($row = $res->fetch_assoc()){
                        $email = $row["user_email"];
                    }
                }
            ?>

            <form id="pass" enctype="multipart/form-data">
                <div class="row spacer">
                    <div class="col-12">
                        <label class="changePass">Email:</label>
                        <input readonly type="email" id="email" value="<?php echo $email; ?>" class="form-control form-control-sm" placeholder="Email" />
                        <span class="val" id="emailVal"></span>
                    </div>
                </div>
                <div class="row spacer">
                    <br>
                    <div class="col-12">
                        <label class="changePass">Current Password:</label>
                        <input type="password" id="curPass" name="oldPassword" class="form-control form-control-sm" placeholder="Current Password" />
                        <span class="val" id="curPassVal"></span>
                    </div>
                </div>
                <div class="row spacer">
                    <div class="col-12">
                        <label class="changePass">New Password:</label>
                        <input type="password" id="newPass" name="password" class="form-control form-control-sm" placeholder="New Password" />
                        <span class="val" id="newPassVal"></span>
                    </div>
                </div>
                <div class="row spacer">
                    <div class="col-12">
                        <label class="changePass">Re-Enter Password:</label>
                        <input type="password" id="rePass" class="form-control form-control-sm" placeholder="Re-Enter Password" />
                        <span class="val" id="rePassVal"></span>
                    </div>
                </div>
            </form>
            <div class="row spacer">
                <div class="col-12" style="text-align: right;">
                    <button class="btn btn-sm btn-primary" id="submit">Change</button>
                </div>
            </div>
        </div>
    </div>

    <style>
        .container{
            width: 80%;
        }
        .box{
            margin: 25px auto;
            background-color: #ddd;
            padding: 15px 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 5px 2px #888;
        }

        .spacer{
            margin: 20px 0;
        }

        .changePass{
            font-size: 1.1rem;
        }

        .val{
            color: red;
            font-size: 0.8rem;
        }
        .submit{
            font-size: 1.1rem;
            font-weight: bold;
        }
    </style>

    <script>
        $(document).ready(() => {
            $('#curPass').on('keyup change', () => { valCurPass(); })
            $('#newPass').on('keyup change', () => { valNewPass(); })
            $('#rePass').on('keyup change', () => { valRePass(); })
            
            $('#submit').click(() => { submit(); })
        })

        function submit(){
            if(isValid()){
                var f = document.getElementById('pass');
                var d = new FormData(f);
                $.ajax({
                    type: 'POST',
                    url: './controls/admin/updatePassword.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r){
                        system_alert(r);
                        clear();
                    },
                    error: function(){
                        system_alert('Something went wrong!');
                    }
                });
            }
        }

        function clear(){
            $('input[type="password"]').val('');
        }

        function addVal(valElm, msg){
            valElm.html(msg);
        }

        function removeVal(valElm){
            valElm.html('');
        }

        function isValid() {
            return valCurPass() & valNewPass()
            & valRePass();
        }

        function valCurPass(){
            var elem = $('#curPass');
            var valElem = $('#curPassVal');
            if(elem.val() == ''){
                addVal(valElem, 'Current password is required!');
                return false;
            }

            removeVal(valElem);
            return true;
        }

        function valNewPass(){
            var elem = $('#newPass');
            var valElem = $('#newPassVal');
            if(elem.val() == ''){
                addVal(valElem, 'New password is required!');
                return false;
            }

            removeVal(valElem);
            return true;
        }

        function valRePass(){
            var elem = $('#rePass');
            var valElem = $('#rePassVal');
            if(elem.val() == ''){
                addVal(valElem, 'Retyping password is required!');
                return false;
            }

            if(elem.val() != $('#newPass').val()){
                addVal(valElem, 'Password does not match');
                return false;
            }

            removeVal(valElem);
            return true;
        }
    </script>