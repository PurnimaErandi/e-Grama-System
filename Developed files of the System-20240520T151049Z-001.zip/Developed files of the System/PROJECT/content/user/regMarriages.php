<div class="container" style="background-color:#e6eafc">
        <br>
        <h3 class="heading" style="text-align:center"><b>Registration of Marriages (General)</b></h3>
        <hr>
        <!-- Registration of Marriages Details(General) -->
        <div class="section">
                <div class="section-content">
                        <div class="row">
                                <ol >
                                    <li>Everyone other than where both parties are Muslims, can register their marriage under Marriage(general) Registration Ordinance.</li><br>
                                    <li>Notice of Marriage should be written and attested in duplicate and handed over to the Registrar of marriages of the division</li><br>
                                    <li>Persons authorized to attest marriage notice:</li> <br>
                                    <ol type="i">
                                        <li>Registrar of marriages of the division</li><br>
                                        <li>Justice of peace</li><br>
                                        <li>Notary public</li><br>
                                        <li>A Minister</li><br>
                                    </ol>
                                    <li>Requirements for submitting a marriage notice:</li><br>
                                        <ol type="i">
                                            <li>Requirement of residence of the parties in the relevant division.</li><br>
                                                <ul style="list-style-type:disc;">
                                                    <li>Residence of parties in the relevant division within 10 days preceding submission of the marriage notice.</li><br>
                                                    <li>Residence of parties in different divisions within 10 days preceding submission of the marriage notice.</li><br>
                                                    <li>If one party was not living in Sri Lanka within 10 days preceding submission of the marriage notice, residence of the other party in Sri Lanka for such 10 days.</li><br>
                                                    <li>If none of the parties had not been living in Sri Lanka within 10 days preceding submission of the marriage notice, residence of one party for 04 days in Sri Lanka</li><br>
                                                </ul>
                                            <li>Completion of age of 18 yrs. by both parties as at their previous birth day.</li><br>
                                            <li>The parties should not have any kind of relationship prohibited in law.</li><br>
                                            <li>No party should have entered into any legal marriage which is valid at the time.</li><br>
                                        </ol>
                                    <li>14 days should be lapsed since submission of marriage notice for registration of a marriage(general). Possibility prevails to register general marriage before lapse of such 14 days.</li><br>
                                    <li>Request may be made in order to register a marriage outside the office.</li>
                                </ol>
                        </div>
                </div>
        </div>
        <hr>
        <!--Organization Information-->
        <div class="col-lg-12">
            <div style="text-align:center;">
                <h6><b>Organization Information</b></h6>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group col-lg-9" style="float:left">
                        <p style="font-size: 1em;">
                            Department of Registrar General,<br>
                            No: 234 /A3,<br>
                            Denzil Kobbakaduwa Mawatha,<br>
                            Battaramulla.<br>
                        </p>        
                    </div>
                    <div class="form-group col-lg-3" style="float:left">
                        <p style="font-size: 1em;" >
                            Ms. Buddhika Nilanthi Ranaweera<br>
                            <b>Telephones:</b>+94-11-2889488 / +94-11-2889489<br>
                            <b>Fax Nos:</b>+94-11-2889491<br>
                            <b>Email:</b>info@rgd.gov.lk<br>
                            <b>Website:</b> www.rgd.gov.lk
                        </p>        
                    </div>
                </div>
            </div>    
        </div>
        <br>
</div>