<div class="col-lg-12">
    <h2>Dashboard</h2>
    <hr>
    <h5>Upcoming Events</h5>
    <div class="table-responsive">
        <table class="table table-striped ">
            <thead class="thead" style="background-color: #afb4b9;">
                <tr>
                    <th scope="col">Event Name</th>
                    <th scope="col">Date</th>
                    <th scope="col">Start Time</th>
                    <th scope="col">End Time</th>
                    <th scope="col">Location</th>
                </tr>
            </thead>
            <tbody>

            <?php

                include '../../DB/conn.php';

                global $connection;
                $conn = $connection;

                $q = "SELECT * FROM `event` 
                WHERE `is_public` = 1 AND `date` >= CURDATE()
                ORDER BY `date` ASC";
                $res = $conn->query($q);

                if (mysqli_num_rows($res) > 0) {
                    while ($row = mysqli_fetch_assoc($res)) {
                        echo "<tr>
                            <td>".$row["event_name"]."</td>
                            <td>".$row["date"]."</td>
                            <td>".$row["start_time"]."</td>
                            <td>".$row["end_time"]."</td>
                            <td>".$row["location"]."</td>
                        </tr>";
                        
                    }
                }
                ?> 

            </tbody>
        </table>
    </div>
    <br>
    <br>

    <div class="row mb-3">
        <div class="col-md-6">
            <div class="card" style="width: 28rem;">
                <img src="https://bmkltsly13vb.compat.objectstorage.ap-mumbai-1.oraclecloud.com/cdn.dailymirror.lk/assets/uploads/image_a9e369e7a0.jpg" class="card-img-top" alt="..."   style="height: 220px;">
                    <div class="card-body">
                        <h5 class="card-title">214 - Western Narangodapaluwa</h5>
                        <p class="card-text">Grama Niladhari : R.D.C.T Madhuwanthi</p>
                        <p class="card-text">Telephone No: 070-5980163</p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><b>Province</b> - Western Province</li>
                        <li class="list-group-item"><b>District</b> - Gampaha</li>
                        <li class="list-group-item"><b>Divisional Secretariat</b>- Ja Ela</li>
                        <li class="list-group-item"><b>GN Division</b> -214Western Narangodapaluwa</li>
                        <li class="list-group-item"><b>Nature</b>  - Rural</li>
                        <li class="list-group-item"><b>Village</b> -Western Narangodapaluwa</li>
                    </ul>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card" style="width: 28rem;">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCzwt2i-uBuYq4tUSgE_RuWsqIKPy34pDQCsc72nmOJY-JUBZubNItHxJwSck0NTGdHao&usqp=CAU" class="card-img-top" alt="..."  style="height: 220px;">
                    <div class="card-body">
                        <h5 class="card-title">Office Time</h5>
                        <p class="card-text">214</p>  
                        <p class="card-text">Western Narangodapaluwa</p>  
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><b>Monday</b> - 8.30AM – 4.15 PM</li>
                        <li class="list-group-item"><b>Tuesday</b> - Field Visit</li>
                        <li class="list-group-item"><b>Wednesday</b>- Divisional Secretariat</li>
                        <li class="list-group-item"><b>Thursday</b> -8.30 AM  - 4.15 PM</li>
                        <li class="list-group-item"><b>Friday </b>  - Holiday</li>
                        <li class="list-group-item"><b>Saturday</b> -8.30 AM – 12.30 PM</li>
                    </ul>
            </div>
        </div>
    </div>
</div>
<style>
    .card{
        margin:auto;
    }
    .card-title{
        text-align: center;
    }
    .card-text{
        text-align: center;
        font-weight: bold;
    }
</style>

