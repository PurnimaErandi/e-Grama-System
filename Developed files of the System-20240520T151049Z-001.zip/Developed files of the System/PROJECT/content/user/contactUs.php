<div class="col-lg-12">
    <h2>Contact Details</h2>
    <hr>
    <h4>General No</h4>
    <h5>
        <i class="fas fa-address-card">
        </i>
        +94 112955036
    </h5>
    <br>
    
    <div class="table-responsive">
        <table class="table table-striped ">
            <thead class="thead-dark">
                <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Designation</th>
                <th scope="col">Contact No</th>
                <th scope="col">Email/Fax</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>Mrs.W.P.C.N.Samarathunga</td>
                    <td>Divisional Secretaty</td>
                    <td>+94 112273218 [Ext: 201]</td>
                    <td>chandana@gmail.com</td>
                </tr>
                <tr>
                    <th scope="row">2</th>
                    <td>Miss.U.D.R.E.Warnakulasooriya</td>
                    <td>Assistant Divisional Secretary</td>
                    <td>+94 112273241 [Ext: 202]</td>
                    <td>rohani@gmail.com</td>
                </tr>
                <tr>
                    <th scope="row">3</th>
                    <td>Mr.R.D.S.T.Gunasinghe</td>
                    <td>Assistant Director ( Planning )</td>
                    <td>+94 112273044 [Ext: 203]</td>
                    <td>+94 372273044</td>
                </tr>
                <tr>
                    <th scope="row">4</th>
                    <td>Mrs.J.M.C.K.V.Jayawardhana</td>
                    <td>Accountant</td>
                    <td>+94 112273021 [Ext: 204]</td>
                    <td>+94 372273021</td>
                </tr>
                <tr>
                    <th scope="row">5</th>
                    <td>Mr. B.S.Pathma Kumara</td>
                    <td>Administrative Officer (Grama Niladhari)</td>
                    <td>+94 112273128 [Ext: 206]</td>
                    <td>+94 372273218</td>
                </tr>
                <tr>
                    <th scope="row">6</th>
                    <td>Mr. R.I.B.N.K.Rathnamalala</td>
                    <td>Additional District Registrar</td>
                    <td>+94 112273128 [Ext: 207]</td>
                    <td>+94 372273218</td>
                </tr>
                <tr>
                    <th scope="row">7</th>
                    <td>Mr. R.I.B.N.K.Rathnamalala</td>
                    <td>Rural Development Officer</td>
                    <td>+94 112273128 [Ext: 207]</td>
                    <td>+94 372273218</td>
                </tr>
                <tr>
                    <th scope="row">8</th>
                    <td>Mr.R.D.S.T.Gunasinghe</td>
                    <td>Assistant Director ( Planning )</td>
                    <td>+94 112273044 [Ext: 203]</td>
                    <td>+94 372273044</td>
                </tr>
            </tbody>
        </table>
    </div>
<style>
    h4 {
        font-size: 1.2rem;
    }
    h5{
       font-size: 1.1rem;  
    }
    .data-container{
        height: 250px;
        background-color: white;
        padding: 10px;
        border-radius: 5px;
        box-shadow: 0px 0px 4px 5px rgba(5,5,5,0.1);
        overflow-y: scroll;
    }  
    
</style>    