<div class="col-lg-12">
    <h2>Covid19 Information</h2>
    <hr>

    <div class="row mb-3">
        <div class="col-md-6">
            <div class="card" style="width: 28rem;box-shadow: 1px 1px 5px 3px;">
                <img src="https://www.nm.org//-/media/northwestern/healthbeat/images/healthy-tips/nm-how-to-wear-face-mask_preview.jpg" class="card-img-top" alt="..."   style="height: 220px;">
                    <div class="card-body">
                        <h5 class="card-title" style="text-align: center;"><b>Wear a Mask....</b></h5>
                        <p class="card-text" style="text-align: justify;">
                            The spread of the epidemic from the beginning of the Kovid epidemic as well as updating security strategies based on the latest scientific evidence is of paramount importance.
                            Given the current epidemic situation and the latest scientific evidence, it is a question for many people whether we should wear a mask or whether there is an advantage to wearing more than one.
                            When wearing N95 masks worn by people working with Kovid patients, including health workers, there is no need to wear extra masks on them as long as they touch all the edges of the face correctly.
                        </p>
                        <p class="card-text" style="text-align: justify;">
                            Some people do this when using a surgical mask, on the outside, or by wearing an extra face mask to minimize these gaps. 
                            There is somewhat early scientific evidence of the extent to which this system can help control epidemics. 
                            This tactic has been recommended by some public health organizations around the world in recent times.
                            The protection of a face mask depends on the number of layers and the material from which it is made. In the event of a high risk, a surgical mask can be worn as mentioned above and a face mask can be worn outside as needed for extra protection.
                            So, wear a mask to protect yourself and others.
                        </p>   
                    </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card" style="width: 28rem;box-shadow: 1px 1px 5px 3px;">
                <img src="https://d1e00ek4ebabms.cloudfront.net/production/74254ed4-5147-4fe0-af78-d71db7ee34a1.jpg" class="card-img-top" alt="..."   style="height: 220px;">
                    <div class="card-body">
                        <h5 class="card-title" style="text-align: center;"><b>Moderna Vaccine...</b></h5>
                        <p class="card-text" style="text-align: justify;">
                            It's one of the first vaccines designed to prevent coronary heart disease and serious illness as well as death. 
                            Preliminary research has shown that the vaccine has a high efficiency of 94%.
                            Initial research in foreign countries has shown that this may be the case for some new strains of the Covid virus. 
                            This is Moderna Inc., an injection company in the United States. Is a vaccine manufactured in a factory in Spain. 
                            It's reported that the World Health Organization (WHO) has made arrangements to supply this stock of vaccines to Sri Lanka on a COVAX basis.
                        </p>
                        <p class="card-text" style="text-align: justify;">
                            Minor side effects have been reported after receiving this injection as well as after the other, and it has been observed that most of them heal in a very short time. 
                            The most common reported side effects are:
                            Pain, swelling and redness at the injection site, fever, headache, vomiting and body aches and fatigue.
                        </p>
                        <p class="card-text" style="text-align: justify;">
                            However,as the Moderna vaccine, like the other vaccines, doesn't provide 100% protection against Covid-19, 
                            we would like to remind you again that it's imperative that you and your loved ones continue to adhere to the health practices that have been followed so far.
                        </p>
                    </div>
            </div>
        </div>
    </div>

    <!-- <div class="card" style="width: 18rem;">
        <img src="https://scontent.fcmb1-2.fna.fbcdn.net/v/t1.6435-9/214759384_3712273792210670_6640201578534860184_n.jpg?_nc_cat=108&ccb=1-3&_nc_sid=973b4a&_nc_ohc=w6ihE6zEf2UAX_h4tN7&_nc_ht=scontent.fcmb1-2.fna&oh=84291f3d6695e87326fe5623912b8da4&oe=6124DAB0" class="card-img-top" alt="...">
        <div class="card-body">
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        </div>
    </div>


    <div class="card mb-3">
  <img src="https://scontent.fcmb1-2.fna.fbcdn.net/v/t1.6435-9/214759384_3712273792210670_6640201578534860184_n.jpg?_nc_cat=108&ccb=1-3&_nc_sid=973b4a&_nc_ohc=w6ihE6zEf2UAX_h4tN7&_nc_ht=scontent.fcmb1-2.fna&oh=84291f3d6695e87326fe5623912b8da4&oe=6124DAB0" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
  </div>
</div> -->
</div>    