<div class="col-lg-12">
    <h2>My Children</h2>
    <hr>
    <br>
    
    <div class="table-responsive">
        <table class="table table-striped ">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Reg No.</th>
                    <th scope="col">Name</th>
                    <th scope="col">Date of Birth</th>
                </tr>
            </thead>
            <tbody>
            <?php
                include '../../DB/conn.php';

                global $connection;
                $conn = $connection;
                session_start();

                $q = "SELECT r.nameof_person, m.child_regNo, r.dateof_birth FROM `parent_child_mapping` m 
                INNER JOIN `person` r ON m.child_id = r.idperson 
                WHERE parent_id = 
                (SELECT p.idperson FROM `user` u INNER JOIN `person` p 
                ON u.user_nic = p.nic WHERE p.is_child = 0 AND u.iduser = ".$_SESSION['LogId'].")";

                $counter = 0;

                $res = $conn->query($q);
                if($res->num_rows > 0){
                    while($row = $res->fetch_assoc()){
                        echo "
                            <tr>
                                <td>
                                    <input data-id='".++$counter."' class='reg' readonly title='Registration No' type='text' value=".$row['child_regNo'].">
                                    <button data-btn='".$counter."' title='Copy to clipboard' class='cp-btn'><i class='fas fa-copy'></i></button>
                                </td>
                                <td>".$row['nameof_person']."</td>
                                <td>".$row['dateof_birth']."</td>
                            </tr>";
                    }
                }
            ?>
            </tbody>
        </table>
    </div>
<style>
    h4 {
        font-size: 1.2rem;
    }
    h5{
       font-size: 1.1rem;  
    }
    .data-container{
        height: 250px;
        background-color: white;
        padding: 10px;
        border-radius: 5px;
        box-shadow: 0px 0px 4px 5px rgba(5,5,5,0.1);
        overflow-y: scroll;
    } 
    .reg {
        border: none;
        background-color: inherit;
    } 
    .reg:focus, .reg:active{
        border: none;
    }
    .cp-btn{
        border: none;
        color: hsl(0deg 0% 50%);
        cursor: pointer;
        background-color: inherit;
        font-size: 1.01rem;
    }
    .cp-btn:hover{
        border-radius: 50%;
        background-color: #dadada;
        color: #5897fb;
    }
    
</style>  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $('.cp-btn').click((e) => {
        var id = e.currentTarget.getAttribute('data-btn');
        var value = $(`input[data-id="${id}"]`).val();
        navigator.clipboard.writeText(value);
        toastr.options = {
            progressBar: true,
            timeOut: 3000
        }
        toastr.success('Reg-no copied to clipboard!');
    })
</script>