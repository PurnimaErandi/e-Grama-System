<div class="container" style="background-color:#e6eafc">
        <br>
        <h3 class="heading" style="text-align:center"><b>Obtaining Transport Permits for Sand Clay, Gravel</b></h3>
        <hr>

        <!-- Obtaining Transport Permits for Sand Clay, Gravel -->
        <div class="section">
            <div class="section-content">
                <div class="row">
                    <ol>
                        <li><b>Eligibility</b></li></br>
                            <ul style="list-style-type:disc;">
                                <li>Be a Sri Lankan</li><br>
                                <li>A foreigner who invests in Sri Lanka (having a registered company in Sri Lanka)</li><br>
                                <li>Should not be a government officer.</li><br>
                                <li>Should not be a mentally retarded, disable, or a person convicted by a court of law.</li><br>
                            </ul>
                        <li><b>Process of Submitting Application</b></li></br>
                        <li><b>Places from where Application can be Obtained</b></li></br>
                            <ul style="list-style-type:disc;">
                                <li>Head office</li><br>
                                <li>Divisional offices</li><br>
                                <li>Fees payable for obtaining application</li><br>
                            </ul>
                        <li><b>Time at which Application should be Submitted":</b> During working hours.</li></br>
                        <li><b>Fees Payable for Obtaining the Service:</b> Not available.</li><br>
                        <li><b>Time taken to Provide the Service (Ordinary Service and Priority Service):</b> One day</li><br>
                        <li><b>Supporting Documents Required</b></li><br>
                        <li><b>Sand - Permit for Sand Excavation:</b> Permit for storage.</li><br>
                    </ol>
                </div>
            <div>
        </div>
        <!--Organization Information-->
        <div class="col-lg-12">
            <div style="text-align:center;">
                <h6><b>Organization Information</b></h6>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group col-lg-9" style="float:left">
                        <p style="font-size: 1em;">
                            Geological Survey and Mines Bureau,<br>
                            No 569,<br>
                            Epitamulla Road,<br>
                            Pitakotte.
                        </p>        
                    </div>
                    <div class="form-group col-lg-3" style="float:left">
                        <p style="font-size: 1em;" >
                            <b>Mr. T. Dhanayake</b><br>
                            <b>Telephones:</b>011 2886289<br>
                            <b>Fax Nos:</b>+94 11 2886273<br>
                            <b>Email:</b>info@gsmb.gov.lk<br>
                            <b>Website:</b> www.gsmb.gov.lk
                        </p>        
                    </div>
                </div>
            </div>    
        </div>
        <br>
</div>