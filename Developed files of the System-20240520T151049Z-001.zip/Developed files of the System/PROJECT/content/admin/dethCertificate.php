
        <div class="container">
            <section id="deathCertificate">
                <h3 class="heading"><b>Report Of Death By Grama Sewa Niladhari</b></h3>
                <div class="sub-text">
                    (To be forwarded direct to the Registrar within seven days of death)
                </div>
                <hr>

                <form id="death-form" enctype="multipart/form-data">
                <!-- Div nums -->
                <div class="section">
                    <div class="section-content">
                        <div class="row">
                            <div class="col-lg-3 gnDiv">Grama Sewa Niladhari's Division</div>
                            <div class="form-group col-lg-9">
                                <select class="form-control form-control-sm" id="gnDiv" name="gnDiv"></select>
                                <span class="val text-danger" id="gnDivVal"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3">Registrar's Division</div>
                            <div class="col-lg-9">
                                <input type="text" class="form-control form-control-sm" id="regDiv" name="regDiv"/>
                                <span class="val text-danger" id="regDivVal"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Death details -->
                <div class="section">
                    <div class="section-content">
                        <div class="row">
                            <div class="col-lg-3">1. Date of Death: </div>
                            <div class="form-group col-lg-9">
                                <input type="date" class="form-control form-control-sm" id="deathDate" name="deathDate"/>
                                <span class="val text-danger" id="deathDateVal"></span>
                            </div>
                        </div>
                        <div class="row" > 
                            <div class="col-lg-3">2. Place of Death: </div>
                            <div class="form-group col-lg-9">
                                <input type="text" class="form-control form-control-sm" id="place" name="place"/>
                                <span class="val text-danger" id="placeVal"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3">3. Person's NIC No: </div>
                            <div class="form-group col-lg-9">
                                <input type="text" class="form-control form-control-sm" id="nicno"  name="nicno" maxlength="12"/>
                                <span class="val text-danger" id="nicnoVal"></span>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-lg-3">4. Full Name: </div>
                            <div class="form-group col-lg-9">
                                <input type="text" class="form-control form-control-sm" id="fullname" name="fullname"/>
                                <span class="val text-danger" id="fullnameVal"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3">5. Gender: </div>
                            <div class="form-group col-lg-9">
                                <select type="text" class="form-control form-control-sm" id="gender"  name="gender">
                                    <option value="0"></option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                <span class="val text-danger" id="genderVal"></span>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-lg-3">6. Nationality: </div>
                            <div class="form-group col-lg-9">
                                <select type="text"  class="form-control form-control-sm" id="nationality"  name="nationality">
                                    <option value="0"></option>
                                    <option value="Sinhalese">Sinhalese</option>
                                    <option value="Tamils">Tamils</option>
                                    <option value="Muslims">Muslims</option>
                                    <option value="Malay">Malay</option>
                                    <option value="Burgher">Burgher</option>
                                </select> 
                                <span class="val text-danger" id="nationalityVal"></span>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-lg-3">7. Age: </div>
                            <div class="form-group col-lg-9">
                                <input type="number" class="form-control form-control-sm" id="age"  name="age"/>
                                <span class="val text-danger" id="ageVal"></span>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-lg-3">8. Rank of Profession: </div>
                            <div class="form-group col-lg-9">
                                <input type="text" class="form-control form-control-sm" id="profession" name="profession"/>
                                <span class="val text-danger" id="professionVal"></span>
                            </div>
                        </div> 

                        <div class="row">
                            <div class="col-lg-3">9. Cause of Death: </div>
                            <div class="form-group col-lg-9">
                                <input type="text" class="form-control form-control-sm" id="reason" name="reason"/>
                                <span class="val text-danger" id="reasonVal"></span>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-lg-5">10. Name of person bound to give Information: </div>
                            <div class="form-group col-lg-7">
                                <input type="text" class="form-control form-control-sm" id="nameinfo" name="nameinfo"/>
                                <span class="val text-danger" id="nameinfoVal"></span>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-lg-5">11. Address of person bound to give Information: </div>
                            <div class="form-group col-lg-7">
                                <textarea type="text" class="form-control form-control-sm" id="addressinfo" name="addressinfo"></textarea>
                                <span class="val text-danger" id="addressinfoVal"></span>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Declaration -->
                <div class="section">
                    <div class="section-content dec-text">
                        I certify that the above statement contains the true particulars of a death 
                        which occurred in my division and I report the same to the Registrar of
                        Registration Number is 
                        <input type="text" class="dec form-control form-control-sm" placeholder="Registration number..." id="regNum" name="regNum"/>
                        and that it has been issued by 
                        <input type="text" class="dec form-control form-control-sm" placeholder="Issuer..." id="issueBy" name="issueBy"/>.
                    </div>
                    
                </div>
                </form>
                
                <div class="form-check" style="margin-bottom: 20px; font-weight: 500;">
                    <input type="checkbox" class="form-check-input" id="gov">
                    <label class="form-check-label" for="exampleCheck1">For state use only</label>
                </div>

                <!-- Gov -->
                <div class="section" id="govSec" style="display: none;">
                    <div class="section-content">
                        <div class="row">
                            <div class="col-lg-3">The registrar of births and deaths: </div>
                            <div class="form-group col-lg-9">
                                <textarea type="text" class="form-control form-control-sm" id="reg-b-and-d"></textarea>
                                <span class="val text-danger" id="reg-b-and-dVal"></span>
                                <span style="font-size: 0.80rem;">
                                    Report required to be finished under the provisions of the Births and 
                                    Deaths Registration Act No. 17 of 1951.
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="controls">
                <button class="btn btn-primary btn-sm" id="submit">Submit</button>
                <button class="btn btn-outline-secondary btn-sm" id="clear">Clear</button>
            </div>
        </div>
        
        <div class="modal" id="confirm-window" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title">Create Death Certificate</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div>Select Person</div>
                            <select class="form-control form-control-sm" id="person-list">
                                <?php
                                    include '../../DB/conn.php';
                                    global $connection;

                                    $query = "SELECT * FROM `person` WHERE `is_alive` = 0";
                                    $result = mysqli_query($connection, $query);
                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<option value=". $row["idperson"] .">".$row["nameof_person"]." (".$row["nic"].")</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="save-form">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <style>
        .select2-container{
            width: 100%!important;
        }
    </style>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="./css/character-form.css"/>
    <script src="./js/deathcertfcte.js"></script>
   