
    <div class="col-lg-12">
        <h2>Work History </h2>
        <hr>
        
        <div class='col-lg-12'>
            <div class="tab-content">
                <div id="home" class="container tab-pane active"><br>
                    <h4>Previous Workplace Details</h4>
                    <div class="col-lg-12">
                        <form id="work_history_forms" enctype="multipart/form-data">
    
                            <div class="form-group col-lg-6" style="float:left">
                                <label for="province">Province:</label>
                                <select class="form-control" id="workhistory-prvnce" name="provnce">
                                    <option value="">- Please Select -</option>
                                    <option value='central province'>Central Province</option>
                                    <option value='Eastern Province'>Eastern Province</option>
                                    <option value='Northern Province'>Northern Province</option>
                                    <option value='North Central Province'>North Central Province</option>
                                    <option value='North Western Province'>North Western Province</option>
                                    <option value='Sabaragamuwa Province'>Sabaragamuwa Province</option>
                                    <option value='Southern Province'>Southern Province</option>
                                    <option value='Uva Province'>Uva Province</option>
                                    <option value='Western Province'>Western Province</option>
                                </select>
                                <label class="val text-danger" id="workhistory-prvnce-val"></label>
                                <br>  
                            </div>   
                            <div class="form-group col-lg-6" style="float:left">
                                <label for="district">District:</label>
                                <select class="form-control" id="dstrct" name="distrct">
                                    <option value="">- Please Select -</option>
                                </select>
                                <label class="val text-danger" id="dstrct-val"></label>
                                <br>
                            </div>

                            <script>
                                var object = JSON.parse('<?php echo file_get_contents('../../data/district.json') ?>');
                                //alert(object.length);
                                $("#workhistory-prvnce").change(function () {
                                    var prv = this.value.toUpperCase();
                                    var data = "";
                                    for (var i = 0; i < object.length; i++) {
                                        var found = false;
                                        var oprv = object[i]["province"].toUpperCase();
                                        if (prv == oprv) {
                                            data = data + "<option value='" + object[i]["district"] + "'>" + object[i]["district"] + "</option>";
                                            
                                        }
                                    }
                                    $("#dstrct").html(data);
                                    loadDivs();
                                });

                                $('#dstrct').change(() => {
                                    loadDivs();
                                });

                                function loadDivs(){
                                    var divs = object.filter(n => n.district == $('#dstrct').val())[0].divisions;
                                    var divList = $('#divisionalsec');
                                    divList.empty();
                                    $.each(divs, i => {
                                        divList.append(`<option value="val">${divs[i]}</option>`);
                                    });
                                }

                            </script>

                            <div class="form-group col-lg-12" style="float:left">
                                <label for="divisionsec">Divisional Secretariat:</label>
                                <select class="form-control" id="divisionalsec">
                                    <option value="">- Please Select -</option>
                                </select>
                                <label class="val text-danger" id="divisionalsec-val"></label>
                                <br>
                            </div>

                            <div class="form-group col-lg-12" style="float:left">
                                <label for="nameofgn">Name of Grama Niladhari:</label>
                                <input type="text" class="form-control" id="nameofgn" name="nameofgn">
                                <label class="val text-danger" id="nameofgn-val"></label>
                            </div>

                            <div class="form-group col-lg-12" style="float:left">
                                <label for="address">Address:</label>
                                <textarea class="form-control" rows="5" id="address" name="address"></textarea>
                                <label class="val text-danger" id="address-val"></label>
                            </div>

                            <div class="form-group col-lg-6" style="float:left">
                                <label for="tno">Telephone No:</label>
                                <input type="tel" class="form-control" id="teleno" name="teleno">
                                <label class="val text-danger" id="teleno-val"></label>
                            </div>

                            <div class="form-group col-lg-6" style="float:left">
                                <label for="sdofduty">Start Date of Duty:</label>
                                <input type="date" class="form-control" id="sdateofduty" name="sdateofduty">
                                <label class="val text-danger" id="sdateofduty-val"></label>
                            </div>

                            <div class="form-group col-lg-12" style="float:left">
                                <label for="odetails">Other Details:</label>
                                <textarea class="form-control" rows="10" id="odetails" name="odetails"></textarea>
                                <label class="val text-danger" id="odetails-val"></label>
                            </div>
                        </form>

                        <button type="button" class="btn btn-primary" id="submit">Submit</button>
                        <button type="button" class="btn btn-dark" id="clear">Clear</button>
                    </div>
                </div>

                <script>
                    $(document).ready(() => {
                        $('#workhistory-prvnce').change(() => { validateProv(); })
                        $('#dstrct').change(() => { validateDist(); })
                        $('#divisionalsec').change(() => { validateDiv(); })
                        $('#nameofgn').on('keyup change', () => { validateName(); })
                        $('#address').on('keyup change', () => { validateAddr(); })
                        $('#teleno').on('keyup change', () => { validateTel(); })
                        $('#sdateofduty').on('keyup change', () => { validateDutDate(); })
                        $('#odetails').on('keyup change', () => { validateOtherDet(); })

                        $("#submit").on('click', () => {
                            var form = document.getElementById('work_history_forms');
                            var data= new FormData(form);
                            data.append('divisionalsec', $('#divisionalsec option:selected').text())

                            if(isValidate()){
                                $.ajax({
                                    url: "./controls/admin/work_history.php",
                                    type: "POST",
                                    data: data, 
                                    contentType: false, 
                                    cache: false,
                                    processData: false,
                                    success: function (data){
                                        if (data == "1") {
                                            system_alert("Saved success");
                                        } else {
                                            system_alert(data);
                                            reset();
                                            changePath("./content/admin/workHistory");
                                        }
                                    },
                                    error: function(){
                                        system_alert("Saved success");
                                    }
                                });
                            }
                            else{
                                $('.in-err').filter(':first').focus();
                            }
                        })
                        $('#clear').click(() => { reset(); })
                    })

                    function reset(){
                        $('input[type="text"], input[type="tel"], input[type="date"], textarea').val('');
                        $('.val').html('');
                        $("select").prop("selectedIndex", 0);
                    }

                    function addValidation(valIn, validationIndicator, message){
                        validationIndicator.html(message);
                        valIn.addClass('in-err');
                    }

                    function removeValidation(valIn, validationIndicator){
                        validationIndicator.html('');
                        valIn.removeClass('in-err');
                    }

                    function isValidate(){
                        return validateProv() & validateDist() & validateDiv() & validateTel()
                        & validateName() & validateAddr() & validateDutDate() & validateOtherDet();
                    }

                    /* Validation events */

                    function validateProv(){
                        if($('#workhistory-prvnce').val() == ''){
                            addValidation($('#workhistory-prvnce'), $('#workhistory-prvnce-val'), 'Province is required');
                            $('#workhistory-prvnce').focus();
                            return false;
                        }
                        removeValidation($('#workhistory-prvnce'), $('#workhistory-prvnce-val'));
                        return true;
                    }

                    function validateDist(){
                        if($('#dstrct').val() == '' || $('#dstrct').val() == null){
                            addValidation($('#dstrct'), $('#dstrct-val'), 'District is required');
                            $('#dstrct').focus();
                            return false;
                        }
                        removeValidation($('#dstrct'), $('#dstrct-val'));
                        return true;
                    }

                    function validateDiv(){
                        if($('#divisionalsec').val() == ''){
                            addValidation($('#divisionalsec'), $('#divisionalsec-val'), 'Divisional Secretariat is required');
                            $('#divisionalsec').focus();
                            return false;
                        }
                        removeValidation($('#divisionalsec'), $('#divisionalsec-val'));
                        return true;
                    }

                    function validateName(){
                        if($('#nameofgn').val() == ''){
                            addValidation($('#nameofgn'), $('#nameofgn-val'), 'Name of GN is required');
                            $('#nameofgn').focus();
                            return false;
                        }
                        removeValidation($('#nameofgn'), $('#nameofgn-val'));
                        return true;
                    }

                    function validateAddr(){
                        if($('#address').val() == ''){
                            addValidation($('#address'), $('#address-val'), 'Address is required');
                            $('#address').focus();
                            return false;
                        }
                        removeValidation($('#address'), $('#address-val'));
                        return true;
                    }

                    function validateTel(){
                        if($('#teleno').val() == ''){
                            addValidation($('#teleno'), $('#teleno-val'), 'Telephone No. is required');
                            $('#teleno').focus();
                            return false;
                        }
                        removeValidation($('#teleno'), $('#teleno-val'));
                        return true;
                    }

                    function validateDutDate(){
                        if($('#sdateofduty').val() == ''){
                            addValidation($('#sdateofduty'), $('#sdateofduty-val'), 'Duty start date is required');
                            $('#sdateofduty').focus();
                            return false;
                        }
                        removeValidation($('#sdateofduty'), $('#sdateofduty-val'));
                        return true;
                    }

                    function validateOtherDet(){
                        if($('#odetails').val() == ''){
                            addValidation($('#odetails'), $('#odetails-val'), 'Other detais are required');
                            $('#odetails').focus();
                            return false;
                        }
                        removeValidation($('#odetails'), $('#odetails-val'));
                        return true;
                    }
                </script>
            </div>                  
        </div>
    </div>
