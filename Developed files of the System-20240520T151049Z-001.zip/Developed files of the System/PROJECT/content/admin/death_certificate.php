<?php
    session_start();
    ini_set('display_errors',0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="../../css/character-form.css"/>
    <title>View Death Certificate</title>
</head>
<body style="padding:10px">
    <?php
        if(isset($_SESSION["deathNic"])){
            $gn_division= '';
            $reg_division = '';
            $death_date  = '';
            $death_place = '';
            $person_nic = '';
            $full_name = '';
            $gender= '';
            $nationality = '';
            $age = '';
            $profession = '';
            $cause = '';
            $person_bound_to_give_info = '';
            $address_of_bounded_person = '';
            $regis_no = '';
            $issuer = '';
            
            
            include '../../DB/conn.php';
            global $connection;
            $conn = $connection;
            $nic = $_SESSION['deathNic'];

            $q = "SELECT * FROM `death_certificate` 
            WHERE `person_nic` = '$nic'";
            
            $res = $conn->query($q);

            if($res->num_rows > 0){
                while($row = $res->fetch_assoc()){
                    $gn_division = $row['gn_division'];
                    $reg_division = $row['reg_division'];
                    $death_date  = $row['death_date'];
                    $death_place  = $row['death_place'];
                    $person_nic  = $row['person_nic'];
                    $full_name = $row['full_name'];
                    $gender = $row['gender'];
                    $nationality = $row['nationality'];
                    $age = $row['age'];
                    $profession  = $row['profession'];
                    $cause = $row['cause'];
                    $person_bound_to_give_info = $row['person_bound_to_give_info'];
                    $address_of_bounded_person = $row['address_of_bounded_person'];
                    $regis_no= $row['regis_no'];
                    $issuer = $row['issuer'];
                    
                }
            }
            else {
                $q = "SELECT d.* FROM death_certificate d INNER JOIN parent_child_mapping m 
                ON d.requested_person_id = m.child_id 
                WHERE m.child_regNo = '$nic'";
                
                $res = $conn->query($q);

                if($res->num_rows > 0){
                    while($row = $res->fetch_assoc()){
                        $gn_division = $row['gn_division'];
                        $reg_division = $row['reg_division'];
                        $death_date  = $row['death_date'];
                        $death_place  = $row['death_place'];
                        $person_nic  = $row['person_nic'];
                        $full_name = $row['full_name'];
                        $gender = $row['gender'];
                        $nationality = $row['nationality'];
                        $age = $row['age'];
                        $profession  = $row['profession'];
                        $cause = $row['cause'];
                        $person_bound_to_give_info = $row['person_bound_to_give_info'];
                        $address_of_bounded_person = $row['address_of_bounded_person'];
                        $regis_no= $row['regis_no'];
                        $issuer = $row['issuer'];
                        
                    }
                }
            }
        }
        else{
            echo '<div class="alert alert-danger">Unable to open the certificate!</div>';
        }
    ?>

    <div class="container">
        <h3 class="heading"><b>Report Of Death By Grama Sewa Niladhari</b></h3>
        <div class="sub-text">
        <h6><center>(To be forwarded direct to the Registrar within seven days of death)</center></h6>
        </div>
        <br>
        <hr>
        <br>
        <div class="section">
            <div class="section-content">
                <div class="row">
                        <div class="col-5">Grama Sewa Niladhari's Division :</div>
                        <div class="form-group col-7">
                            <span><?php echo $gn_division; ?></span> 
                        </div>
                </div>
                <div class="row">
                        <div class="col-5">Registrar's Division :</div>
                        <div class="form-group col-7">
                        <span><?php echo $reg_division; ?></span>     
                       </div>
                </div>
            </div>
        </div>
        <br>
        <div class="section">
            <div class="section-content">
                <div class="row">
                    <div class="col-5">1. Date of Death: </div>
                    <div class="form-group col-7">
                        <span><?php echo $death_date ; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">2. Place of Death: </div>
                    <div class="form-group col-6">
                        <span><?php echo  $death_place; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">3. Person's NIC No:</div>
                    <div class="form-group col-7">
                        <span><?php echo  $person_nic ; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">4. Full Name:</div>
                    <div class="form-group col-7">
                        <span><?php echo $full_name; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">5. Gender: </div>
                    <div class="form-group col-7">
                        <span><?php echo $gender ; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">6. Nationality:   </div>
                    <div class="form-group col-7">
                        <span><?php echo $nationality; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">7. Age:  </div>
                    <div class="form-group col-7">
                        <span><?php echo $age ; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">8. Rank of Profession: </div>
                    <div class="form-group col-7">
                        <span><?php echo $profession; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">9. Cause of Death: </div>
                    <div class="form-group col-7">
                        <span><?php echo $cause ; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">10. Name of person bound to give Information: </div>
                    <div class="form-group col-7">
                        <span><?php echo $person_bound_to_give_info; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5">11. Address of person bound to give Information:</div>
                    <div class="form-group col-7">
                        <span><?php echo $address_of_bounded_person; ?></span>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="section">
            <div class="section-content dec-text">
                <h6>I certify that the above statement contains the true particulars of a death 
                which occurred in my division and I report the same to the Registrar of
                Registration Number is
                <span><?php echo $regis_no; ?></span>
                and that it has been issued by 
                <span><?php echo $issuer."."; ?></span></h6>
            </div>
        </div>
    </div>
    <br>
    <footer>
        <div class="container hide" style="text-align:right">
            <button class="btn btn-sm btn-secondary" id="print" title="Print Certificate"><i class="fa fa-print"></i></button> 
        </div>
    </footer>

    <style>
        @media print{
            .hide{
                display: none;
            }
        }
    </style>

    <script>
        $('#print').click(() => { print(); });
    </script>
</body>
</html>

