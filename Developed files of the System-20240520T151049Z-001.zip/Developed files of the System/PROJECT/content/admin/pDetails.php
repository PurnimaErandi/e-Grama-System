<div class="col-lg-12">
    <h2> View Persons Registration Details</h2>
    <hr>
   
    <div class="container">
        <div class="table-responsive">
            <div class="container mt-3">
                <table class="table table-striped table-bordered table-sm" id="personalDetails_view">
                    <thead>
                        <tr>
                            <th>Action&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Name of Person&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>House No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Status</th>
                            <th>Gender</th>
                            <th>Date of Birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Birth Place</th>
                            <th>Telephone No</th> 
                            <th>Email</th>
                            <th>Is Alive</th>
                            <th>Religions</th>
                            <th>Nationality</th> 
                            <th>NIC No</th>
                            <th>Education&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Occupation</th>
                            <th>Physical & Mental Situation&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Vehicles</th>
                            <th>Language Knowledge</th>
                            <th>IT Knowledge&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Other Skills</th>
                            <th>Is Child</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            include '../../DB/conn.php';
                                        global $connection;

                                        $query = "SELECT * FROM `person`";
                                        $result = mysqli_query($connection, $query);
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                $alive = $row['is_alive'] == 1 ? 'Yes' : 'No';
                                                $isChild = $row['is_child'] == 1 ? 'Child' : 'Adult';
                                                echo "
                                                    <tr>
                                                        <td>
                                                            <button class=\"btn btn-sm btn-danger\" onclick='remove(".$row['idperson'].")'><i class=\"fa fa-trash\"></i></button>
                                                            <button class=\"btn btn-sm btn-primary\" onclick='edit(".$row['idperson'].")'><i class=\"fa fa-edit\"></i></button>
                                                            <button class=\"btn btn-sm btn-info\" onclick='viewAid(".$row['idperson'].")'><i class=\"fa fa-eye\"></i></button>
                                                        </td>
                                                        <td>".$row['nameof_person']."</td>
                                                        <td>".$row['house_no']."</td>
                                                        <td>".$row['status']."</td>
                                                        <td>".$row['gender']."</td>
                                                        <td>".$row['dateof_birth']."</td>
                                                        <td>".$row['birth_place']."</td>
                                                        <td>".$row['telephone_no']."</td>
                                                        <td>".$row['email']."</td> 
                                                        <td>".$alive."</td> 
                                                        <td>".$row['religions']."</td>       
                                                        <td>".$row['nationality']."</td>
                                                        <td>".$row['nic']."</td>
                                                        <td>".$row['education']."</td>    
                                                        <td>".$row['occupation']."</td>
                                                        <td>".$row['phyMental_health']."</td>  
                                                        <td>".$row['vehicles']."</td>
                                                        <td>".$row['lang_knowledge']."</td>
                                                        <td>".$row['it_knowledge']."</td>
                                                        <td>".$row['other_skills']."</td> 
                                                        <td>".$isChild."</td> 
                                                    </tr>
                                                 ";
                                            }
                                        }
                        ?>     
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Edit personal details -->

        <div class="modal fade" id="editor" tabindex="-1" role="dialog" aria-labelledby="editorLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editorLabel">Edit</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="data" enctype="multipart/form-data">
                            <div class="container">
                                <div class="row">
                                    <div class="form-group col-lg-6">
                                        <label for="isChild">Is the person a Child: </label>
                                        <input type="checkbox" class="" id="isChild" name="isChild">
                                    </div>
                                </div>
                                <div class="row"> 
                                    <div class="form-group col-md-6">
                                        <label>Name of Person:</label>
                                        <input type="text" class="form-control form-control-sm" id="personname" name="personname">
                                        <span class="val" id="personnameVal"></span>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>House No:</label>
                                        <input type="text"  class="form-control form-control-sm"  id="hseno" name="hseno">
                                        <span class="val" id="hsenoVal"></span>
                                    </div>
                                </div> 
                                <div class="row"> 
                                    <div class="form-group col-md-6">
                                        <label>Status:</label>
                                        <select id="status" class="form-control form-control-sm" name="status">
                                            <option>Single</option>
                                            <option>Married</option>
                                            <option>Divorce</option>
                                        </select>
                                        <span class="val" id="statusVal"></span>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Gender:</label>
                                        <select id="gender" class="form-control form-control-sm" name="gender">
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>
                                        <span class="val" id="genderVal"></span>
                                    </div>
                                </div> 
                                <div class="row"> 
                                    <div class="form-group col-md-6">
                                        <label>Date of Birth:</label>
                                        <input type="date"  class="form-control form-control-sm" id="date" name="date">
                                        <span class="val" id="dateVal"></span>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Birth Place:</label>
                                        <input type="text"  class="form-control form-control-sm"  id="place" name="place">
                                        <span class="val" id="placeVal"></span>
                                    </div>
                                </div> 
                                <div class="row" data-hide-on-child="true"> 
                                    <div class="form-group col-md-6">
                                        <label>ID No:</label>
                                        <input type="text"  class="form-control form-control-sm" id="idNo" name="idNo">
                                        <span class="val" id="idNoVal"></span>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Telephone No:</label>
                                        <input type="text"  class="form-control form-control-sm"  id="telno" name="telno">
                                        <span class="val" id="telnoVal"></span>
                                    </div>
                                </div> 
                                <div class="row"> 
                                    <div class="form-group col-md-6" data-hide-on-child="true">
                                        <label>Email:</label>
                                        <input type="text"  class="form-control form-control-sm" id="email" name="email">
                                        <span class="val" id="emailVal"></span>
                                    </div>

                                    <div class="form-group col-md-6 hide" data-hide-on-child="false">
                                        <label style="display: block;" for="guardian">Guardian of the Child:</label>
                                        <select class="form-control" id="guardian" style="width: 100%;">
                                            <option value="" disabled selected>Select the guardian</option>
                                            <?php
                                                include '../../DB/conn.php';

                                                global $connection;
                                                $conn = $connection;

                                                $q = "SELECT * FROM `person` WHERE `is_child` = 0";
                                                $res = $conn->query($q);
                                                if($res->num_rows > 0){
                                                    while($row = $res->fetch_assoc()){
                                                        echo "<option value='".$row["idperson"]."'>".$row["nameof_person"]." - ".$row["nic"]."</option>";
                                                    }
                                                }
                                            ?>
                                        </select>
                                        <span class="val text-danger" id="guardianVal"></span>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>Is Alive:</label>
                                        <select id="alive" class="form-control form-control-sm" name="alive">
                                            <option value="0">No</option>
                                            <option value="1">Yes</option>
                                        </select>
                                        <span class="val" id="aliveVal"></span>
                                    </div>
                                </div>
                                <div class="row"> 
                                    <div class="form-group col-md-6">
                                        <label>Religions:</label>
                                        <select id="religion" class="form-control form-control-sm" name="religion">
                                            <option>Buddhism</option>
                                            <option>Hinduism</option>
                                            <option>Islam</option>
                                            <option>Catholic</option>
                                            <option>Other</option>
                                        </select>
                                        <span class="val" id="religionVal"></span>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Nationality:</label>
                                        <select id="nationality" class="form-control form-control-sm" name="nationality">
                                            <option>Sinhalese</option>
                                            <option>Tamils</option>
                                            <option>Muslims</option>
                                            <option>Malay</option>
                                            <option>Burgher</option>
                                            <option>Other</option>
                                        </select>
                                        <span class="val" id="nationalityVal"></span>
                                    </div>
                                </div> 
                                <div class="row"> 
                                    <div class="form-group col-md-6">
                                        <label>Education:</label>
                                        <select id="education" class="form-control form-control-sm" name="education">
                                            <option>1-5 Primary</option>
                                            <option>6-10 Secondary</option>
                                            <option>Ordinary Level</option>
                                            <option>Advanced Level</option>
                                            <option>Higher Studies</option>
                                            <option>Other</option>
                                        </select>
                                        <span class="val" id="educationVal"></span>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Occupation:</label>
                                        <select id="occupation" class="form-control form-control-sm" name="occupation">
                                            <option>None</option>
                                            <option>Cultivation</option>
                                            <option>Skilled Labour(Carpenters,Masons,Electricians etc.)</option>
                                            <option>Unskilled Labour</option>
                                            <option>Fishing</option>
                                            <option>Government Offices</option>
                                            <option>Private Sector</option>
                                            <option>Small Business</option>
                                            <option>Services</option>
                                            <option>Self-employee</option>
                                            <option>Others</option>
                                        </select>
                                        <span class="val" id="occupationVal"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Other Skills:</label>
                                    <textarea class="form-control" rows="5" id="oskills" name="oskills"></textarea>
                                    <label class="val text-danger" id="oskillsVal"></label>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-primary" id="save">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- View Aids Details -->

        <div class="modal fade" id="aidModal" tabindex="-1" role="dialog" aria-labelledby="aidModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="aidModalLabel">View Aids</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="table-responsive">
                                <div class="container mt-3">
                                    <table class="table table-striped table-bordered table-sm" id="personalDetails_view">
                                        <thead>
                                            <tr>
                                                <th>Type of Aid</th>
                                                <th>Account No</th>
                                                <th>Donation No</th>
                                                <th>Donation Rs.</th>
                                                <th>Place of obtaining</th>
                                                <th>Other Details</th>
                                            </tr>
                                            <tbody id="aid-data"></tbody>
                                        </thead>
                                    </table>  
                                </div>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    <style>
        .val{
            color: red;
            font-size: 0.8rem;
        }
        .hide {
            display: none !important;
        }
    </style>
    </div>  
</div>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>

<script>
        $(document).ready(() => {
            $('#personalDetails_view').DataTable();
            $('#guardian').select2();

            var isChild = document.getElementById('isChild');
            $('#isChild').change(() => {
                if(isChild.checked){
                    $('[data-hide-on-child="true"]').addClass('hide');
                    $('[data-hide-on-child="false"]').removeClass('hide');
                }
                else{
                    $('[data-hide-on-child="false"]').addClass('hide');
                    $('[data-hide-on-child="true"]').removeClass('hide');
                }
            })

            $('#personname').on('change keyup', () => { valName(); })
            $('#hseno').on('change keyup',() => { valHouseno(); })
            $('#status').change(() => { valStatus(); })
            $('#gender').change(() => { valGender(); })
            $('#date').change(() => { valDate(); })
            $('#place').on ('change keyup',() => { valPlace(); })
            $('#idNo').on ('change keyup',() => { valID(); })
            $('#telno').on('change keyup',() => { valTelno(); })
            $('#email').change(() => { valEmail(); })
            $('#alive').change(() => { valAlive(); })
            $('#religion').change(() => { valReligion(); })
            $('#nationality').change(() => { valNationality(); })
            $('#education').change(() => { valEducation(); })
            $('#occupation').change(() => { valOccupation(); })
            $('#oskills').on('change keyup',() => { valOskills(); })
            $('#guardian').change(() => { validateGuard(); })
            $('#save').click(() => { save(); })
        })

            var dataId = -1;
            
            function save(){
                if(dataId < 0){
                    alert('Pick an object before edit!');
                    return;
                }

                if(isValid()){
                    var data = new FormData(document.getElementById('data'));
                    data.append('personname', $('#personname').val());
                    data.append('hseno', $('#hseno').val());
                    data.append('status', $('#status').val());
                    data.append('gender', $('#gender').val());
                    data.append('status', $('#status').val());
                    data.append('alive', $('#alive').val());
                    data.append('religion', $('#religion').val());
                    data.append('nationality', $('#nationality').val());
                    data.append('education', $('#education').val());
                    data.append('occupation', $('#occupation').val());
                    data.append('isChild', $('#isChild').prop('checked'));
                    data.append('parentId', $('#guardian').val());
                    data.append('id', dataId);

                    $.ajax({
                    type: 'post',
                    url: './controls/admin/update_personalData.php',
                    processData: false,
                    contentType: false,
                    data: data,
                    success: function(r) {
                        system_alert(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        $('#editor').modal('hide');
                    }
                });

                }
            }

        function edit(id){
            $('.val').html('');
            var data;
            var d = new FormData();
            d.append('Id', id);

            // ajax for get data by id

            $.ajax({
                    type: 'post',
                    url: './controls/admin/get_personalData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        data = JSON.parse(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        dataId = id;
                        $('#personname').val(data.personname).change();
                        $('#hseno').val(data.hseno).change();
                        $('#status').val(data.status);
                        $('#gender').val(data.gender);
                        $('#date').val(data.date);
                        $('#place').val(data.place);
                        $('#idNo').val(data.idNo);
                        $('#telno').val(data.telno);
                        $('#email').val(data.email);
                        $('#alive').val(data.alive);
                        $('#religion').val(data.religion);
                        $('#nationality').val(data.nationality);
                        $('#education').val(data.education);
                        $('#occupation').val(data.occupation);
                        $('#oskills').val(data.oskills);

                        $('#isChild').prop('checked', data.isChild).change();
                        $('#guardian').val(data.parentId).change();

                        $('#editor').modal('show');
                    }
            });
        }

        function remove(id){
            var d = new FormData();
            d.append('Id', id);
            dataId = id;
            // ajax for delete data

            $.ajax({
                    type: 'post',
                    url: './controls/admin/delete_personalData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        system_alert(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        $('#editor').modal('hide');
                    }
                });
        }

        function addVal(val, msg){
            val.html(msg);
        }

        function removeVal(val){
            val.html('');
        }

        function isValid(){
            return valName() & valHouseno() & valStatus() &
            valGender() & valDate() & valPlace() & valID() &
            valTelno() & valEmail() & valAlive() &valReligion() & 
            valNationality() & valEducation() & valOccupation() & 
            valOskills() & validateGuard();
        }

        function valName(){
            var inp = $('#personname')
            var val = $('#personnameVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Person Name is required'); return false;
            }

            removeVal(val); return true;
        }

        function valHouseno(){
            var inp = $('#hseno')
            var val = $('#hsenoVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'House No is required'); return false;
            }

            removeVal(val); return true;
        }

        function valStatus(){
            var inp = $('#status')
            var val = $('#statusVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Status is required'); return false;
            }

            removeVal(val); return true;
        }

        function valGender(){
            var inp = $('#gender')
            var val = $('#genderVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Gender is required'); return false;
            }

            removeVal(val); return true;
        }

        function valDate(){
            var inp = $('#date')
            var val = $('#dateVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Date of Birth is required'); return false;
            }

            removeVal(val); return true;
        }

        function valPlace(){
            var inp = $('#place')
            var val = $('#placeVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Birth place is required'); return false;
            }

            removeVal(val); return true;
        }

        function valID(){
            var isChild = $('#isChild').prop('checked');
            var inp = $('#idNo')
            var val = $('#idNoVal');
            if(!isChild){
                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'ID no is required'); return false;
                }

                removeVal(val); return true;
            }
            else{
                removeVal(val); return true;
            }
        }

        function valTelno(){
            var isChild = $('#isChild').prop('checked');
            var inp = $('#telno')
            var val = $('#telnoVal');
            
            if(!isChild){
                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Telephone number is required'); return false;
                }

                removeVal(val); return true;
            }
            else{
                removeVal(val); return true;
            }
        }

        function valEmail(){
            var isChild = $('#isChild').prop('checked');
            var inp = $('#email')
            var val = $('#emailVal');

            if(!isChild){
                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Email is required'); return false;
                }

                removeVal(val); return true;
            }
            else{
                removeVal(val); return true;
            }
        }

        function valAlive(){
            var inp = $('#alive')
            var val = $('#aliveVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Is alive is required'); return false;
            }

            removeVal(val); return true;
        }

        function valReligion(){
            var inp = $('#religion')
            var val = $('#religionVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Religion is required'); return false;
            }

            removeVal(val); return true;
        }

        function valNationality(){
            var inp = $('#nationality')
            var val = $('#nationalityVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Nationality is required'); return false;
            }

            removeVal(val); return true;
        }

        function valEducation(){
            var inp = $('#education')
            var val = $('#educationVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Education is required'); return false;
            }

            removeVal(val); return true;
        }

        function valOccupation(){
            var inp = $('#occupation')
            var val = $('#occupationVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Occupation is required'); return false;
            }

            removeVal(val); return true;
        }

        function valOskills(){
            var inp = $('#oskills')
            var val = $('#oskillsVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Other skills are required'); return false;
            }

            removeVal(val); return true;
        }

        function validateGuard(){
            if(isChild.checked){
                if($('#guardian').val() == null || $('#guardian').val() == ''){
                    addVal($('#guardianVal'), 'Child\'s guardian is required');
                    $('#guardian').focus();
                    return false;
                }

                removeVal($('#guardianVal'));
                return true;
            }
            else{
                removeVal($('#guardianVal'));
                return true;
            }
        }

        function viewAid(person_id){
            var x = new FormData();
            x.append('person_id', person_id);
            var data;

            $.ajax({
                type: 'post',
                url: './controls/admin/get_aid_data.php',
                processData: false,
                contentType: false,
                data: x,
                success: function(r) {
                    data = JSON.parse(r);
                },
                error: function() {
                    system_alert('Something went wrong!');
                },
                complete: function(){
                    var table = $('#aid-data');
                    table.empty();
                    
                    if(data.length > 0){
                        $.each(data, i => {
                            var r = `<tr>
                                <td>${data[i].type}</td>
                                <td>${data[i].account_no}</td>
                                <td>${data[i].donation}</td>
                                <td>${data[i].amount}</td>
                                <td>${data[i].place}</td>
                                <td>${data[i].other_details}</td>
                            </tr>`;
                            table.append(r);
                        });
                        $('#aidModal').modal('show');
                    }
                    else{
                        system_alert('No public assistant data!');
                    }
                }
            });
        }

</script>