        <div class="col-lg-12">
            <h2>Public Assistance & Other Details</h2>
                <hr>
                <div class="col-lg-12">
                        <form id="work_plan_forms" enctype="multipart/form-data">
                            <div class="form-group col-lg-6" style="float:left">
                                <label for="tpofad">Type of Aid:</label>
                                    <select class="form-control" id="typeofaid" name="tpofad">
                                       
                                        <option>Civil</option>
                                        <option>Forces</option>
                                        <option>Dependences</option>
                                        <option>Disabled</option>
                                        <option>Mahapola</option>
                                        <option>Scholarship</option>
                                        <option>Widow</option>
                                        <option>Other</option>
                                    </select>
                            </div>
                            <div class="form-group col-lg-6" style="float:left">
                                    <label for="accno">Account No:</label>
                                    <input type="text" class="form-control" id="accno">
                            </div>
                            <div class="form-group col-lg-6" style="float:left">
                                    <label for="dontno">Donation No:</label>
                                    <input type="text" class="form-control" id="dontno">
                            </div>
                            <div class="form-group col-lg-6" style="float:left">
                                    <label for="dontns">Donations Rs:</label>
                                    <input type="text" class="form-control" id="dontns">
                            </div>
                            <div class="form-group col-lg-12" style="float:left">
                                    <label for="plceofobtain">Place of Obtaining:</label>
                                    <input type="text" class="form-control" id="plceofobtain">
                            </div>
                            <div class="form-group col-lg-12" style="float:left">
                                    <label for="odetails">Other Details:</label>
                                    <textarea class="form-control" rows="12" id="odetails" name="text"></textarea>
                            </div>
                           <button type="submit" class="btn btn-primary">Submit</button> 
                           <button type="button" class="btn btn-dark">Cancel</button>
                        </form>
                </div>
        </div>
