<div class="col-lg-12">
    <h2> View Work Plan Details</h2>
    <hr>

    <div class="container">
        <div class="table-responsive">
            <div class="container mt-3">
    
                <table class="table table-striped table-bordered table-sm" id="workPlans_view">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Type of Work</th>
                            <th>Description</th>  
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            include '../../DB/conn.php';
                            global $connection;

                            $query = "SELECT * FROM `work_plan`";
                            $result = mysqli_query($connection, $query);
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    
                                    echo "
                                        <tr>
                                            <td>
                                                <button class=\"btn btn-sm btn-danger\" onclick='remove(".$row['idwork_plan'].")'><i class=\"fa fa-trash\"></i></button>
                                                <button class=\"btn btn-sm btn-primary\" onclick='edit(".$row['idwork_plan'].")'><i class=\"fa fa-edit\"></i></button>
                                            </td>
                                            <td>".$row['work_plan_date']."</td>
                                            <td>".$row['work_plan_time']."</td>
                                            <td>".$row['work_plan_type']."</td>
                                            <td>".$row['work_plan_description']."</td>
                                        </tr>
                                    ";
                                }
                            }
                        ?>     
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal fade" id="editor" tabindex="-1" role="dialog" aria-labelledby="editorLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editorLabel">Edit</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="data" enctype="multipart/form-data">
                            <div class="container">
                                <div class="form-group">
                                    <label>Date:</label>
                                    <input type="date" name="date" id="date" class="form-control form-control-sm" />
                                    <span class="val" id="dateVal"></span>
                                </div>
                                <div class="form-group">
                                    <label>Time:</label>
                                    <input type="time" name="time" id="time" class="form-control form-control-sm" />
                                    <span class="val" id="timeVal"></span>
                                </div>
                                <div class="form-group">
                                    <label>Type of Work:</label>
                                    <select id="type" class="form-control form-control-sm">
                                        <option value="Seminars">Seminars</option>
                                        <option value="Meetings">Meetings</option>
                                        <option value="Wesak Festival">Wesak Festival</option>
                                        <option value="Poson Festival">Poson Festival</option>
                                        <option value="Functions">Functions</option>
                                        <option value="Weddings">Weddings</option>
                                        <option value="Independence Day">Independence Day</option>
                                        <option value="Social Activities">Social Activities</option>
                                        <option value="Social Meetings">Social Meetings</option>
                                    </select>
                                    <span class="val" id="typeVal"></span>
                                </div>
                                <div class="form-group">
                                    <label>Description:</label>
                                    <textarea name="desc" id="desc" class="form-control form-control-sm"></textarea>
                                    <span class="val" id="descVal"></span>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-primary" id="save">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <style>
            .val{
                color: red;
                font-size: 0.8rem;
            }
        </style>                

        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#myTable tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                    });
                });

                $('#workPlans_view').DataTable();

                $('#date').change(() => { valDate(); })
                $('#time').change(() => { valTime(); })
                $('#type').change(() => { valType(); })
                $('#desc').on('change keyup', () => { valDesc(); })
                $('#save').click(() => { save(); })
            });

            var dataId = -1;
            function save(){
                if(dataId < 0){
                    alert('Pick an object before edit!');
                    return;
                }

                if(isValid()){
                    var data = new FormData(document.getElementById('data'));
                    data.append('type', $('#type').val());
                    data.append('id', dataId);

                    $.ajax({
                        type: 'post',
                        url: './controls/admin/update_workplanData.php',
                        processData: false,
                        contentType: false,
                        data: data,
                        success: function(r) {
                            system_alert(r);
                        },
                        error: function() {
                            system_alert('Something went wrong!');
                        },
                        complete: function(){
                            $('#editor').modal('hide');
                        }
                    });
                }
            }

            function edit(id){
                var data;
                var d = new FormData();
                d.append('Id', id);

                $.ajax({
                    type: 'post',
                    url: './controls/admin/get_workplanData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        data = JSON.parse(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        dataId = id;
                        $('#date').val(data.date);
                        $('#time').val(data.time);
                        $('#type').val(data.type);
                        $('#desc').val(data.desc);
                        $('#editor').modal('show');
                    }
                });
            }

            function remove(id){
                var d = new FormData();
                d.append('Id', id);

                $.ajax({
                        type: 'post',
                        url: './controls/admin/delete_workplanData.php',
                        processData: false,
                        contentType: false,
                        data: d,
                        success: function(r) {
                            system_alert(r);
                        },
                        error: function() {
                            system_alert('Something went wrong!');
                        },
                        complete: function(){
                            $('#editor').modal('hide');
                        }
                    });
            }

            function addVal(val, msg){
                val.html(msg);
            }

            function removeVal(val){
                val.html('');
            }

            function isValid(){
                return valDate() & valTime() &
                valType() & valDesc();
            }

            function valDate(){
                var inp = $('#date')
                var val = $('#dateVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Date is required'); return false;
                }

                removeVal(val); return true;
            }

            function valTime(){
                var inp = $('#time')
                var val = $('#timeVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Time is required'); return false;
                }

                removeVal(val); return true;
            }

            function valType(){
                var inp = $('#type')
                var val = $('#typeVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Type of work is required'); return false;
                }

                removeVal(val); return true;
            }

            function valDesc(){
                var inp = $('#desc')
                var val = $('#descVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Description is required'); return false;
                }

                removeVal(val); return true;
            }

        </script>

