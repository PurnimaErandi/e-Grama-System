
    <div class="container">
        <h3 class="heading"><b>Certificate on residence and character issued by the Grama Niladhari</b></h3>
        <div class="sub-text">
            This certificate is issued by the Grama Niladhari of the Division in which the applicant 
            resides is valid only for 06 months from the date countersigned by the Divisional Secretary.
        </div>
        
        <form id="char-cert" enctype="multipart/form-type">
            
            <!-- 1. Information about Grama Niladhari Division -->
            <div class="section">
                <h4 class="section-heading">1. Information about Grama Niladhari Division</h4>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-2">a) District: </div>
                        <div class="form-group col-lg-10">
                            <select class="form-control form-control-sm" id="districtList" name="districtList"></select>
                            <span class="val text-danger" id="districtListVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">b) Divisional Secratary's Division: </div>
                        <div class="form-group col-lg-9">
                            <select class="form-control form-control-sm" id="divSecList" name="divSecList"></select>
                            <span class="val text-danger" id="divSecListVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">c) Grama Niladhari Division and Number: </div>
                        <div class="form-group col-lg-8">
                            <select class="form-control form-control-sm" id="divNum" name="divNum">
                                <option value=""></option>
                                <option value="Batuwatta West Grama Niladhari Division">Batuwatta West Grama Niladhari Division</option>
                                <option value="Batuwatta East Grama Niladhari Division">Batuwatta East Grama Niladhari Division</option>
                                <option value="Dandugama Grama Niladhari Division">Dandugama Grama Niladhari Division</option>
                                <option value="Dehiyagatha Grama Niladhari Division">Dehiyagatha Grama Niladhari Division</option>
                                <option value="Ketakewatta Grama Niladhari Division">Ketakewatta Grama Niladhari Division</option>
                                <option value="Narangodapaluwa West Grama Niladhari Division">Narangodapaluwa West Grama Niladhari Division</option>
                                <option value="Narangodapaluwa East Grama Niladhari Division">Narangodapaluwa East Grama Niladhari Division</option>
                                <option value="Peralanda Grama Niladhari Division">Peralanda Grama Niladhari Division</option>
                                <option value="Thewatta Grama Niladhari Division">Thewatta Grama Niladhari Division</option>
                                <option value="Thudella North Grama Niladhari Division">Thudella North Grama Niladhari Division</option>
                            </select>
                            <span class="val text-danger" id="divNumVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">d) Whether applicant is personally known to the Grama Niladhari: </div>
                        <div class="form-group col-lg-6">
                            <select class="form-control form-control-sm" id="gnKnown" name="gnKnown">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="gnKnownVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-2">e) If so, since when: </div>
                        <div class="form-group col-lg-10">
                            <input type="date" class="form-control form-control-sm" id="sinceDate" name="sinceDate"/>
                            <span class="val text-danger" id="sinceDateVal"></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. Information about applicant -->
            <div class="section">
                <h4 class="section-heading">2. Information about applicant</h4>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-2">a) Name: </div>
                        <div class="form-group col-lg-10">
                            <input type="text" class="form-control form-control-sm" id="name" name="name"/>
                            <span class="val text-danger" id="nameVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-2">b) Address: </div>
                        <div class="form-group col-lg-10">
                            <textarea type="text" class="form-control form-control-sm" id="address" name="address"></textarea>
                            <span class="val text-danger" id="addressVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-2">c) Age: </div>
                        <div class="form-group col-lg-10">
                            <input type="number" class="form-control form-control-sm" id="age" name="age"/>
                            <span class="val text-danger" id="ageVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-2">d) Civil Status: </div>
                        <div class="form-group col-lg-10">
                            <select type="text" class="form-control form-control-sm" id="civilStat" name="civilStat">
                                <option id="0">Unmarried</option>
                                <option id="1">Married</option>
                            </select>
                            <span class="val text-danger" id="civilStatVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">e) Whether Sri Lankan?: </div>
                        <div class="form-group col-lg-9">
                            <select type="text" class="form-control form-control-sm" id="isSL" name="isSL">
                                <option id="0">No</option>
                                <option id="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="isSLVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">f) Religion: </div>
                        <div class="form-group col-lg-9">
                            <select type="text" class="form-control form-control-sm" id="religion" name="religion">
                                <option id="0"></option>
                                <option id="1">Buddhism</option>
                                <option id="2">Hinduism</option>
                                <option id="3">Islam</option>
                                <option id="4">Christianity</option>
                                <option id="5">Baháʼí Faith</option>
                                <option id="6">Others</option>
                            </select>
                            <span class="val text-danger" id="religionVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">g) Present Occupation: </div>
                        <div class="form-group col-lg-9">
                            <input type="text" class="form-control form-control-sm" id="occu" name="occu"/>
                            <span class="val text-danger" id="occuVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">h) Period of residence in the village: </div>
                        <div class="form-group col-lg-8">
                            <input type="text" class="form-control form-control-sm" id="res" name="res"/>
                            <span class="val text-danger" id="resVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">i) National Identity Card Number: </div>
                        <div class="form-group col-lg-9">
                            <input type="text" class="form-control form-control-sm" id="nic" name="nic" maxlength="12"/>
                            <span class="val text-danger" id="nicVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">j) Number of Electotial Register & Particulars of Registration: </div>
                        <div class="form-group col-lg-6">
                            <input type="text" class="form-control form-control-sm" id="elecReg" name="elecReg"/>
                            <span class="val text-danger" id="elecRegVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">k) Name and Address of the father: </div>
                        <div class="form-group col-lg-8">
                            <textarea class="form-control form-control-sm" id="fatherNameAddr" name="fatherNameAddr"></textarea>
                            <span class="val text-danger" id="fatherNameAddrVal"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5">l) Purpose for which the certificate is required: </div>
                        <div class="form-group col-lg-7">
                            <textarea class="form-control form-control-sm" id="certPurpose" name="certPurpose"></textarea>
                            <span class="val text-danger" id="certPurposeVal"></span>
                        </div>
                    </div>

                </div>
            </div>

            <!-- 3. Other Information -->
            <div class="section">
                <h4 class="section-heading">3. Other Information</h4>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-5">a) Period of the residence in the Grama Niladhari Division: </div>
                        <div class="form-group col-lg-7">
                            <input type="text" class="form-control form-control-sm" id="residPeriod" name="esidPeriod"/>
                            <span class="val text-danger" id="residPeriodVal"></span>
                        </div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-6">b) Nature of other evidences in proof of the period of residence: </div>
                        <div class="form-group col-lg-6">
                            <input type="text" class="form-control form-control-sm" id="natureResEvd" name="natureResEvd"/>
                            <span class="val text-danger" id="natureResEvdVal"></span>
                        </div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-6">c) Whether the applicant has been convicted by Court of Law?: </div>
                        <div class="form-group col-lg-6">
                            <textarea class="form-control form-control-sm" id="convByLaw" name="convByLaw"></textarea>
                            <span class="val text-danger" id="convByLawVal"></span>
                        </div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-6">d) Whether he/she has taken an interest in public activities social services work community work etc.: </div>
                        <div class="form-group col-lg-6">
                            <textarea class="form-control form-control-sm" id="act" name="act"></textarea>
                            <span class="val text-danger" id="actVal"></span>
                        </div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="row">
                        <div class="col-lg-2">e) His/her character: </div>
                        <div class="form-group col-lg-10">
                            <textarea class="form-control form-control-sm" id="charc" name="charc"></textarea>
                            <span class="val text-danger" id="charcVal"></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 4. Remark -->
            <div class="section">
                <h4 class="section-heading">4. Remark</h4>
                <div class="section-content">
                    <div class="row">
                        <div class="form-group col-lg-12">
                            <textarea placeholder="Enter Remark..." class="form-control form-control-sm" id="remark" name="remark"></textarea>
                            <span class="val text-danger" id="remarkVal"></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Declaration -->
            <div class="section">
                <div class="section-content dec-text">
                    It is hereby certified that the above particulars are correct to the best of my 
                    knowledge, he/she is a citizen of Sri Lanka by descent/registration, his/her Certificate
                    of Registration Number is 
                    <input type="text" class="dec form-control form-control-sm" placeholder="Registration number..." id="regNum" name="regNum"/>
                    and that it has been issued by 
                    <input type="text" class="dec form-control form-control-sm" placeholder="Issuer..." id="issueBy" name="issueBy"/>.
                </div>

            </div>
        
        </form>
        
        <div class="controls">
            <button class="btn btn-primary btn-sm" id="submit">Submit</button>
            <button class="btn btn-outline-secondary btn-sm" id="clear">Clear</button>
            <!-- <button class="btn btn-secondary btn-sm" id="print">Print</button> -->
        </div>
    </div>
    
    <!-- Confirm window -->
    <div class="modal" id="confirm-window" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Create Character Certificate</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="row">
                        <div>Select Person</div>
                        <select class="form-control form-control-sm" id="person-list">
                            <?php
                            include '../../DB/conn.php';
                            global $connection;

                            $query = "SELECT * FROM `person`";
                            $result = mysqli_query($connection, $query);
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<option value=". $row["idperson"] .">".$row["nameof_person"]." (".$row["nic"].")</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" id="save-form">Save changes</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="./css/character-form.css"/>
    <script src="./js/character-form.js"></script>

