<div class="col-lg-12">
   <h2> View Property Details</h2>
   <hr>
   <div class='col-lg-12'>
      <ul class="nav nav-tabs" role="tablist">
         <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#home">Property Management Details</a>
         </li>
         <li class="nav-item">
            <a class="nav-link" data-toggle="tab"  href="#menu1">Household Basic Details</a>
         </li>
      </ul>
      <div class="tab-content" >
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
            <div class="container">
               <div class="table-responsive">
                  <div class="container mt-3">
                     <table class="table table-striped table-bordered table-sm" id="propManagementnew_view">
                        <thead>
                           <tr>
                              <th>Action&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Grama Niladhari Office&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Purchase of Land</th>
                              <th>Major Crop</th>
                              <th>House Latitude</th>
                              <th>House Longitude</th>
                              <th>Village/Street Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Water</th>
                              <th>Lights</th>
                              <th>Toilets</th>
                              <th>Garbage</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              include '../../DB/conn.php';
                               global $connection;
                              
                               $query = "SELECT * FROM `property`";
                               $result = mysqli_query($connection, $query);
                               if (mysqli_num_rows($result) > 0) {
                                   while ($row = mysqli_fetch_assoc($result)) {
                              
                                       $w = $row['water'] == "1" ? 'Yes' : 'No';
                                       $l = $row['lights'] == "1" ? 'Yes' : 'No';
                                       $t = $row['toilets'] == "1" ? 'Yes' : 'No';
                                       $g = $row['garbage'] == "1" ? 'Yes' : 'No';
                              
                                       echo "
                                           <tr>
                                               <td>
                                                   <button class=\"btn btn-sm btn-danger\" onclick='removeProperty(".$row['idproperty'].")'><i class=\"fa fa-trash\"></i></button>
                                                   <button class=\"btn btn-sm btn-primary\" onclick='editProperty(".$row['idproperty'].")'><i class=\"fa fa-edit\"></i></button>
                                               </td>
                                               <td>".$row['grama_niladhari_office']."</td>
                                               <td>".$row['address']."</td>
                                               <td>".$row['purchase_of_land']."</td>
                                               <td>".$row['major_crops']."</td>     
                                               <td>".$row['house_latitude']."</td>
                                               <td>".$row['house_longitude']."</td>
                                               <td>".$row['villagestreet_name']."</td>    
                                               <td>".$w."</td>
                                               <td>".$l."</td>  
                                               <td>".$t."</td>
                                               <td>".$g."</td>
                                           </tr>
                                        ";
                                   }
                               }
                              
                              
                              ?>     
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
         <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#myTable tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                    });
                });
            });
            $(document).ready(function () {
                $('#propManagementnew_view').DataTable();
            });
            
         </script>
         <div class="tab-pane fade" id="menu1" role="tabpanel" aria-labelledby="menu1-tab">
            <div class="container">
               <div class="table-responsive">
                  <div class="container mt-3">
                     <table class="table table-striped table-bordered table-sm" id="houseManagement_view">
                        <thead>
                           <tr>
                              <th>Action&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>House Name</th>
                              <th>House Status&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>House Type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Walls&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Floor</th>
                              <th>Roof&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>House Built Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Other Details&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                              <th>Radio</th>
                              <th>Television</th>
                              <th>Landline Phones</th>
                              <th>Mobile Phones</th>
                              <th>Desktop Computer</th>
                              <th>Laptop</th>
                              <th>Internet Connections</th>
                              <th>Washing Machine</th>
                              <th>Refrigerator</th>
                              <th>Air Conditioner</th>
                              <th>Gas Cooker</th>
                              <th>Rice Cooker</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              include '../../DB/conn.php';
                              global $connection;
                              
                                      $query = "SELECT * FROM `house`";
                                      $result = mysqli_query($connection, $query);
                                      if (mysqli_num_rows($result) > 0) {
                                          while ($row = mysqli_fetch_assoc($result)) {
                              
                                              $a = $row['radio'] == "1" ? 'Yes' : 'No';
                                              $b = $row['television'] == "1" ? 'Yes' : 'No';
                                              $c = $row['landline_phones'] == "1" ? 'Yes' : 'No';
                                              $d = $row['mobile_phones'] == "1" ? 'Yes' : 'No';
                                              $e = $row['desktop_computer'] == "1" ? 'Yes' : 'No';
                                              $f = $row['laptop'] == "1" ? 'Yes' : 'No';
                                              $g = $row['internet_connections'] == "1" ? 'Yes' : 'No';
                                              $h = $row['washing_machine'] == "1" ? 'Yes' : 'No';
                                              $i = $row['refrigerator'] == "1" ? 'Yes' : 'No';
                                              $j = $row['air_conditioner'] == "1" ? 'Yes' : 'No';
                                              $k = $row['gas_cooker'] == "1" ? 'Yes' : 'No';
                                              $l = $row['rice_cooker'] == "1" ? 'Yes' : 'No';
                              
                                              echo "
                                                  <tr>
                                                      <td>
                                                          <button class=\"btn btn-sm btn-danger\" onclick='removeHouse(".$row['house_no'].")'><i class=\"fa fa-trash\"></i></button>
                                                          <button class=\"btn btn-sm btn-primary\" onclick='editHouse(".$row['house_no'].")'><i class=\"fa fa-edit\"></i></button>
                                                      </td>
                                                      <td>".$row['house_name']."</td>
                                                      <td>".$row['house_status']."</td>
                                                      <td>".$row['house_type']."</td>
                                                      <td>".$row['walls']."</td>
                                                      <td>".$row['floor']."</td>
                                                      <td>".$row['roofs']."</td>
                                                      <td>".$row['house_built_date']."</td>
                                                      <td>".$row['other_details']."</td>     
                                                      <td>".$a."</td>
                                                      <td>".$b."</td>  
                                                      <td>".$c."</td>
                                                      <td>".$d."</td>
                                                      <td>".$e."</td>
                                                      <td>".$f."</td>  
                                                      <td>".$g."</td>
                                                      <td>".$h."</td>
                                                      <td>".$i."</td>
                                                      <td>".$j."</td>  
                                                      <td>".$k."</td>
                                                      <td>".$l."</td>
                                                  </tr>
                                               ";
                                          }
                                      }
                              
                              
                              
                              ?>     
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<!-- Property edit window -->
    <div class="modal fade" id="propertyWindow" tabindex="-1" role="dialog" aria-labelledby="propertyWindowLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="propertyWindowLabel">Edit</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="propertyForm" enctype="multipart/form-data">
                        <div class="container">
                            <div class="form-group">
                                <label>Grama Niladhari Office</label>
                                <select id="gnoffice" class="form-control form-control-sm">
                                    <option>Batuwatta East GN Division</option>
                                    <option>Batuwatta West GN Division</option>
                                    <option>Batagama North GN Division</option>
                                    <option>Dambuwa GN Division</option>
                                    <option>Kandana East GN Division</option>
                                    <option>Nagoda GN Division</option>
                                    <option>Nedurupitya GN Division</option>
                                    <option>Narangodapaluwa East GN Division</option>
                                    <option>Narangodapaluwa West GN Division</option>
                                    <option>Wishakawatta GN Division</option>
                                    <option>Yakkaduwa GN Division</option>
                                </select>
                                <span class="val" id="gnofficeVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Address:</label>
                                <textarea name="address" id="address" class="form-control form-control-sm"></textarea>
                                <span class="val" id="addressVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Purchase of Land:</label>
                                <input type="number" class="form-control form-control-sm" id="purchaseland" name="purchofland">
                                <span class="val" id="purchaselandVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Major Crops:</label>
                                <textarea name="crops" id="crops" class="form-control form-control-sm"></textarea>
                                <span class="val" id="cropsVal"></span>
                            </div>
                             
                            <div class="row"> 
                                <div class="form-group col-md-6">
                                    <label>House Latitude:</label>
                                    <input type="number" step="0.0001" class="form-control form-control-sm" id="lati" name="lati">
                                    <span class="val" id="latiVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>House Longitude:</label>
                                    <input type="number" step="0.0001" class="form-control form-control-sm"  id="long" name="long">
                                    <span class="val" id="longVal"></span>
                                </div>
                            </div> 

                            <div class="form-group">
                                <a class="btn btn-info btn-block inform-btn" id="setLoction">Set Current Location</a>
                            </div>
                            <div class="form-group">
                                <label>Village/Street Name:</label>
                                <textarea name="streetname" id="streetname" class="form-control form-control-sm"></textarea>
                                <span class="val" id="streetnameVal"></span>
                            </div>
                        
                            <h6>Other Infrastructure Details</h6> 
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Water</label>
                                    <select id="water" class="form-control form-control-sm" name="water">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="waterVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Lights:</label>
                                    <select id="lights" class="form-control form-control-sm" name="lights">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="lightsVal"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label>Toilets</label>
                                    <select id="toilets" class="form-control form-control-sm" name="toilets">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="toiletsVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Garbage</label>
                                    <select id="garbage" class="form-control form-control-sm" name="garbage">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="garbageVal"></span>
                                </div>  
                            </div>    
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-primary" id="saveProperty">Save</button>
                </div>
            </div>
        </div>
    </div>

<!-- Location picker -->
    <div class="modal fade" id="locationPicker" tabindex="-1" role="dialog" aria-labelledby="locationPickerLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="locationPickerLabel">Location Picker</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div id="map"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <style>
        .val{
            color: red;
            font-size: 0.8rem;
        }
        .select2-container{
            width: 100%!important;
        }
        .control-box{
            text-align: right;
        }
        .inform-btn {
            color: white!important;
        }
        #map{
            width: 100%;
            height: 400px;
            background-color: #ddd;
            border-radius: 8px;
        }
    </style>

<!--House edit window -->
<div class="modal fade" id="houseWindow" tabindex="-1" role="dialog" aria-labelledby="editorLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editorLabel">Edit</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="houseForm" enctype="multipart/form-data">
                        <div class="container">
                            <div class="form-group">
                                <label>House Name:</label>
                                <textarea name="housename" id="housename" class="form-control form-control-sm"></textarea>
                                <span class="val" id="housenameVal"></span>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6" >
                                    <label>House Status:</label>
                                    <select id="husestatus" class="form-control form-control-sm">
                                        <option>- Please Select -</option>
                                        <option>Freehold houses</option>
                                        <option>Free of rent</option>
                                        <option>Government-owned rent</option>
                                        <option>Government owned taxes</option>
                                        <option>Illegal</option>
                                        <option>Private rental houses</option>
                                        <option>Other</option>
                                    </select>
                                    <span class="val" id="hstatusVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>House Type:</label>
                                    <select id="husetype" class="form-control form-control-sm">
                                        <option>- Please Select -</option>
                                        <option>Apartment</option>
                                        <option>Flat</option>
                                        <option>Line rooms</option>
                                        <option>Single storey house</option>
                                        <option>Two storey house</option>
                                        <option>More than two storey house</option>
                                        <option>Sub house</option>
                                        <option>Shanty house</option>
                                        <option>Other</option>
                                    </select>
                                    <span class="val" id="husetypeVal"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label>Walls:</label>
                                    <select id="walls" class="form-control form-control-sm">
                                        <option>- Please Select -</option>
                                        <option>Bricks</option>
                                        <option>Cement stones</option>
                                        <option>Coconut branches</option>
                                        <option>Glass</option>
                                        <option>Kabok Stones</option>
                                        <option>Stones</option>
                                        <option>Palm branches</option>
                                        <option>Partition Wall</option>
                                        <option>Pottery & ceramics clay</option>
                                        <option>Wood Paneling</option>
                                        <option>Other</option>
                                    </select>
                                    <span class="val" id="wallsVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Floor:</label>
                                    <select id="floor" class="form-control form-control-sm">
                                        <option>- Please Select -</option>
                                        <option>Cement</option>
                                        <option>Concreate</option>
                                        <option>Teraso</option>
                                        <option>Granite</option>
                                        <option>Sand</option>
                                        <option>Pottery & ceramics clay</option>
                                        <option>Wood</option>
                                        <option>Other</option>
                                    </select>
                                    <span class="val" id="floorVal"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label>Roof:</label>
                                    <select id="roof" class="form-control form-control-sm" name="roof">
                                    <option>- Please Select -</option>
                                    <option>Aluminium sheets</option>
                                    <option>Concreate</option>
                                    <option>Coconut branches</option>
                                    <option>Sheets</option>
                                    <option>Asbastos</option>
                                    <option>other</option>
                                    </select>
                                    <span class="val" id="roofVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Start Date of Duty:</label>
                                    <input type="date" id="date" name="date" class="form-control form-control-sm" /> 
                                    <span class="val" id="dateVal"></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Other Details:</label>
                                <textarea class="form-control" rows="4" id="odetails" name="odetails"></textarea>
                                <label class="val text-danger" id="odetailsVal"></label>
                            </div>

                            <h6>Other Infrastructure Details</h6> 
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Radio:</label>
                                    <select id="radio" class="form-control form-control-sm" name="radio">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="radioVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Television:</label>
                                    <select id="tv" class="form-control form-control-sm" name="tv">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="tvVal"></span>
                                </div>
                            </div>
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Landline Phones:</label>
                                    <select id="landphone" class="form-control form-control-sm" name="landphone">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="landphoneVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Mobile Phones:</label>
                                    <select id="mobphone" class="form-control form-control-sm" name="mobphone">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="mobphoneVal"></span>
                                </div>
                            </div> 
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Desktop Computer:</label>
                                    <select id="desktop" class="form-control form-control-sm" name="desktop">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="desktopVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Laptop:</label>
                                    <select id="laptop" class="form-control form-control-sm" name="laptop">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="laptopVal"></span>
                                </div>
                            </div>
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Internet Connections:</label>
                                    <select id="internet" class="form-control form-control-sm" name="internet">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="internetVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Washing Machine:</label>
                                    <select id="washmachine" class="form-control form-control-sm" name="washmachine">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="washmachineVal"></span>
                                </div>
                            </div>
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Refrigerator:</label>
                                    <select id="refrig" class="form-control form-control-sm" name="refrig">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="refrigVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Air Conditioner:</label>
                                    <select id="aircondi" class="form-control form-control-sm" name="aircondi">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="aircondiVal"></span>
                                </div>
                            </div>
                            <div class="row">    
                                <div class="form-group col-md-6">
                                    <label>Gas Cooker:</label>
                                    <select id="gascook" class="form-control form-control-sm" name="gascook">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="gascookVal"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Rice Cooker:</label>
                                    <select id="ricecook" class="form-control form-control-sm" name="ricecook">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                    </select>
                                    <span class="val" id="ricecookVal"></span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-primary" id="saveHouse">Save</button>
                </div>
            </div>
        </div>
    </div>
<script>
   $(document).ready(function () {
       $("#myInput").on("keyup", function () {
           var value = $(this).val().toLowerCase();
           $("#myTable tr").filter(function () {
               $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
           });
       });
   });
   $(document).ready(function () {
       $('#houseManagement_view').DataTable();
      // $('.dataTables_length').addClass('bs-select');
   });
</script>

<!-- Edit windows -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCMrsWm_ka2vGqme0Uv5IDFYk0frGQ74OY&callback=initMap&libraries=&v=weekly" async differ></script>
<script>
        $(document).ready(() => {
            $('#gnoffice').change(() => { valGnoffice(); })
            $('#address').on('change keyup', () => { valAddress(); })
            $('#purchaseland').change(() => { valPurchaseland(); })
            $('#crops').on('change keyup', () => { valCrops(); }) 
            $('#lati').change(() => { valLati(); })
            $('#long').change(() => { valLong(); })
            $('#streetname').on('change keyup', () => { valStreetname(); }) 
            $('#water').change(() => { valWater(); })
            $('#lights').change(() => { valLights(); })
            $('#toilets').change(() => { valToilets(); })
            $('#garbage').change(() => { valGarbage(); })
            $('#saveProperty').click(() => { saveProperty(); })

            $('#housename').change(() => { valHousename(); })
            $('#husestatus').change(() => { valHusestatus(); })
            $('#husetype').change(() => { valHusetype(); })
            $('#walls').change(() => { valWalls(); })
            $('#floor').change(() => { valFloor(); })
            $('#roof').change(() => { valRoof(); })
            $('#date').change(() => { valDate(); })
            $('#odetails').on('change keyup', () => { valOdetails(); })
            $('#radio').change(() => { valRadio(); })
            $('#tv').change(() => { valTv(); })
            $('#mobphone').change(() => { valMobphone(); })
            $('#landphone').change(() => { valMobphone(); })
            $('#desktop').change(() => { valDesktop(); })
            $('#laptop').change(() => { valLaptop(); })
            $('#internet').change(() => { valInternet(); })
            $('#washmachine').change(() => { valWashmachine(); })
            $('#refrig').change(() => { valRefrig(); })
            $('#aircondi').change(() => { valAircondi(); })
            $('#gascook').change(() => { valGascook(); })
            $('#ricecook').change(() => { valRicecook(); })
            $('#saveHouse').click(() => { saveHouse(); })
        })

        var propertyDataID = -1;
        function saveProperty(){
            if(propertyDataID < 0){
                alert('Pick an object before edit!');
                return;
            }

            if(isValid()){
                var data = new FormData(document.getElementById('propertyForm'));
                data.append('gnoffice', $('#gnoffice').val());
                data.append('id', propertyDataID);

                $.ajax({
                    type: 'post',
                    url: './controls/admin/update_propertyData.php',
                    processData: false,
                    contentType: false,
                    data: data,
                    success: function(r) {
                        system_alert(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        $('#propertyWindow').modal('hide');
                    }
                });
            }
        }

        function editProperty(id){
            var data;
            var d = new FormData();
            d.append('Id', id);

            // ajax for get data by id

            $.ajax({
                    type: 'post',
                    url: './controls/admin/get_propertyData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        data = JSON.parse(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        propertyDataID = id;
                        $('#gnoffice').val(data.gnoffice).change();
                        $('#address').val(data.address);
                        $('#purchaseland').val(data.purchaseland);
                        $('#crops').val(data.crops);
                        $('#lati').val(data.lati);
                        $('#long').val(data.long);
                        $('#streetname').val(data.streetname);
                        $('#water').val(data.water);
                        $('#lights').val(data.lights);
                        $('#toilets').val(data.toilets);
                        $('#garbage').val(data.garbage);
                        $('#propertyWindow').modal('show');
                    }
            });
        }

        function removeProperty(id){
            var d = new FormData();
            d.append('Id', id);
            propertyDataID = id;
            // ajax for delete data

            $.ajax({
                    type: 'post',
                    url: './controls/admin/delete_propertyData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        system_alert(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        $('#propertyWindow').modal('hide');
                    }
                });
        }

        function addVal(val, msg){
            val.html(msg);
        }

        function removeVal(val){
            val.html('');
        }

        function isValid(){
                return valGnoffice() & valAddress() &
                valPurchaseland() & valCrops() & valLati() & 
                valLong() & valStreetname() & valWater() & 
                valLights() & valToilets() & valGarbage();
        }

        function valGnoffice(){
            var inp = $('#gnoffice')
            var val = $('#gnofficeVal');

            
            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Grama Niladhari Office is required'); return false;
            }

            removeVal(val); return true;
        }

        function valAddress(){
            var inp = $('#address')
            var val = $('#addressVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Address is required'); return false;
            }

            removeVal(val); return true;
        }

        function valPurchaseland(){
            var inp = $('#purchaseland')
            var val = $('#purchaselandVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Purchase of land is required'); return false;
            }

            removeVal(val); return true;
        }
           
        function valCrops(){
            var inp = $('#crops')
            var val = $('#cropsVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Major crop is required'); return false;
            }

            removeVal(val); return true;
        }

        function valLati(){
            var inp = $('#lati')
            var val = $('#latiVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Latitude is required'); return false;
            }

            removeVal(val); return true;
        }
               
        function valLong(){
            var inp = $('#long')
            var val = $('#longVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Longitude is required'); return false;
            }

            removeVal(val); return true;
        }

        function valStreetname(){
            var inp = $('#streetname')
            var val = $('#streetnameVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Village/Street name is required'); return false;
            }

            removeVal(val); return true;
        }

        function valWater(){
            var inp = $('#water')
            var val = $('#waterVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Water details are required'); return false;
            }

            removeVal(val); return true;
        }

        function valLights(){
            var inp = $('#lights')
            var val = $('#lightsVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, ' Lights details are required'); return false;
            }

            removeVal(val); return true;
        }

        function valToilets(){
            var inp = $('#toilets')
            var val = $('#toiletsVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Toilets details are required'); return false;
            }

            removeVal(val); return true;
        }

        function valGarbage(){
            var inp = $('#garbage')
            var val = $('#garbageVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Garbage details are required'); return false;
            }

            removeVal(val); return true;
        }

        /* For house */
        var houseDataID = -1;
        function saveHouse(){
            if(houseDataID < 0){
                alert('Pick an object before edit!');
                return;
            }

            if(isValidHouse()){
                var data = new FormData(document.getElementById('houseForm'));
                data.append('husestatus', $('#husestatus').val());
                data.append('type', $('#type').val());
                data.append('husetype', $('#husetype').val());
                data.append('walls', $('#walls').val());
                data.append('floor', $('#floor').val());
                data.append('roof', $('#roof').val());
                data.append('id', houseDataID);

                $.ajax({
                    type: 'post',
                    url: './controls/admin/update_HouseData.php',
                    processData: false,
                    contentType: false,
                    data: data,
                    success: function(r) {
                        system_alert(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        $('#houseWindow').modal('hide');
                    }
                });
            }
        }

        function editHouse(id){
            var data;
            var d = new FormData();
            d.append('Id', id);

            // ajax for get data by id

            $.ajax({
                    type: 'post',
                    url: './controls/admin/get_houseData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        data = JSON.parse(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        houseDataID = id;
                        $('#housename').val(data.housename);
                        $('#husestatus').val(data.husestatus);
                        $('#husetype').val(data.husetype);
                        $('#walls').val(data.walls);
                        $('#floor').val(data.floor);
                        $('#roof').val(data.roof);
                        $('#date').val(data.date);
                        $('#odetails').val(data.odetails);
                        $('#radio').val(data.radio);
                        $('#tv').val(data.tv);
                        $('#mobphone').val(data.mobphone);
                        $('#landphone').val(data.landphone);
                        $('#desktop').val(data.desktop);
                        $('#laptop').val(data.laptop);
                        $('#internet').val(data.internet);
                        $('#washmachine').val(data.washmachine)
                        $('#refrig').val(data.refrig);
                        $('#aircondi').val(data.aircondi);
                        $('#gascook').val(data.gascook);
                        $('#ricecook').val(data.ricecook);
                        $('#houseWindow').modal('show');
                    }
            });
            
        }

        function removeHouse(id){
            var d = new FormData();
            d.append('Id', id);
            houseDataID = id;
            // ajax for delete data

            $.ajax({
                    type: 'post',
                    url: './controls/admin/delete_houseData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        system_alert(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        $('#houseWindow').modal('hide');
                    }
                });
        }

        function isValidHouse(){
                return valHousename() &valHusestatus() & 
                valHusetype() &  valWalls() & valFloor() & 
                valRoof() & valDate() & valOdetails() &
                valRadio() & valTv() & valLandphone() & valMobphone() & 
                valDesktop() & valLaptop() & valInternet() & valWashmachine() & 
                valRefrig() & valAircondi() & valGascook() & valRicecook();
        }

        

        function valHousename(){
            var inp = $('#housename')
            var val = $('#housenameVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, ''); return false;
            }

            removeVal(val); return true;
        }

        function valHusestatus(){
            var inp = $('#husestatus')
            var val = $('#husestatusVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'House Status is required'); return false;
            }

            removeVal(val); return true;
        }
           
        function valHusetype(){
            var inp = $('#husetype')
            var val = $('#husetypeVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'House type is required'); return false;
            }

            removeVal(val); return true;
        }

        function valWalls(){
            var inp = $('#walls')
            var val = $('#wallsVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Wall is required'); return false;
            }

            removeVal(val); return true;
        }
            
            
        function valFloor(){
            var inp = $('#floor')
            var val = $('#floorVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Floor is required'); return false;
            }

            removeVal(val); return true;
        }

        function valRoof(){
            var inp = $('#roof')
            var val = $('#roofVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Roof type is required'); return false;
            }

            removeVal(val); return true;
        } 

        function valDate(){
            var inp = $('#date')
            var val = $('#dateVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Built date is required'); return false;
            }

            removeVal(val); return true;
        }

        function valOdetails(){
            var inp = $('#odetails')
            var val = $('#odetailsVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Other details are required'); return false;
            }

            removeVal(val); return true;
        }

        function valRadio(){
            var inp = $('#radio')
            var val = $('#radioVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Radio is required'); return false;
            }

            removeVal(val); return true;
        }

        function valTv(){
            var inp = $('#tv')
            var val = $('#tvVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Television is required'); return false;
            }

            removeVal(val); return true;
        }

        function valLandphone(){
            var inp = $('#landphone')
            var val = $('#landphoneVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Landline is required'); return false;
            }

            removeVal(val); return true;
        }

        function valMobphone(){
            var inp = $('#mobphone')
            var val = $('#mobphoneVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Mobile phone is required'); return false;
            }

            removeVal(val); return true;
        }

        function valDesktop(){
            var inp = $('#desktop')
            var val = $('#desktopVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Desktop is required'); return false;
            }

            removeVal(val); return true;
        }

        function valLaptop(){
            var inp = $('#laptop')
            var val = $('#laptopVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Laptop is required'); return false;
            }

            removeVal(val); return true;
        }

        function valInternet(){
            var inp = $('#internet')
            var val = $('#internetVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Internet is required'); return false;
            }

            removeVal(val); return true;
        }

        function valWashmachine(){
            var inp = $('#washmachine')
            var val = $('#washmachineVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Washing machine is required'); return false;
            }

            removeVal(val); return true;
        }

        function valRefrig(){
            var inp = $('#refrig')
            var val = $('#refrigVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Refrigerator is required'); return false;
            }

            removeVal(val); return true;
        }

        function valAircondi(){
            var inp = $('#aircondi')
            var val = $('#aircondiVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Air conditioner is required'); return false;
            }

            removeVal(val); return true;
        }

        function valGascook(){
            var inp = $('#gascook')
            var val = $('#gascookVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'gas cooker is required'); return false;
            }

            removeVal(val); return true;
        }

        function valRicecook(){
            var inp = $('#ricecook')
            var val = $('#ricecookVal');

            if(inp.val() == '' || inp.val() == null){
                addVal(val, 'Rice cooker is required'); return false;
            }

            removeVal(val); return true;
        }
    </script>

<script>
        var lati = $('#lati');
        var longi = $('#long');

        $(document).ready(() => {
            $('#setLoction').click(() => { $('#locationPicker').modal('show'); initMap(); })
        });

        function initMap(){
            const initial = { lat: 7.0415740944018115, lng: 79.939904131782 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 15,
                center: initial,
            });

            let tagWindow = new google.maps.InfoWindow({
                content: "Click on the map where you want to select",
                position: initial,
            });

            tagWindow.open(map);

            map.addListener('click', e => {
                tagWindow.close();

                tagWindow = new google.maps.InfoWindow({
                    position: e.latLng,
                });

                var loc = e.latLng.toJSON();
                tagWindow.setContent(JSON.stringify(loc, null, 2));
                tagWindow.open(map);

                lati.val(loc.lat.toFixed(16));
                longi.val(loc.lng.toFixed(16));

                $('#locationPicker').modal('hide');
            });
        }
</script>