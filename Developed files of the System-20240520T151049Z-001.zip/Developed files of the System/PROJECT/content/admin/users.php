
<div class="container">
    <div class="row header">
        <div class="col-9 header-topic">
            <b>Register New User</b>
        </div>
        <div class="col-3 header-button-box">
            <button title="Add New User" class="add-user" id="addUser"><i class="fa fa-user-plus"></i></button>
        </div>
    </div>
    <div class="row search-box">
        <input type="text" class="form-control form-control-sm" placeholder="Search User..." id="searchUser" />
    </div>

    <div class="user-list">
        <table class="table table-striped">
            <thead>
            <th scope="col">Action</th>
            <th scope="col">Profile Picture</th>
            <th scope="col">Username</th>
            <th scope="col">Full Name</th>
            <th scope="col">Email</th>
            <th scope="col">NIC</th>
            <th scope="col">Role</th>
            </thead>
            <tbody class="user-list-body">

                <?php
                include '../../DB/conn.php';

                global $connection;
                session_start();
                $adminId = $_SESSION['LogId'];
                
                $q = "SELECT u.*, r.`role_name` FROM `user` u INNER JOIN `role` r ON u.user_role_iduser_role = r.role_id "
                        . "WHERE r.role_name <> 'User'";
                $r = mysqli_query($connection, $q);
                $users = array();
                if (mysqli_num_rows($r) > 0) {
                    while ($row = mysqli_fetch_assoc($r)) {
                        $iduser = $row['iduser'];
                        $user_fullname = $row['user_fullname'];
                        $user_email = $row['user_email'];
                        $user_uname = $row['user_uname'];
                        $user_nic = $row['user_nic'];
                        $user_imgPath = $row['user_imgPath'];
                        $user_role = $row['role_name'];
                        
                        $user_imgPath = str_replace("/..", "", $user_imgPath);

                        echo ' <tr>
                                    <td class="data-middle">';
                                        if($adminId != $iduser && $user_role != "Super Admin"){
                                            echo '<i class="fa fa-trash del" onclick="remove('.$iduser.')" title="Delete User"></i>';
                                        }
                                        
                                        
                                        echo '</td>
                                            <td class="data-middle">
                                            <div class="img-cont">
                                                <a href="'.$user_imgPath.'" target="_blank">
                                                <img class="prof-pic-src" src="'.$user_imgPath.'" width="64" height="64" alt="profile-pic"/>
                                                </a>
                                            </div>
                                        </td>
                                        <td class="data-middle data">'.$user_uname.'</td>
                                        <td class="data-middle data">'.$user_fullname.'</td>
                                        <td class="data-middle data">'.$user_email.'</td>
                                        <td class="data-middle data">'.$user_nic.'</td>
                                        <td class="data-middle data">'.$user_role.'</td>
                                </tr>';
                        
                    }
                }
                ?>



            </tbody>
        </table>
    </div>
</div>

<!-- Add user -->
<div class="modal fade" id="add-user-window" tabindex="-1" role="dialog" aria-labelledby="lbladdUser" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
            <div class="modal-header">
                <h6 class="modal-title" id="lblNewAid">Add New User</h6>
                <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <form id="userData" enctype="multipart/form-data">
                        <div class="row group">
                            <label>Username</label>
                            <input type="text" class="form-control form-control-sm" placeholder="Username" id="uname" name="uname">
                            <span class="red val" id="unameVal"></span>
                        </div>
                        <div class="row group">
                            <label>Password</label>
                            <input type="password" autocomplete="" class="form-control form-control-sm" placeholder="Password" id="pword" name="pword">
                            <span class="red val" id="pwordVal"></span>
                        </div>
                        <div class="row group">
                            <label>Re-Enter Password</label>
                            <input type="password" autocomplete="" class="form-control form-control-sm" placeholder="Re-Enter Password" id="repass">
                            <span class="red val" id="repassVal"></span>
                        </div>
                        <div class="row group">
                            <label>Full Name</label>
                            <input type="text" autocomplete="" class="form-control form-control-sm" placeholder="Full Name" id="fullname" name="fullname">
                            <span class="red val" id="fullnameVal"></span>
                        </div>
                        <div class="row group">
                            <label>Email</label>
                            <input type="email" autocomplete="" class="form-control form-control-sm" placeholder="Email" id="email" name="email">
                            <span class="red val" id="emailVal"></span>
                        </div>
                        <div class="row group">
                            <label>NIC</label>
                            <input type="text" autocomplete="" class="form-control form-control-sm" placeholder="NIC" id="nic" name="nic">
                            <span class="red val" id="nicVal"></span>
                        </div>
                        <div class="row group">
                            <label>User Role</label>
                            <select class="form-control form-control-sm" id="urole" name="urole"></select>
                            <span class="red val" id="uroleVal"></span>
                        </div>
                        <div class="row group">
                            <label>Profile Picture</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input form-control-sm" accept=".jpg, .jpeg, .png" id="profpic" name="profpic">
                                <label style="overflow: hidden;" class="custom-file-label col-form-label-sm" id="lbl-profpic" for="profpic">Select File...</label>
                            </div>
                            <span class="red val" id="profpicVal"></span>
                        </div>
                        <div class="row controls">
                            <input type="button" class="btn btn-sm btn-primary" id="submit" value="Submit"/>
                            <input type="button" class="btn btn-sm btn-secondary" data-dismiss="modal" id="cancel" value="Cancel"/>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" href="./css/user-register.css" />
<script src="./js/user-register.js"></script>
