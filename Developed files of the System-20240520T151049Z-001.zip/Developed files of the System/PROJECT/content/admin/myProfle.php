<div class="container">
        <h2>Edit My Profile</h2>
        <hr/>
        <div class="prof-group">
            <div class="prof-image">
                <img class="prof-image-src" id="profImage" src="" alt="profile-picture" />
            </div>
            <div class="prof-title" id="profTitle"></div>
            <div class="prof-email" id="profEmail"></div>
        </div>
        <hr/>
        <div class="form">
            <form method="POST" id="password-change" enctype="multipart/form-data">
                
                <div class="form-item">
                    <label id="lbl-oldPassword">Old Password</label>
                    <input type="password" name="oldPassword" autocomplete class="form-control" id="oldPassword" />
                    <span class="val text-red" id="val-oldPassword"></span>
                </div>
                
                
                <div class="form-item">
                    <label id="lbl-newPassword">New Password</label>
                    <input type="password" name="newPassword" autocomplete class="form-control" id="newPassword" />
                    <span class="val text-red" id="val-newPassword"></span>
                </div>
                
                
                <div class="control-box">
                    <button type="button" class="btn btn-primary" id="save">Save Changes</button>
                </div>
                
            </form>
        </div>
    </div>

    <link rel="stylesheet" href="./css/my-profile.css" />
    <script src="./js/my-profile.js"></script>
