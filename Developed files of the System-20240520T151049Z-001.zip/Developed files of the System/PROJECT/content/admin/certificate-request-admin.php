    <div class="container">
        <h3>Certificate Requests</h3>
        <div>
            <select class="form-control form-control-sm" id="status">
                <option value="pending">Pending</option>
                <option value="granted">Granted</option>
                <option value="rejected">Rejected</option>
            </select>
        </div>
        <div class="content">
            <table class="table table-striped" id="data">
                <thead>
                    <tr>
                        <th scope="col">Action</th>
                        <th scope="col">Certificate</th>
                        <th scope="col">Requestor</th>
                        <th scope="col">Reason</th>
                        <th scope="col">Date</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody class="cert-table">
    
                </tbody>
            </table>
        </div>
        <div class="banner hide">
            <div class="banr-cont">
                <div>
                    <i class="fa fa-exclamation-triangle"></i>
                </div>
                <di>
                    No pending account requests
                </div>
            </div>
        </div>
    </div>

    <style>
        .content{
            overflow-y: auto;
            margin: 15px;
        }
        .banner{
            background-color: #eee;
            padding: 20px;
            margin: auto 20px;
            text-align: center;
            font-size: 1rem;
            font-weight: 500;
            color: #555;
            border-radius: 7px;
        }
        .banner .icon{
            margin: auto;
        }
        .banner i{
            font-size: 2rem;
            color: orange;
        }
        .hide{
            display: none;
        }
        .ver{
            border: none;
            background-color: inherit;
            width: 32px;
            height: 32px;
            color: #17b857;
            border-radius: 16px;
            transition: 0.5s;
            cursor: pointer;
        }
        .ver:hover{
            background-color: #17b857;
            color: white;
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(() => {
            loadRequests("pending");

            $('#status').change(() => { loadRequests($("#status").val())})
        })

        function loadRequests(status){
            var x;
            var dt = new FormData();
            dt.append('status', status);
            
            $.ajax({
                type: 'post',
                url: './controls/admin/get_certificate_request_admin.php',
                processData: false,
                contentType: false,
                cache: false,
                data: dt,
                success: function(res){
                    x = JSON.parse(res);
                },
                error: function(){
                    alert('No');
                },
                complete: function(){
                    fillItems(x);
                }
            });
        }

        function fillItems(a){
            var b = $('.banner');
            if(a == undefined || a == null){
                b.show();
                return;
            }
            var tb = $('.cert-table');
            tb.empty();
            $.each(a, i => {
                var status, btn = '';
                switch(a[i].status){
                    case 'pending': status = `<span class="badge badge-warning">Pending</span>`;
                            btn = `<button title="Respond" class="ver" onclick="verify(${a[i].Id})"><i class="fa fa-check"></i></button>` 
                            break;
                    case 'granted': status = `<span class="badge badge-success">Granted</span>`; break;
                    case 'rejected': status = `<span class="badge badge-danger">Rejetced</span>`; break;
                    default: status = `<span class="badge badge-secondary">${a[i].status}</span>`; break;
                }

                var row = `
                <tr>
                    <td>
                        ${btn}
                    </td>
                    <td>${a[i].certificate}</td>
                    <td>${a[i].requestor}</td>
                    <td>${a[i].reason}</td>
                    <td>${a[i].date.toString().replace('00:00:00', '')}</td>
                    <td>${status}</td>
                </tr>`;
                tb.append(row);
            });
        }

        function verify(id){
            Swal.fire({
                title: 'Respond to Request',
                text: 'Do you want to grant this certificate to the user?',
                showDenyButton: true,
                showCloseButton: true,
                confirmButtonText: 'Grant',
                denyButtonText: 'Reject',
                confirmButtonColor: '#17b857',
                allowEscapeKey: false,
                allowOutsideClick: false
            }).then(r => {
                if(r.isConfirmed){
                    var x = new FormData();
                    x.append("reqId", id);
                    x.append("status", "granted");
                    var d;
                        
                    $.ajax({
                        type: 'post',
                        url: './controls/admin/verify_certificate.php',
                        processData: false,
                        contentType: false,
                        data: x,
                        cache: false,
                        beforeSend: function(){
                            Swal.fire({
                                    text: 'Please wait...',
                                    imageUrl: 'http://localhost/PROJECT/img/res/loader-img.gif',
                                    imageWidth: 48,
                                    imageHeight: 48,
                                    imageAlt: 'Loading',
                                    showConfirmButton: false
                            });
                        },
                        success: function(res){
                            Swal.close();
                            d = JSON.parse(res);
                        },
                        error: function(){
                            Swal.close();

                            Swal.fire({
                                title: 'Something went wrong!',
                                icone: 'error'
                            });
                        },
                        complete: function(){
                            Swal.close();

                            Swal.fire({
                                title: d.title,
                                html: d.msg,
                                icon: d.status
                            });
                        }
                    });
                }
                else if(r.isDenied){
                    var x = new FormData();
                    x.append("reqId", id);
                    x.append("status", "rejected");
                    var d;
                        
                    $.ajax({
                        type: 'post',
                        url: './controls/admin/verify_certificate.php',
                        processData: false,
                        contentType: false,
                        data: x,
                        cache: false,
                        beforeSend: function(){
                            Swal.fire({
                                    text: 'Please wait...',
                                    imageUrl: 'http://localhost/PROJECT/img/res/loader-img.gif',
                                    imageWidth: 48,
                                    imageHeight: 48,
                                    imageAlt: 'Loading',
                                    showConfirmButton: false
                            });
                        },
                        success: function(res){
                            Swal.close();
                            d = JSON.parse(res);
                        },
                        error: function(){
                            Swal.close();
                            Swal.fire({
                                title: 'Something went wrong!',
                                icone: 'error'
                            });
                        },
                        complete: function(){
                            Swal.close();
                            Swal.fire({
                                title: d.title,
                                html: d.msg,
                                icon: d.status
                            });
                        }
                    });
                }
            });
        }
    </script>
