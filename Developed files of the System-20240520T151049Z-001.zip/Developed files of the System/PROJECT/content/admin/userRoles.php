 <div class="container">
        <div class="row header">
            <div class="col-md-8 header-topic">
                User Roles
            </div>
            <div class="col-md-4 header-button-box">
                <button title="Add New Role" class="add-role" id="add-role"><i class="fa fa-folder"></i></button>
            </div>
        </div>
        <div class="body">
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th scope="col">Role Name</th>
                        <th scope="col">Privileges</th>
                    </tr>
                </thead>
                <tbody class="role-table">

                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="view-role-window" tabindex="-1" role="dialog" aria-labelledby="lblviewrole" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
                <div class="modal-header">
                    <h6 class="modal-title" id="lblNewAid">Add New Role</h6>
                    <button type="button" class="edit"><i class="fa fa-pencil icon"></i></button>
                    <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="role-container">
                        <div class="role-group">
                            <div class="role-header">System Data</div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Personal Details
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="perDet-C">
                                        <label for="perDet-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="perDet-V">
                                        <label for="perDet-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="perDet-M">
                                        <label for="perDet-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="perDet-D">
                                        <label for="perDet-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Property Management
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="propMng-C">
                                        <label for="propMng-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="propMng-V">
                                        <label for="propMng-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="propMng-M">
                                        <label for="propMng-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="propMng-D">
                                        <label for="propMng-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Work Plan Details
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="wrkPln-C">
                                        <label for="wrkPln-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="wrkPln-V">
                                        <label for="wrkPln-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="wrkPln-M">
                                        <label for="wrkPln-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="wrkPln-D">
                                        <label for="wrkPln-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Aids and Other Details
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="aidDet-C">
                                        <label for="aidDet-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="aidDet-V">
                                        <label for="aidDet-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="aidDet-M">
                                        <label for="aidDet-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="aidDet-D">
                                        <label for="aidDet-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="role-group">
                            <div class="role-header">Certificates</div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Character Certificate
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="charCert-C">
                                        <label for="charCert-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="charCert-V">
                                        <label for="charCert-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="charCert-M">
                                        <label for="charCert-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="charCert-D">
                                        <label for="charCert-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Death Certificate
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="deathCert-C">
                                        <label for="deathCert-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="deathCert-V">
                                        <label for="deathCert-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="deathCert-M">
                                        <label for="deathCert-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="deathCert-D">
                                        <label for="deathCert-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Certificate of Residence
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="resCert-C">
                                        <label for="resCert-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="resCert-V">
                                        <label for="resCert-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="resCert-M">
                                        <label for="resCert-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="resCert-D">
                                        <label for="resCert-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="role-group">
                            <div class="role-header">User Management</div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Users
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="user-C">
                                        <label for="user-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="user-V">
                                        <label for="user-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="user-M">
                                        <label for="user-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="user-D">
                                        <label for="user-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    User Roles
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="uRole-C">
                                        <label for="uRole-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="uRole-V">
                                        <label for="uRole-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="uRole-M">
                                        <label for="uRole-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="uRole-D">
                                        <label for="uRole-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Edit My Profile
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="myProf-C">
                                        <label for="myProf-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="myProf-V">
                                        <label for="myProf-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="myProf-M">
                                        <label for="myProf-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="myProf-D">
                                        <label for="myProf-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="role-group">
                            <div class="role-header">Disaster Recovery</div>
                            <div class="row role-items">
                                <div class="col-md-4 role-item-name">
                                    Disaster Recovery
                                </div>
                                <div class="col-md-8 role-item-access">
                                    <span>
                                        <input type="checkbox" id="disast-C">
                                        <label for="disast-C">Create</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="disast-V">
                                        <label for="disast-V">View</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="disast-M">
                                        <label for="disast-M">Modify</label>
                                    </span>
                                    <span>
                                        <input type="checkbox" id="disast-D">
                                        <label for="disast-D">Delete</label>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="role-view-controls"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add-role-window" tabindex="-1" role="dialog" aria-labelledby="lbladdrole" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
                <div class="modal-header">
                    <h6 class="modal-title" id="lblNewAid">Add New Role</h6>
                    <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-3">Role Name</div>
                        <div class="col-md-9">
                            <input class="form-control form-control-sm" id="roleName" />
                            <span class="val text-danger" id="roleNameVal"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="modal-footer-control">
                        <button class="btn btn-sm btn-primary" id="addRole">Add Role</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="./css/user-role.css" />
    <script src="./js/user-role.js"></script>

