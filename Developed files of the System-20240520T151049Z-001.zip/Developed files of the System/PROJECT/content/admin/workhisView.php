<div class="col-lg-12">
    <h2> View Work History Details</h2>
    <hr>

    <div class="container">
        <div class="table-responsive">
            <div class="container mt-3">
    
                <table class="table table-striped table-bordered table-sm" id="workHistory_view">
                    <thead>
                        <tr>
                            <th>Action&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Province</th>
                            <th>District</th>
                            <th>Divisional Secretariat&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Name of Grama Niladhari&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            <th>Address</th> 
                            <th>Telephone No</th> 
                            <th>Start Date of Duty&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> 
                            <th>Other Details&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                           include '../../DB/conn.php';
                           global $connection;

                           $query = "SELECT * FROM `work_history`";
                           $result = mysqli_query($connection, $query);
                           if (mysqli_num_rows($result) > 0) {
                               while ($row = mysqli_fetch_assoc($result)) {
                                   
                                   echo "
                                       <tr>
                                           <td>
                                               <button class=\"btn btn-sm btn-danger\" onclick='remove(".$row['idwork_history'].")'><i class=\"fa fa-trash\"></i></button>
                                               <button class=\"btn btn-sm btn-primary\" onclick='edit(".$row['idwork_history'].")'><i class=\"fa fa-edit\"></i></button>
                                           </td>
                                           <td>".$row['work_history_province']."</td>
                                           <td>".$row['work_history_district']."</td>
                                           <td>".$row['work_history_divisional_secretariat']."</td>
                                           <td>".$row['gn_name']."</td> 
                                           <td>".$row['work_history_address']."</td>
                                           <td>".$row['work_history_telephone_no']."</td> 
                                           <td>".$row['work_history_start_date_of_duty']."</td>     
                                           <td>".$row['other_details']."</td>
                                       </tr>
                                   ";
                               }
                           }
                       ?>     
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="modal fade" id="editor" tabindex="-1" role="dialog" aria-labelledby="editorLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editorLabel">Edit</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="data" enctype="multipart/form-data">
                        <div class="container">
                            
                        <div class="form-group">
                                <label>Province:</label>
                                <select id="province" class="form-control form-control-sm">
                                    <option value="">- Please Select -</option>
                                    <option value='Central Province'>Central Province</option>
                                    <option value='Eastern Province'>Eastern Province</option>
                                    <option value='Northern Province'>Northern Province</option>
                                    <option value='North Central Province'>North Central Province</option>
                                    <option value='North Western Province'>North Western Province</option>
                                    <option value='Sabaragamuwa Province'>Sabaragamuwa Province</option>
                                    <option value='Southern Province'>Southern Province</option>
                                    <option value='Uva Province'>Uva Province</option>
                                    <option value='Western Province'>Western Province</option>
                                </select>
                                <span class="val" id="provinceVal"></span>
                            </div>

                            <div class="form-group">
                                <label>District:</label>
                                <select id="district" class="form-control form-control-sm"></select>
                                <span class="val" id="districtVal"></span>
                            </div>

                            <script>
                                var object = JSON.parse('<?php echo file_get_contents('../../data/district.json') ?>');
                                
                                $("#province").change(function () {
                                    var prv = this.value.toUpperCase();
                                    var data = "";
                                    
                                    for (var i = 0; i < object.length; i++) {
                                        var found = false;
                                        var oprv = object[i]["province"].toUpperCase();
                                        if (prv == oprv) {
                                            data = data + "<option value='" + object[i]["district"] + "'>" + object[i]["district"] + "</option>";
                                        }
                                    }
                                    
                                    $("#district").html(data);
                                    loadDivs();
                                   
                                });

                                $('#district').change(() => {
                                    loadDivs();
                                });

                                function loadDivs(){
                                    var divs = object.filter(n => n.district == $('#district').val())[0].divisions;
                                    var divList = $('#division');
                                    divList.empty();
                                        
                                    $.each(divs, i => {
                                        divList.append(`<option value="${divs[i]}">${divs[i]}</option>`);
                                    });
                                }
                            </script>

                            <div class="form-group">
                                <label>Divisional Secretariat:</label>
                                <select id="division" class="form-control form-control-sm"></select>
                                <span class="val" id="divisionVal"></span>
                            </div>

                            <div class="form-group">
                                <label>Name of Grama Niladhari:</label>
                                <textarea name="name" id="name" class="form-control form-control-sm"></textarea>
                                <span class="val" id="nameVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Address:</label>
                                <textarea name="address" id="address" class="form-control form-control-sm"></textarea>
                                <span class="val" id="addressVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Telephone No:</label>
                                <textarea name="telno" id="telno" class="form-control form-control-sm"></textarea>
                                <span class="val" id="telnoVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Start Date of Duty:</label>
                                <input type="date" id="date" name="date" class="form-control form-control-sm" /> 
                                <span class="val" id="dateVal"></span>
                            </div>
                            <div class="form-group">
                                <label>Other Details:</label>
                                <textarea class="form-control" rows="5" id="odetails" name="odetails"></textarea>
                                <label class="val text-danger" id="odetailsVal"></label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-primary" id="save">Save</button>
                </div>
            </div>
        </div>
    </div>
                  
        <style>
            .val{
                color: red;
                font-size: 0.8rem;
            }
        </style>

        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#myTable tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                    });
                });

                $('#workHistory_view').DataTable();

                $('#province').change(() => { valProvince(); })
                $('#district').change(() => { valDistrict(); })
                $('#division').change(() => { valDivision(); })
                $('#name').change(() => { valName(); })
                $('#address').change(() => { valAddress(); })
                $('#telno').change(() => { valTelno(); })
                $('#date').change(() => { valdateDate(); })
                $('#odetails').on('change keyup', () => { valOdetails(); })
                $('#save').click(() => { save(); })
            });

            var dataId = -1;
            function save(){
                if(dataId < 0){
                    alert('Pick an object before edit!');
                    return;
                }

                if(isValid()){
                    var data = new FormData(document.getElementById('data'));
                    // data.append('type', $('#type').val());
                    // data.append('id', dataId);
                    data.append('province', $('#province').val());
                    data.append('district', $('#district').val());
                    data.append('division', $('#division').val());
                    data.append('id', dataId);

                    $.ajax({
                        type: 'post',
                        url: './controls/admin/update_workhistoryData.php',
                        processData: false,
                        contentType: false,
                        data: data,
                        success: function(r) {
                            system_alert(r);
                        },
                        error: function() {
                            system_alert('Something went wrong!');
                        },
                        complete: function(){
                            $('#editor').modal('hide');
                        }
                    });
                }
            }

            function edit(id){
                var data;
                var d = new FormData();
                d.append('Id', id);

                $.ajax({
                    type: 'post',
                    url: './controls/admin/get_workhistoryData.php',
                    processData: false,
                    contentType: false,
                    data: d,
                    success: function(r) {
                        data = JSON.parse(r);
                    },
                    error: function() {
                        system_alert('Something went wrong!');
                    },
                    complete: function(){
                        dataId = id;
                        $('#province').val(data.province).change();
                        $('#district').val(data.district).change();
                        $('#division').val(data.division);
                        $('#name').val(data.name);
                        $('#address').val(data.address);
                        $('#telno').val(data.telno);
                        $('#date').val(data.date);
                        $('#odetails').val(data.odetails);
                        //$("#province").prop("selectedIndex", 1).change();
                        $('#editor').modal('show');
                    }
                });
            }

            function remove(id){
                var d = new FormData();
                d.append('Id', id);

                $.ajax({
                        type: 'post',
                        url: './controls/admin/delete_workhistoryData.php',
                        processData: false,
                        contentType: false,
                        data: d,
                        success: function(r) {
                            system_alert(r);
                        },
                        error: function() {
                            system_alert('Something went wrong!');
                        },
                        complete: function(){
                            $('#editor').modal('hide');
                        }
                    });
            }

            function addVal(val, msg){
                val.html(msg);
            }

            function removeVal(val){
                val.html('');
            }

            function isValid(){
                return valProvince() & valDistrict() &
                valDivision() & valName() & valAddress() & 
                valTelno() & valDate() & valOdetails();
            }

            function valProvince(){
                var inp = $('#province')
                var val = $('#provinceVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Province is required'); return false;
                }

                removeVal(val); return true;
            }

            function valDistrict(){
                var inp = $('#district')
                var val = $('#districtVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'District is required'); return false;
                }

                removeVal(val); return true;
            }

            function valDivision(){
                var inp = $('#division')
                var val = $('#divisionVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Divisional Secretariat is required'); return false;
                }

                removeVal(val); return true;
            }
           
            function valName(){
                var inp = $('#name')
                var val = $('#nameVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Name of Grama Niladhari is required'); return false;
                }

                removeVal(val); return true;
            }

            function valAddress(){
                var inp = $('#address')
                var val = $('#addressVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Address is required'); return false;
                }

                removeVal(val); return true;
            }
            
            
            function valTelno(){
                var inp = $('#telno')
                var val = $('#telnoVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Telephone No is required'); return false;
                }

                removeVal(val); return true;
            }

            function valDate(){
                var inp = $('#date')
                var val = $('#dateVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Start Date of duty is required'); return false;
                }

                removeVal(val); return true;
            }

            function valOdetails(){
                var inp = $('#odetails')
                var val = $('#odetailsVal');

                if(inp.val() == '' || inp.val() == null){
                    addVal(val, 'Other details is required'); return false;
                }

                removeVal(val); return true;
            }

        </script>

