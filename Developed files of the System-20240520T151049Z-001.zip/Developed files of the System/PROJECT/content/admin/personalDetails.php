<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
<link rel="stylesheet" href="css/personal-details.css"/>
<script src="js/personal-details.js" type="text/javascript"></script>
<h2>Personal Details</h2>
<hr>

<div class="row">
    <div class="form-group col-lg-6">
        <label for="isChild">Is the person a Child: </label>
        <input type="checkbox" class="" id="isChild" name="isChild">
    </div>
</div>

<div class="row">
    <div class="form-group col-lg-6">
        <label for="nmeofprsn">Name of Person:</label>
        <input type="text" class="form-control" id="nmeofprsn" name="persname">
        <span class="val text-danger" id="nmeofprsnVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="hseno">House No:</label>
        <input type="text" class="form-control" id="hseno" name="houseno">
        <span class="val text-danger" id="hsenoVal"></span>
    </div>
</div>

<div class="row">
    <div class="form-group col-lg-6">
        <label for="stts">Status:</label>
        <select class="form-control" id="status" name="stts">
            <option>Single</option>
            <option>Married</option>
            <option>Divorce</option>
        </select>
        <span class="val text-danger" id="statusVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="gndr">Gender:</label>
        <select class="form-control" id="gender" name="gndr">
            <option>Male</option>
            <option>Female</option>
        </select>
        <span class="val text-danger" id="genderVal"></span>
    </div>
</div>

<div class="row">
    <div class="form-group col-lg-6">
        <label for="dob">Date of Birth:</label>
        <input type="date" class="form-control" id="dateofbirth" name="dob">
        <span class="val text-danger" id="dateofbirthVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="brthplce">Birth Place:</label>
        <input type="text" class="form-control" id="brthplce" name="birthplace">
        <span class="val text-danger" id="brthplceVal"></span>
    </div>
</div>

<div class="row" data-hide-on-child="true">
    <div class="form-group col-lg-6">
        <label for="idno">ID No:</label>
        <input type="text" class="form-control" id="idno" name="idno">
        <span class="val text-danger" id="idnoVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="telno">Telephone No:</label>
        <input type="text" class="form-control" id="telno" name="telno">
        <span class="val text-danger" id="telnoVal"></span>
    </div>
</div>
<div class="row">
    <div class="form-group col-lg-6" data-hide-on-child="true">
            <label for="email">Email:</label>
            <input type="text" class="form-control" id="email" name="email">
            <span class="val text-danger" id="emailVal"></span>
    </div>
    <div class="form-group col-lg-6 hide" data-hide-on-child="false">
        <label for="guardian">Guardian of the Child:</label>
        <select class="form-control selectpicker"  data-live-search="true" id="guardian">
            <option value="" disabled selected>Select the guardian</option>
            <?php
                include '../../DB/conn.php';

                global $connection;
                $conn = $connection;

                $q = "SELECT * FROM `person` WHERE `is_child` = 0";
                $res = $conn->query($q);
                if($res->num_rows > 0){
                    while($row = $res->fetch_assoc()){
                        echo "<option value='".$row["idperson"]."'>".$row["nameof_person"]." - ".$row["nic"]."</option>";
                    }
                }
            ?>
        </select>
        <span class="val text-danger" id="guardianVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="isAlive">Is Alive:</label>
        <select class="form-control" id="isAlive">
            <option value="0">No</option>
            <option value="1" selected="selected">Yes</option>
        </select>
        <span class="val text-danger" id="isAliveVal"></span>
    </div>
</div>
<div class="row">
    <div class="form-group col-lg-6">
        <label for="relgns">Religions:</label>
        <select class="form-control" id="religions" name="relgns">
            <option>Buddhism</option>
            <option>Hinduism</option>
            <option>Islam</option>
            <option>Catholic</option>
            <option>Other</option>
        </select>
        <span class="val text-danger" id="religionsVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="natnalty">Nationality:</label>
        <select class="form-control" id="nationality" name="natnalty">
            <option>Sinhalese</option>
            <option>Tamils</option>
            <option>Muslims</option>
            <option>Malay</option>
            <option>Burgher</option>
            <option>Other</option>
        </select>
        <span class="val text-danger" id="nationalityVal"></span>
    </div>
</div>

<div class="row">
    <div class="form-group col-lg-6">
        <label for="edctn">Education:</label>
        <select class="form-control" id="education" name="edctn">
            <option>1-5 Primary</option>
            <option>6-10 Secondary</option>
            <option>Ordinary Level</option>
            <option>Advanced Level</option>
            <option>Higher Studies</option>
            <option>Other</option>
            <option>None</option>
        </select>
        <span class="val text-danger" id="educationVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="occptn">Occupation:</label>
        <select class="form-control" id="occupation" name="occptn">
            <option>None</option>
            <option>Cultivation</option>
            <option>Skilled Labour(Carpenters,Masons,Electricians etc.)</option>
            <option>Unskilled Labour</option>
            <option>Fishing</option>
            <option>Government Offices</option>
            <option>Private Sector</option>
            <option>Small Business</option>
            <option>Services</option>
            <option>Self-employee</option>
            <option>Others</option>
        </select>
        <span class="val text-danger" id="occupationVal"></span>
    </div>
</div>

<div class="row">
    <div class="form-group col-lg-6">
        <label for="physcal">Physical & Mental Situation:</label>
        <select class="form-control selectpicker"  data-live-search="true" id="physcalhlth" name="physcal" multiple>
            <option value="Normal">Normal</option>
            <option value="Blind">Blind</option>
            <option value="Disabled">Disabled</option>
            <option value="Deaf">Deaf</option>
            <option value="Dumb">Dumb</option>
            <option value="Other">Other</option>

        </select>
        <span class="val text-danger" id="physcalhlthVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="vehicls">Vehicles:</label>
        <select class="form-control selectpicker" data-live-search="true"  id="vehcls" name="vehicls" multiple>
            <option>Car</option>
            <option>Bus</option>
            <option>Van</option>
            <option>Jeep</option>
            <option>Motor Bicycle</option>
            <option>Three Wheels</option>
            <option>Lorry</option>
            <option>Other</option>
            <option>None</option>
        </select>
        <span class="val text-danger" id="vehclsVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="langknlg">Language Knowledge:</label>
        <select class="form-control selectpicker" data-live-search="true" id="langknwlge" name="langknlg" multiple>
            <option>Sinhala</option>
            <option>English</option>
            <option>Tamil</option>
            <option>Other</option>
        </select>
        <span class="val text-danger" id="langknwlgeVal"></span>
    </div>
    <div class="form-group col-lg-6">
        <label for="itknlg">IT Knowledge:</label>
        <select class="form-control selectpicker" data-live-search="true" id="itknwlege" name="itknlg" multiple>
            <option>Microsoft Office</option>
            <option>Programming Languages</option>
            <option>Networking</option>
            <option>None</option>
            <option>Other</option>
        </select>
        <span class="val text-danger" id="itknwlegeVal"></span>
    </div>

</div>

<div class="row">
    <div class="form-group col-lg-12">
        <label for="otherskls">Other Skills:</label>
        <textarea class="form-control" rows="6" id="otherskls" name="otherskills"></textarea>
        <span class="val text-danger" id="othersklsVal"></span>
    </div>
</div>

<!-- Public aids -->
<div class="row">
    <div class="form-group col-lg-12 group-box">
        <h4 class="h">Public Assistance & Other Details</h4>
        <div class="outter-box">
            <div class="item-container">
                <div class="row head">
                    <div class="col-md-1">Action</div>
                    <div class="col-md-2">Type</div>
                    <div class="col-md-1">Donation</div>
                    <div class="col-md-2">Acc. No.</div>
                    <div class="col-md-2">Amount</div>
                    <div class="col-md-2">Place</div>
                    <div class="col-md-2">Other Info</div>
                </div>
            </div>
        </div>
        <div class="control-container">
            <button class="btn btn-sm btn-primary" id="add-aid"><i class="fa fa-plus"></i> Add New Aid</button>
        </div>
    </div>
</div>

<div class="form-control-group">
    <button type="button" class="btn btn-primary f" id="submit">Submit</button>
    <button type="button" class="btn btn-dark f" id="clear">Clear</button>
</div>


<!-- Add aid window -->
<div class="modal fade" id="add-aid-window" tabindex="-1" role="dialog" aria-labelledby="lblNewAid" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
            <div class="modal-header">
                <h6 class="modal-title" id="lblNewAid">Add New Aid</h6>
                <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <div>Type of Aid:</div>
                    <select id="typeOfAid" class="form-control form-control-sm">
                        <option value="Civil">Civil</option>
                        <option value="Forces">Forces</option>
                        <option value="Dependences">Dependences</option>
                        <option value="Disabled">Disabled</option>
                        <option value="Mahapola">Mahapola</option>
                        <option value="Scholarship">Scholarship</option>
                        <option value="Widow">Widow</option>
                        <option value="Other">Other</option>
                    </select>
                    <div id="typeOfAidVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Account No:</div>
                    <input type="text" id="accNo" class="form-control form-control-sm" />
                    <div id="accNoVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Donation No:</div>
                    <input type="text" id="donatNo" class="form-control form-control-sm" />
                    <div id="donatNoVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Donation Rs.:</div>
                    <input type="number" step="0.01" id="donatAmnt" class="form-control form-control-sm" />
                    <div id="donatAmntVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Place of Obtaining:</div>
                    <input type="text" id="place" class="form-control form-control-sm" />
                    <div id="placeVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Other Details:</div>
                    <textarea class="form-control" id="otherDet" rows="3"></textarea>
                    <div id="otherDetVal" class="text-danger"></div>
                </div>

            </div>
            <div class="modal-footer " id="createInvoiceWindowControls">
                <button class="btn btn-sm btn-success" id="add">Add</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit aid window -->
<div class="modal fade" id="edit-aid-window" tabindex="-1" role="dialog" aria-labelledby="lblEditAid" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
            <div class="modal-header">
                <h6 class="modal-title" id="lblEditAid">Edit Aid</h6>
                <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <div>Type of Aid:</div>
                    <select id="e-typeOfAid" class="form-control form-control-sm">
                        <option value="Civil">Civil</option>
                        <option value="Forces">Forces</option>
                        <option value="Dependences">Dependences</option>
                        <option value="Disabled">Disabled</option>
                        <option value="Mahapola">Mahapola</option>
                        <option value="Scholarship">Scholarship</option>
                        <option value="Widow">Widow</option>
                        <option value="Other">Other</option>
                    </select>
                    <div id="e-typeOfAidVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Account No:</div>
                    <input type="text" id="e-accNo" class="form-control form-control-sm" />
                    <div id="e-accNoVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Donation No:</div>
                    <input type="text" id="e-donatNo" class="form-control form-control-sm" />
                    <div id="e-donatNoVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Donation Rs.:</div>
                    <input type="number" step="0.01" id="e-donatAmnt" class="form-control form-control-sm" />
                    <div id="e-donatAmntVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Place of Obtaining:</div>
                    <input type="text" id="e-place" class="form-control form-control-sm" />
                    <div id="e-placeVal" class="text-danger"></div>
                </div>
                <div class="form-group">
                    <div>Other Details:</div>
                    <textarea class="form-control" id="e-otherDet" rows="3"></textarea>
                    <div id="e-otherDetVal" class="text-danger"></div>
                </div>

            </div>
            <div class="modal-footer " id="createInvoiceWindowControls">
                <button class="btn btn-sm btn-success" id="edit-save">Save</button>
            </div>
        </div>
    </div>
</div>

<!-- Loader -->
<div class="modal" id="loader" tabindex="-1" role="dialog" aria-labelledby="lblLoader" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
            <div class="modal-body" style="text-align: center;">
                <img src="./img/res/loader-img.gif" width="32" height="32">
                <span style="margin-left: 10px;">Saving data...</span>
            </div>
        </div>
    </div>
</div>

<!-- Error -->
<div class="modal" id="error" tabindex="-1" role="dialog" aria-labelledby="lblError" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
            <div class="modal-body" style="text-align: center;">
                <img src="./img/res/error-trans.png" width="32" height="32">
                <span style="margin-left: 10px;">Something went wrong while communicating with server...</span>
            </div>
        </div>
    </div>
</div>