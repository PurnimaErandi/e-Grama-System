
    <div class="container">
        <h3>Pending Account Requests</h3>
        <div class="content">
            <table class="table table-striped table" id="data">
                <thead>
                    <tr>
                        <th scope="col">Action</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">NIC</th>
                        <th scope="col">Address</th>
                        <th scope="col">Contact No.</th>
                    </tr>
                </thead>
                <tbody class="req-table">
    
                </tbody>
            </table>
        </div>
        <div class="banner hide">
            <div class="banr-cont">
                <div>
                    <i class="fa fa-exclamation-triangle"></i>
                </div>
                <di>
                    No pending account requests
                </div>
            </div>
        </div>
    </div>

    <style>
        .content{
            overflow-y: auto;
            margin: 15px;
        }
        .banner{
            background-color: #eee;
            padding: 20px;
            margin: auto 20px;
            text-align: center;
            font-size: 1rem;
            font-weight: 500;
            color: #555;
            border-radius: 7px;
        }
        .banner .icon{
            margin: auto;
        }
        .banner i{
            font-size: 2rem;
            color: orange;
        }
        .hide{
            display: none;
        }
        .ver{
            border: none;
            background-color: inherit;
            width: 32px;
            height: 32px;
            color: #17b857;
            border-radius: 16px;
            transition: 0.5s;
            cursor: pointer;
        }
        .ver:hover{
            background-color: #17b857;
            color: white;
        }
        
        .rej{
            border: none;
            background-color: inherit;
            width: 32px;
            height: 32px;
            color: #e82e44;
            border-radius: 16px;
            transition: 0.5s;
            cursor: pointer;
        }
        .rej:hover{
            background-color: #e82e44;
            color: white;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(() => {
            loadAccountRequests();
        });

        function fillAccounts(a){
            var b = $('.banner');
            if(a == undefined || a == null){
                b.show();
                return;
            }
            var tb = $('.req-table');
            tb.empty();
            $.each(a, i => {
                var row = `
                <tr>
                    <td>
                        <button title="Inspect" class="ver" onclick="verify(${a[i].Id})"><i class="fa fa-check"></i></button>
                        <button title="Reject" class="rej" onclick="reject(${a[i].Id})"><i class="fa fa-times"></i></button>
                    </td>
                    <td>${a[i].Name}</td>
                    <td>${a[i].Email}</td>
                    <td>${a[i].NIC}</td>
                    <td>${a[i].Address}</td>
                    <td>${a[i].ContactNo}</td>
                </tr>`;
                tb.append(row);
            });
        }

        function loadAccountRequests(){
            var accounts;
            
            $.ajax({
                type: 'post',
                url: './controls/admin/get_account_requests.php',
                contentType: false,
                success: function(r){
                    accounts = JSON.parse(r);
                },
                error: function(){
                    alert('Something went wrong');
                },
                complete: function(){
                    fillAccounts(accounts);
                }
            });
        }

        async function f(d){
            //var d = getAccount(i);

            if(d.isSuccess == 1){
                const { value: uName } = await Swal.fire({
                    title: 'Account Verified',
                    html: `${d.msg}.<br/>Create new Username below.`,
                    showCloseButton: true,
                    showCancelButton: false,
                    cancelButtonText: 'Reject Request',
                    confirmButtonColor: '#17b857',
                    cancelButtonColor: '#dc3545',
                    confirmButtonText: 'Create Account',
                    input: 'text',
                    allowEscapeKey: false,
                    inputPlaceholder: 'Username',
                    inputValidator: (value) => {
                        if (!value) {
                            return 'Username is required'
                        }
                    },
                    inputAttributes: {
                        'autocomplete': 'off'
                    }
                })
                
                if(uName){
                    var pass;
                    var x = new FormData();
                    x.append("Id", d.Id);
                    x.append("uName", uName);
                    
                    $.ajax({
                        type: 'post',
                        url: './controls/admin/create_user_account.php',
                        contentType: false,
                        processData: false,
                        data: x,
                        beforeSend: function(){
                            Swal.fire({
                                text: 'Please wait...',
                                imageUrl: 'http://localhost/PROJECT/img/res/loader-img.gif',
                                imageWidth: 48,
                                imageHeight: 48,
                                imageAlt: 'Loading',
                                showConfirmButton: false
                            });
                        },
                        success: function(r){
                            Swal.close();
                            pass = r;
                        },
                        error: function(){
                            Swal.close();
                            alert('Something went wrong');
                        },
                        complete: function(){
                            Swal.close();
                            Swal.fire({
                                title: 'Account Successfully Created',
                                html: `Credentials were sent to the user for password "<b>${pass}</b>"`,
                                icon: 'success',
                                showConfirmButton: true
                            });
                        }
                    });
                    
                            
                }
            }

            if(d.isSuccess == 0){
                Swal.fire({
                    title: "Account Couldn't Verified",
                    html: `${d.msg}`,
                    confirmButtonText: "Reject Request",
                    confirmButtonColor: '#dc3545',
                    showCancelButton: true,
                    cancelButtonText: 'Close',
                    icon:'error'
                }).then(r => {
                    if(r.value){
                        Swal.fire({
                            title: 'Account Rejected',
                            text: 'This account is denied',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }
                });
            }
        }

        function verify(i){
            var a;
            
            var data = new FormData();
            data.append("Id", i);
            
            $.ajax({
                type: 'post',
                url: './controls/admin/verify_account_request.php',
                contentType: false,
                processData: false,
                data: data,
                async: false,
                success: function(r){
                    a = JSON.parse(r);
                },
                error: function(){
                    alert('Something went wrong');
                }
            });
            f(a);
        }
        
        function reject(id){
            var x = new FormData();
            x.append("id", id);
            var d;
            
            $.ajax({
                type: 'post',
                url: './controls/admin/delete_request.php',
                contentType: false,
                processData: false,
                data: x,
                async: true,
                beforeSend: function(){
                    Swal.fire({
                        text: 'Please wait...',
                        imageUrl: 'http://localhost/PROJECT/img/res/loader-img.gif',
                        imageWidth: 48,
                        imageHeight: 48,
                        imageAlt: 'Loading',
                        showConfirmButton: false
                    });
                },
                success: function(r){
                    Swal.close();
                    d = JSON.parse(r);
                },
                error: function(){
                    Swal.close();
                    alert('Something went wrong');
                },
                complete: function(){
                    Swal.close();
                    var i = d.sts == 1 ? 'success' : 'error';
                    
                    Swal.fire({
                        title: 'Account Request',
                        text: d.msg,
                        icon: i
                    });
                }
            });
        }
    </script>
