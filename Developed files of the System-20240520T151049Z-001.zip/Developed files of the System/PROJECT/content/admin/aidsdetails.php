<div class="container">
        <div class="row header">
            <div class="col-md-8 header-topic">
                <b>Samurdhi Subsidies & Other Aids</b>
            </div>
            <div class="col-md-4 header-button-box">
                <button title="Add New Aid" class="add-aid" id="add-aid"><i class="fa fa-folder"></i></button>
            </div>
        </div>

        <div class="body">
            <table class="table table-striped table" id="data">
                <thead>
                    <tr>
                        <th scope="col">Action&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th scope="col">House No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Aid Type</th>
                        <th scope="col">Account No.</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> 
                        <th scope="col">Place&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th scope="col">Other&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    </tr>
                </thead>
                <tbody class="aid-table">
    
                </tbody>
            </table>
        </div>

        <div class="modal fade" id="add-aid-window" tabindex="-1" role="dialog" aria-labelledby="lbladdAid" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
                    <div class="modal-header">
                        <h6 class="modal-title" id="lblNewAid">Add Aids Details</h6>
                        <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body modal-container">
                        <form enctype="multipart/form-data" id="aid-form">
                            <div class="row group">
                                <label>House No.</label>
                                <select class="form-control form-control-sm" id="hName" name="houseNo">
                                    <?php
                                        include '../../DB/conn.php';

                                        global $connection;
                                        $conn = $connection;

                                        $q = "SELECT `house_no`, `nameof_person` FROM `person`";
                                        $res = $conn->query($q);
                                        if($res->num_rows > 0){
                                            while($row = $res->fetch_assoc()){
                                                echo '<option value="'.$row['house_no'].'">'.$row["house_no"]." - [".$row["nameof_person"]."]</option>";
                                            }
                                        }
                                    ?>
                                </select>
                                <span class="val text-red" id="houseNoVal"></span>
                            </div>

                            <div class="row group">
                                <label>Person Name</label>
                                <input type="text" class="form-control form-control-sm" id="pName" name="pName"/>
                                <span class="val text-red" id="pNameVal"></span>
                            </div>

                            <div class="row group">
                                <label>Aid Type</label>
                                <select class="form-control form-control-sm" id="aidType" name="aidType">
                                    <?php
                                        include '../../DB/conn.php';

                                        global $connection;
                                        $conn = $connection;

                                        $q = "SELECT * FROM `aid_type`";
                                        $res = $conn->query($q);
                                        if($res->num_rows > 0){
                                            while($row = $res->fetch_assoc()){
                                                echo '<option value="'.$row['aid_type_id'].'">'.$row["aid_type_name"]."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                                <span class="val text-red" id="aidTypeVal"></span>
                            </div>

                            <div class="row group">
                                <label>Account No.</label>
                                <input type="text" class="form-control form-control-sm" id="accNo" name="accNo"/>
                                <span class="val text-red" id="accNoVal"></span>
                            </div>

                            <div class="row group">
                                <label>Amount</label>
                                <input type="number" min="0" class="form-control form-control-sm" id="amount" name="amount"/>
                                <span class="val text-red" id="amountVal"></span>
                            </div>

                            <div class="row group">
                                <label>Place of Obtained</label>
                                <input type="text" class="form-control form-control-sm" id="place" name="place"/>
                                <span class="val text-red" id="placeVal"></span>
                            </div>

                            <div class="row group">
                                <label>Date</label>
                                <input type="date" class="form-control form-control-sm" id="date" name="date"/>
                                <span class="val text-red" id="dateVal"></span>
                            </div>

                            <div class="row group">
                                <label>Other Details</label>
                                <textarea class="form-control form-control-sm" id="other" name="other"></textarea>
                                <span class="val text-red" id="otherVal"></span>
                            </div>
                        </form>
                        <div class="row control-group">
                            <div class="control">
                            <button class="btn btn-sm btn-primary" id="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="./css/aid-details.css" />
    <script src="./js/aid-details.js"></script>
