
    <div class="container">
        <h2>Feedbacks</h2>
        <div class="row summary">
            <div class="col-3 v-middle">
                <div class="average">
                    <i class="fas fa-angry"></i>
                    <span class="count"></span>
                </div>
            </div>
            <div class="col-9">
                <div class="rating-chart">
                    <canvas id="rates" aria-label="rating-charts" role="img"></canvas>
                </div>
            </div>
        </div>

        <div class="feed-container"></div>
    </div>

    
    <link rel="stylesheet" href="./css/feedback-review.css">
    <script src="js/feedback-review.js"></script>
