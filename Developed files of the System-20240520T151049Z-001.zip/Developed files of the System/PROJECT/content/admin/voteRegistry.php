<div class="container">
    <h3 class="mb-3">Vote Register</h3>
    <input type="text" class="form-control md-3" placeholder="Search..." id="data-search" />
    <br>
    <div class="data-grid">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>Remove</th>
                    <th>Name</th>
                    <th>House No.</th>
                    <th>SLIN/NIC</th>
                    <th>DoB</th>
                    <th>Gender</th>
                    <th>Tel No.</th>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody class="table-body"></tbody>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="./js/vote.js"></script>