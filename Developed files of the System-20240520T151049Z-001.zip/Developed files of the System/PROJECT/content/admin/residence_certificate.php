<?php
    session_start();
    ini_set('display_errors',0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="../../css/character-form.css"/>
    <title>View Residence Certificate</title>
</head>
<body style="padding:10px">
    <?php
        if(isset($_SESSION["personId"])){
            $div_sec_name = '';
            $person_name = '';
            $permanent_residence = '';
            $nic = '';
            $date_of_birth = '';
            $age = '';
            $residing_gnd = '';
            $purpose = '';
            $applicant_name = '';
            $gn_division = '';
            
            
            include '../../DB/conn.php';
            global $connection;
            $conn = $connection;
            $pId = $_SESSION['personId'];

            $q = "SELECT * FROM `residence_certificate` 
            WHERE `requested_person_id` = $pId";
            
            $res = $conn->query($q);

            if($res->num_rows > 0){
                while($row = $res->fetch_assoc()){
                    $div_sec_name = $row['div_name'];
                    $person_name = $row['person_name'];
                    $permanent_residence = $row['permanent_residence'];
                    $nic = $row['nic'];
                    $date_of_birth = $row['date_of_birth'];
                    $age = $row['age'];
                    $residing_gnd = $row['residing_gnd'];
                    $purpose = $row['purpose'];
                    $applicant_name = $row['applicant_name'];
                    $gn_division  = $row['gn_division'];
                     
                }
            }
        }
        else{
            echo '<div class="alert alert-danger">Unable to open the certificate!</div>';
        }
    ?>

    <div class="container">
        <h3 class="heading"><b>Certificate on residence issued by the Grama Niladhari</b></h3>
        <div class="sub-text">
            <h6>This certificate is issued by the Grama Niladhari of the Division in which the applicant 
            resides is valid only for 06 months from the date countersigned by the Divisional Secretary.</h6>
        </div>
        <hr>
        <br>
        <div class="section">
            <div class="section-content">
                <div class="row">
                    <div class="col-6">1. Divisional Secretariat Division : </div>
                    <div class="form-group col-6">
                        <span><?php echo $div_sec_name; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">2. Name of person : </div>
                    <div class="form-group col-6">
                        <span><?php echo $person_name; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">3. Permanent Residence : </div>
                    <div class="form-group col-6">
                        <span><?php echo $permanent_residence; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">4. National Identity Card No :</div>
                    <div class="form-group col-6">
                        <span><?php echo $nic; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">5. Date of Birth :  </div>
                    <div class="form-group col-6">
                        <span><?php echo $date_of_birth ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">6. Age (Years) :  </div>
                    <div class="form-group col-6">
                        <span><?php echo $age; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">7. Residing Grama Niladhari Division :  </div>
                    <div class="form-group col-6">
                        <span><?php echo $residing_gnd; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">8. Purpose:  </div>
                    <div class="form-group col-6">
                        <span><?php echo $purpose; ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-content dec-text">
                <h6>I certify that the above name mentioned person Mr./Mrs
                <span><?php echo $applicant_name; ?></span>
                is a permanent resident in Grama Niladhari Division
                <span><?php echo $gn_division."."; ?></span></h6>
            </div>
        </div>
    </div>
    <br>
    <footer>
        <div class="container hide" style="text-align:right">
            <button class="btn btn-sm btn-secondary" id="print" title="Print Certificate"><i class="fa fa-print"></i></button> 
        </div>
    </footer>

    <style>
        @media print{
            .hide{
                display: none;
            }
        }
    </style>

    <script>
        $('#print').click(() => { print(); });
    </script>
</body>
</html>

