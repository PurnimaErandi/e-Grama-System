<?php
    session_start();
    ini_set('display_errors',0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="../../css/character-form.css"/>
    <title>View Character Certificate</title>
</head>
<body style="padding:10px">
    <?php
        if(isset($_SESSION["personId"])){
            $district = '';
            $divSecratary = '';
            $gnDivision = '';
            $dgnKnown = '';
            $sinceDate = '';
            $name = '';
            $address = '';
            $age = '';
            $civilStatus = '';
            $isSL = '';
            $religion = '';
            $occupation = '';
            $resiVillage = '';
            $nic = '';
            $elecReg = '';
            $fatherName = '';
            $certPurpose = '';
            $residPeriod= '';
            $natureResEvd = '';
            $convByLaw = '';
            $act = '';
            $charc = '';
            $remark = '';
            $regNo = '';
            $issuer = '';
            

            include '../../DB/conn.php';
            global $connection;
            $conn = $connection;
            $pId = $_SESSION['personId'];

            $q = "SELECT * FROM `character_certificate` 
            WHERE `requested_person_id` = $pId";
            
            $res = $conn->query($q);

            if($res->num_rows > 0){
                while($row = $res->fetch_assoc()){
                    $district = $row['district'];
                    $divSecratary = $row['divi_sec_div'];
                    $gnDivision = $row['gn_div_name'];
                    $dgnKnown = $row['applicant_known_by_gn'];
                    $sinceDate = $row['if_so_since_when'];
                    $name = $row['applicant_name'];
                    $address = $row['applicant_address'];
                    $age = $row['age'];
                    $civilStatus = $row['civil_status'];
                    $isSL  = $row['sri_lankan_or_not'];
                    $religion = $row['religion'];
                    $occupation = $row['present_ocupation'];
                    $resiVillage = $row['period_of_residence'];
                    $nic = $row['nic'];
                    $elecReg = $row['no_of_electotial_reg'];
                    $fatherName = $row['name_of_father'];
                    $certPurpose = $row['purpose'];
                    $residPeriod = $row['period_of_residence_in_gn'];
                    $natureResEvd = $row['nature_of_other_evidence'];
                    $convByLaw = $row['applicant_has_been_convicted'];
                    $act = $row['interest_in_public_activities'];
                    $charc = $row['hisorher_character'];
                    $remark = $row['remark'];
                    $regNo = $row['reg_no'];
                    $issuer = $row['issuer'];
                }
            }
        }
        else{
            echo '<div class="alert alert-danger">Unable to open the certificate!</div>';
        }
    ?>

    <div class="container">
        <h3 class="heading"><b>Certificate on residence and character issued by the Grama Niladhari</b></h3>
        <div class="sub-text">
            <h6>This certificate is issued by the Grama Niladhari of the Division in which the applicant 
            resides is valid only for 06 months from the date countersigned by the Divisional Secretary.</h6>
        </div>

        <div class="section">
            <h4 class="section-heading">1. Information about Grama Niladhari Division</h4>
            <div class="section-content">
                <div class="row">
                    <div class="col-6">a) District: </div>
                    <div class="form-group col-6">
                        <span><?php echo $district; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">b) Divisional Secratary's Division: </div>
                    <div class="form-group col-6">
                        <span><?php echo $divSecratary; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">c) Grama Niladhari Division: </div>
                    <div class="form-group col-6">
                        <span><?php echo $gnDivision; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">d) Whether applicant is personally known to the Grama Niladhari:</div>
                    <div class="form-group col-6">
                        <span><?php echo $dgnKnown == 0 ? 'No' : 'Yes'; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">e) If so, since when:  </div>
                    <div class="form-group col-6">
                        <span><?php echo $dgnKnown == 0 ? 'None' : $sinceDate; ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="section">
            <h4 class="section-heading">2. Information about applicant</h4>
            <div class="section-content">
                <div class="row">
                    <div class="col-6">a) Name: </div>
                    <div class="form-group col-6">
                        <span><?php echo $name; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">b) Address: </div>
                    <div class="form-group col-6">
                        <span><?php echo  $address; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">c) Age:</div>
                    <div class="form-group col-6">
                        <span><?php echo  $age; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">d) Civil Status:</div>
                    <div class="form-group col-6">
                        <span><?php echo $civilStatus; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">e) Whether Sri Lankan?: </div>
                    <div class="form-group col-6">
                        <span><?php echo $isSL ; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">f) Religion:  </div>
                    <div class="form-group col-6">
                        <span><?php echo $religion; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">g) Present Occupation:  </div>
                    <div class="form-group col-6">
                        <span><?php echo $occupation; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">h) Period of residence in the village: </div>
                    <div class="form-group col-6">
                        <span><?php echo $resiVillage; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">i) National Identity Card Number: </div>
                    <div class="form-group col-6">
                        <span><?php echo $nic; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">j) Number of Electotial Register & Particulars of Registration: </div>
                    <div class="form-group col-6">
                        <span><?php echo $elecReg; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">k) Name and Address of the father: </div>
                    <div class="form-group col-6">
                        <span><?php echo $fatherName; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">l) Purpose for which the certificate is required: </div>
                    <div class="form-group col-6">
                        <span><?php echo $certPurpose; ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="section">
            <h4 class="section-heading">3. Other Information</h4>
            <div class="section-content">
                <div class="row">
                    <div class="col-6">a) Period of the residence in the Grama Niladhari Division: </div>
                    <div class="form-group col-6">
                        <span><?php echo $residPeriod; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">b) Nature of other evidences in proof of the period of residence:  </div>
                    <div class="form-group col-6">
                        <span><?php echo$natureResEvd; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">c) Whether the applicant has been convicted by Court of Law?: </div>
                    <div class="form-group col-6">
                        <span><?php echo $convByLaw; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">d) Whether he/she has taken an interest in public activities social services work community work etc.:  </div>
                    <div class="form-group col-6">
                        <span><?php echo $act; ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">e) His/her character:   </div>
                    <div class="form-group col-6">
                        <span><?php echo $charc; ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="section">
            <h4 class="section-heading">4. Remark</h4>
            <div class="section-content">
                <div class="row">
                    <div class="form-group col-10">
                        <span><?php echo $remark; ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="section-content dec-text">
                <h6>It is hereby certified that the above particulars are correct to the best of my 
                knowledge, he/she is a citizen of Sri Lanka by descent/registration, his/her Certificate
                of Registration Number is
                <span><?php echo $regNo; ?></span>
                and that it has been issued by
                <span><?php echo $issuer."."; ?></span></h6>
            </div>
        </div>
    </div>
    
    <footer>
        <div class="container hide" style="text-align:right">
            <button class="btn btn-sm btn-secondary" id="print" title="Print Certificate"><i class="fa fa-print"></i></button> 
        </div>
    </footer>

    <style>
        @media print{
            .hide{
                display: none;
            }
        }
    </style>

    <script>
        $('#print').click(() => { print(); });
    </script>
</body>
</html>

