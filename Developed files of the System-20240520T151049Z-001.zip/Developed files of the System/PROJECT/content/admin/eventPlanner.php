<style>
    .header{
        margin-top: 10px;
        background-color: #eee;
        border-radius: 10px;
    }

    .header-topic{
        line-height: 3;
        font-size: 1.6rem;
        font-weight: bold;
    }

    .header-button-box{
        text-align: right;
        line-height: 4;
    }

    .add{
        border: none;
        background-color: argb(0 0 0 0);
        color: rgb(100, 100, 100);
        font-size: 1.2rem;
        transition: 0.4s;
        cursor: pointer;
    }

    .add:hover{
        color: rgb(220, 34, 75);
    }

    .val{
        font-size: 0.8rem;
        color: red;
    }
</style>
<script src="./js/event-planner.js"></script>

<div class="container">
    <div class="row header mb-4">
        <div class="col-md-8 header-topic">Event Planner</div>
        <div class="col-md-4 header-button-box">
            <button class="add"><i class="fa fa-folder"></i></button>
        </div>
    </div>

    <div class="table-container">
        <table class="table">
            <thead>
                <th>Action</th>
                <th>Name</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Location</th>
                <th>Is Public</th>
            </thead>
            <tbody>
                <?php
                    include '../../DB/conn.php';

                    global $connection;
                    $conn = $connection;
                    session_start();
                
                    $data = array();
                
                    $q = "SELECT * FROM `event`";
                    $id;
                    $name;
                    $date;
                    $sTime;
                    $eTime;
                    $loc;
                    $isPub;

                    $res = $conn->query($q);
                    if($res->num_rows > 0){
                        while($row = $res->fetch_assoc()){
                            $id = $row['event_id'];
                            $name = $row['event_name'];
                            $date = $row['date'];
                            $sTime = $row['start_time'];
                            $eTime = $row['end_time'];
                            $loc = $row['location'];
                            $isPub = $row['is_public'] == true ? 'Yes' : 'No';

                            echo "<tr>
                                <td>
                                    <button onclick=\"remove($id)\" class=\"btn btn-sm btn-danger\" title=\"Delete Event\">
                                        <i class=\"fa fa-minus-circle\"></i>
                                    </button>
                                </td>
                                <td>$name</td>
                                <td>$date</td>
                                <td>$sTime</td>
                                <td>$eTime</td>
                                <td>$loc</td>
                                <td>$isPub</td>
                            </tr>";
                        }
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="addEvent" tabindex="-1" role="dialog" aria-labelledby="addEventLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEventLabel">Add Event</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="data" enctype="multipart/form-data">
                    <div class="container">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control form-control-sm" id="name" name="name">
                            <span class="val" id="nameVal"></span>
                        </div>

                        <div class="form-group">
                            <label>Date</label>
                            <input type="date" class="form-control form-control-sm" id="date" name="date">
                            <span class="val" id="dateVal"></span>
                        </div>

                        <div class="form-group">
                            <label>Start Time</label>
                            <input type="time" class="form-control form-control-sm" id="sTime" name="sTime">
                            <span class="val" id="sTimeVal"></span>
                        </div>

                        <div class="form-group">
                            <label>End Time</label>
                            <input type="time" class="form-control form-control-sm" id="eTime" name="eTime">
                            <span class="val" id="eTimeVal"></span>
                        </div>

                        <div class="form-group">
                            <label>Location</label>
                            <input type="text" class="form-control form-control-sm" id="loc" name="loc">
                            <span class="val" id="locVal"></span>
                        </div>

                        <div class="form-group">
                            <label style="margin-right: 10px;">Is Public</label>
                            <input type="checkbox" id="pub">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-primary" id="create">Create</button>
            </div>
        </div>
    </div>
</div>