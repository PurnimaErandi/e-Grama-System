<div class="col-lg-12">
        <h2>Work Plans</h2>
        <hr>
        <div class="col-lg-12">
            <form id="work_plan_forms" method="post">
    
                <div class="form-group col-lg-6" style="float:left">
                    <label for="date">Date:</label>
                    <input type="date" class="form-control" id="date" name="date">
                    <span class="val text-danger" id="dateVal"></span>
                </div>
                <div class="form-group col-lg-6" style="float:left">
                    <label for="time">Time:</label>
                    <input type="time" class="form-control" id="time" name="time">
                    <span class="val text-danger" id="timeVal"></span>
                </div>
                <div class="form-group col-lg-12" style="float:left">
                    <label for="typeofwrk">Type of Work:</label>
                    <select class="form-control" id="typeofwork" name="typeofwork">
                        <option value="Seminars">Seminars</option>
                        <option value="Meetings">Meetings</option>
                        <option value="Wesak Festival">Wesak Festival</option>
                        <option value="Poson Festival">Poson Festival</option>
                        <option value="Functions">Functions</option>
                        <option value="Weddings">Weddings</option>
                        <option value="Independence Day">Independence Day</option>
                        <option value="Social Activities">Social Activities</option>
                        <option value="Social Meetings">Social Meetings</option>
                    </select>
                    <span class="val text-danger" id="typeofworkVal"></span>
                </div>
                <div class="form-group col-lg-12" style="float:left">
                    <label for="descriptn">Description:</label>
                    <textarea class="form-control" rows="15" id="descriptn" name="descriptn"></textarea>
                    <span class="val text-danger" id="descriptnVal"></span>
                </div>
                <input type="button" class="btn btn-primary" value="Save" id="save">     
                <input type="reset" class="btn btn-dark" value="Cancel" id="cancel">
            </form>
    
        </div>
    
    </div>
    
    <script src="js/work-plan.js"></script>
