        <div class="container">
            <section id="residenceCertificate">
                <h3 class="heading"><b>Certificate of Residence</b></h3>
                    <div class="sub-text">
                        This certificate is issued by the Grama Niladhari of the Division in which the applicant 
                        resides is valid only for 06 months from the date countersigned by the Divisional Secretary.
                    </div>
                <hr>
                <br>
                <form id="res-cert" enctype="multipart/form-data">
                    <!-- Residence details -->
                    <div class="section">
                        <div class="section-content">
                            <div class="row">
                                <div class="col-lg-4">1. Divisional Secretariat Division : </div>
                                <div class="form-group col-lg-8">
                                    <select class="form-control form-control-sm" id="divSecList" name="divSecList">
                                        <option value="">-Please Select-</option>
                                        <option>Attanagalla Divisional Secretariat</option>
                                        <option>Biyagama Divisional Secretariat</option>
                                        <option>Divulapitiya Divisional Secretariat</option>
                                        <option>Dompe Divisional Secretariat</option>
                                        <option>Gampaha Divisional Secretariat</option>
                                        <option>Ja-Ela Divisional Secretariat</option>
                                        <option>Katana Divisional Secretariat</option>
                                        <option>Kelaniya Divisional Secretariat</option>
                                        <option>Mahara Divisional Secretariat</option>
                                        <option>Minuwangoda Divisional Secretariat</option>
                                        <option>Mirigama Divisional Secretariat</option>
                                        <option>Negombo Divisional Secretariat</option>
                                        <option>Wattala Divisional Secretariat</option>
                                    </select>
                                    <span class="val text-danger" id="divSecListVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">2. Name of person : </div>
                                <div class="form-group col-lg-8">
                                    <input type="text" class="form-control form-control-sm" id="personName" name="personName"/>
                                    <span class="val text-danger" id="personNameVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">3. Permanent Residence : </div>
                                <div class="form-group col-lg-8">
                                    <input type="text" class="form-control form-control-sm" id="residence" name="residence"/>
                                    <span class="val text-danger" id="residenceVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">4. National Identity Card No : </div>
                                <div class="form-group col-lg-8">
                                    <input type="text" class="form-control form-control-sm" id="nic" name="nic"/>
                                    <span class="val text-danger" id="nicVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">5. Date of Birth : </div>
                                <div class="form-group col-lg-8">
                                    <input type="date" class="form-control form-control-sm" id="dob" name="dob"/>
                                    <span class="val text-danger" id="dobVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">6. Age (Years) : </div>
                                <div class="form-group col-lg-8">
                                    <input type="number" class="form-control form-control-sm" id="age" name="age"/>
                                    <span class="val text-danger" id="ageVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">7. Residing Grama Niladhari Division : </div>
                                <div class="form-group col-lg-8">
                                    <select class="form-control form-control-sm" id="residingGND" name="residingGND">
                                        <option value="">-Please Select-</option>
                                        <option value="Batuwatta West Grama Niladhari Division">Batuwatta West Grama Niladhari Division</option>
                                        <option value="Batuwatta East Grama Niladhari Division">Batuwatta East Grama Niladhari Division</option>
                                        <option value="Dandugama Grama Niladhari Division">Dandugama Grama Niladhari Division</option>
                                        <option value="Narangodapaluwa West Grama Niladhari Division">Narangodapaluwa West Grama Niladhari Division</option>
                                        <option value="Narangodapaluwa East Grama Niladhari Division">Narangodapaluwa East Grama Niladhari Division</option>
                                        <option value="Peralanda Grama Niladhari Division">Peralanda Grama Niladhari Division</option>
                                        <option value="Thewatta Grama Niladhari Division">Thewatta Grama Niladhari Division</option>
                                        <option value="Thudella North Grama Niladhari Division">Thudella North Grama Niladhari Division</option>  
                                    </select>
                                    <span class="val text-danger" id="residingGNDVal"></span>
                                </div>
                            </div>
                            <div class="row" > 
                                <div class="col-lg-4">8. Purpose: </div>
                                <div class="form-group col-lg-8">
                                    <input type="text" class="form-control form-control-sm" id="purpose" name="purpose"/>
                                    <span class="val text-danger" id="purposeVal"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <br>
                    <!-- Declaration -->
                    <div class="section">
                        <div class="section-content dec-text">
                            I certify that the above name mentioned person Mr./Mrs 
                            <input type="text" class="dec form-control form-control-sm" placeholder="Applicant name..." id="appName" name="appName" />
                            is a permanent resident in Grama Niladhari Division
                            <input type="text" class="dec form-control form-control-sm" placeholder="GN division..." id="gndivision" name="gndivision"/>.       
                        </div>
                    </div> 
                </form>
            </section> 
            <br>  
            <hr>
            <br>
            <br>
            <div class="controls">
                <button class="btn btn-primary btn-sm" id="submit">Submit</button>
                <button class="btn btn-outline-secondary btn-sm" id="clear">Clear</button>
            </div>
        </div>

        <!-- Confirm window -->
        <div class="modal" id="confirm-window" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title">Create Residence Certificate</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div>Select Person</div>
                            <select class="form-control form-control-sm" id="person-list">
                                <?php
                                include '../../DB/conn.php';
                                global $connection;

                                $query = "SELECT * FROM `person`";
                                $result = mysqli_query($connection, $query);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<option value=". $row["idperson"] .">".$row["nameof_person"]." (".$row["nic"].")</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="save-form">Save changes</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>

        <style>
            .select2-container{
                width: 100%!important;
            }
            *{
                --gray : rgb(54, 54, 54);
                --light-gray: rgb(180, 180, 180);
            }
            .row{
                margin-right: 0;
            }
            .heading{
                text-align: center;
                font-weight: 400;
            }
            .sub-text{
                text-align: center;
                font-size: 0.85rem;
                margin: 20px 0;
            }
            .controls{
                text-align: right;
                margin-bottom: 20px;
            }
            .dec {
                width: 180px;
                display: inline-block;
            }
        </style>

        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            $(document).ready(() => {
                $('#clear').click(() => { clear(); })
                $('#submit').click(() => { submit(); })

                $('#divSecList').change(() => { validateDiv(); })
                $('#personName').on('change keyup', () => { validateName(); })
                $('#residence').on('change keyup', () => { validateAddr(); })
                $('#nic').on('change keyup', () => { validateNic(); })
                $('#dob').on('change', () => { validateDoB(); setAge(); validateAge(); })
                $('#residingGND').on('change keyup', () => { validateResGN(); })
                $('#purpose').on('change keyup', () => { validatePps(); })
            })

            function submit(){
                if(isValidate()){
                    var win = $('#confirm-window');
                    win.modal('show');
                }
                else{
                    $('.in-err').filter(':first').focus();
                }
            }

            $('#save-form').click(() => {
                var l = $('#person-list');
                if(l.val() == null || l.val() == '')
                    alert('Something went wrong!');
                else{
                    var form = document.getElementById("res-cert");
                    var data = new FormData(form);
                    data.append('requested_person_id', $('#person-list').val());
                    
                    $.ajax({
                        type: 'post',
                        url: './controls/admin/save_resiCertificate.php',
                        processData: false,
                        contentType: false,
                        data: data,
                        success: function(r){
                            alert(r);
                            form.reset();
                            $('.modal').modal('toggle');
                        },
                        error: function(){
                            alert('Something went wrong!');
                        },
                        complete: function(){
                            l.prop("selectedIndex", 0).val();
                        }
                    });
                }
            });

            function clear(){
                $('input').val('');
                $("select").prop("selectedIndex", 0).val();
            }

            function addValidation(valIn, validationIndicator, message){
                validationIndicator.html(message);
                valIn.addClass('in-err');
            }

            function removeValidation(valIn, validationIndicator){
                validationIndicator.html('');
                valIn.removeClass('in-err');
            }

            function isValidate(){
                return validateDiv() & validateName() & validateAddr() & validateNic() & validateDoB()
                & validateAge() & validateResGN() & validatePps();
            }

            /* Validations */
            function validateDiv(){
                if($('#divSecList').val() == ''){
                    addValidation($('#divSecList'), $('#divSecListVal'), 'Divisional Secretariat Division is required');
                    $('#divSecList').focus();
                    return false;
                }
                removeValidation($('#divSecList'), $('#divSecListVal'));
                return true;
            }

            function validateName(){
                if($('#personName').val() == ''){
                    addValidation($('#personName'), $('#personNameVal'), 'Name is required');
                    $('#personName').focus();
                    return false;
                }
                removeValidation($('#personName'), $('#personNameVal'));
                return true;
            }

            function validateAddr(){
                if($('#residence').val() == ''){
                    addValidation($('#residence'), $('#residenceVal'), 'Residence Address is required');
                    $('#residence').focus();
                    return false;
                }
                removeValidation($('#residence'), $('#residenceVal'));
                return true;
            }

            function validateNic(){
                if($('#nic').val() == ''){
                    addValidation($('#nic'), $('#nicVal'), 'NIC number is required');
                    $('#nic').focus();
                    return false;
                }
                var len = $('#nic').val().length
                if(!(len == 10 || len == 12)){
                    addValidation($('#nic'), $('#nicVal'), 'Invalid NIC number');
                    $($('#nic')).focus();
                    return false;
                }
                var regex = len == 10 ? /[1-9]{1}[0-9]{8}[vVxX]{1}/
                    : len == 12 ? /[1-9]{1}[0-9]{11}/ : '';
                if(!regex.test($('#nic').val())){
                    addValidation($('#nic'), $('#nicVal'), 'Incorrect NIC number format');
                    $($('#nic')).focus();
                    return false;
                }
                removeValidation($('#nic'), $('#nicVal'));
                return true;
            }

            function validateDoB(){
                if($('#dob').val() == ''){
                    addValidation($('#dob'), $('#dobVal'), 'Date of birth is required');
                    $('#dob').focus();
                    return false;
                }
                var dob = $('#dob').val();
                var d = new Date(dob);
                if(d > new Date()){
                    addValidation($('#dob'), $('#dobVal'), 'Date of birth cannot be in future');
                    $('#dob').focus();
                    return false;
                }

                removeValidation($('#dob'), $('#dobVal'));
                return true;
            }

            function setAge(){
                if($('#dob').val() != ''){
                    var dob = new Date($('#dob').val());
                    var today = new Date();
                    if(dob <= today){
                        var age = (Date.parse(today) - Date.parse(dob)) / (1000 * 3600* 24 * 365);
                        $('#age').val(parseInt(age));
                    }
                }
            }

            function validateAge(){
                if($('#age').val() == ''){
                    addValidation($('#age'), $('#ageVal'), ' Age is required');
                    $('#age').focus();
                    return false;
                }

                removeValidation($('#age'), $('#ageVal'));
                return true;
            }

            function validateResGN(){
                if($('#residingGND').val() == ''){
                    addValidation($('#residingGND'), $('#residingGNDVal'), 'Residing GN division is required');
                    $('#residingGND').focus();
                    return false;
                }
                removeValidation($('#residingGND'), $('#residingGNDVal'));
                return true;
            }

            function validatePps(){
                if($('#purpose').val() == ''){
                    addValidation($('#purpose'), $('#purposeVal'), 'Purpose is required');
                    $('#purpose').focus();
                    return false;
                }
                removeValidation($('#purpose'), $('#purposeVal'));
                return true;
            }
        </script> 