<div class="container">
        <div class="row header">
            <div class="col-md-8 header-topic">
                <b>Disaster Management</b>
            </div>
            <div class="col-md-4 header-button-box">
                <button title="Add Disaster details" class="add-disaster" id="add-disaster"><i class="fa fa-folder"></i></button>
            </div>
        </div>

        <div class="body">
            <table class="table table-sm table-striped" id="data">
                <thead>
                    <tr>
                        <th scope="col">Action</th>
                        <th scope="col">Date</th>
                        <th scope="col">Remark</th>
                        <th scope="col">Disaster Type</th>
                        <th scope="col">Damages</th> 
                        <th scope="col">Other Details</th>
                    </tr>
                </thead>
                <tbody class="disaster-table">
    
                </tbody>
            </table>
        </div>
        
        <br>
        
        <div class="mainMapContainer">
            <div id="mainMap" class="mainMap"></div>
        </div>

        <div class="modal fade" id="add-disaster-window" tabindex="-1" role="dialog" aria-labelledby="lbladdDis" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
                    <div class="modal-header">
                        <h6 class="modal-title" id="lblNewDis">Add Disaster Details</h6>
                        <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body modal-container">
                        <form enctype="multipart/form-data" id="disaster-form">
                                <div class="row group">
                                    <label>Date</label>
                                    <input type="date" class="form-control form-control-sm" id="date" name="date"/>
                                    <span class="val text-red" id="dateVal"></span>
                                </div>
                                <div class="row group">
                                    <label>Remark</label>
                                    <textarea class="form-control form-control-sm" id="remark" name="remark"></textarea>
                                    <span class="val text-red" id="remarkVal"></span>
                                </div>
                                <div class="row group">
                                    <label>Location</label>
                                    <div class="input-group">
                                        <input readonly placeholder="Latitude" type="text" class="form-control form-control-sm" id="locLt" name="locLt">
                                        <input readonly placeholder="Longitude" type="text" class="form-control form-control-sm" id="locLg" name="locLg">
                                        <div class="input-group-append">
                                            <input type="button" class="btn btn-sm btn-primary" id="setLoc" value="Set" />
                                        </div>
                                    </div>
                                    <span class="val text-red" id="locVal"></span>
                                </div>
                                <div class="row group">
                                    <label for="disaster">Disaster Type</label>
                                    <select class="form-control" id="disaster" name="disaster">
                                        <option>Floods</option>
                                        <option>Landslides</option>
                                        <option>Epidemics</option>
                                        <option>Cyclone</option>
                                        <option>Tsunami</option>
                                        <option>Sea surge</option>
                                        <option>Storm surge</option>
                                        <option>Other-specify</option>
                                    </select>
                                    <span class="val text-danger" id="disasterVal"></span>
                                </div>
                                <div class="row group">
                                    <label>Damages</label>
                                    <textarea class="form-control form-control-sm" id="damages" name="damages"></textarea>
                                    <span class="val text-red" id="damagesVal"></span>
                                </div>
                                <div class="row group">
                                    <label>Other Details</label>
                                    <textarea class="form-control form-control-sm" id="other" name="other"></textarea>
                                    <span class="val text-red" id="otherVal"></span>
                            </div>
                        </form>  
                        <div class="row control-group">
                            <div class="control">
                            <button class="btn btn-sm btn-primary" id="submit">Submit</button>
                            </div>
                        </div>  
                    </div>    
                </div>
            </div>
        </div>

        <div class="modal fade" id="locationPicker" tabindex="-1" role="dialog" aria-labelledby="locationPickerLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="locationPickerLabel">Location Picker</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div id="map"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
</div>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCMrsWm_ka2vGqme0Uv5IDFYk0frGQ74OY&callback=initMap&libraries=&v=weekly" async differ></script>
<script src="./js/disaster.js"></script>
<link rel="stylesheet" href="./css/disaster.css" />
<style>
    .body{
        height: 40vh;
        overflow-y: scroll;
    }
    #map{
        width: 100%;
        height: 400px;
        background-color: #ddd;
        border-radius: 8px;
    }
    .mainMap{
        margin:0 auto; 
        width:80%; 
        height:30vh;
    }
</style>