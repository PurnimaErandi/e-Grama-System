<?php
    include '../../DB/conn.php';

    global $connection;
    $conn = $connection;
    session_start();
    $persons;
    $properties;
    $houses;
    $users;

    /* Data cards */

    $q = "SELECT COUNT(`idperson`) AS `person_count`
        FROM `person`;";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $persons = $row["person_count"];
        }
    }

    $q = "SELECT COUNT(`idproperty`) AS `property_count`
        FROM `property`";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $properties = $row["property_count"];
        }
    }

    $q = "SELECT COUNT(`house_no`) AS `house_count`
        FROM `house`";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $houses = $row["house_count"];
        }
    }

    $q = "SELECT COUNT(`request_id`) AS `user_count`
        FROM `user_request`";
    $res = $conn->query($q);
    if($res->num_rows > 0){
        while($row = $res->fetch_assoc()){
            $users = $row["user_count"];
        }
    }
?>

<div class="container">
    <h3>Dashboard</h3>
    <hr>
    <div class="row mb-3">
        <div class="col-md-3">
            <div class="data-card">
                <div class="icon bg-blue">
                    <i class="fas fa-user-alt"></i>
                </div>
                <div class="content">
                    <div style="line-height: 32px;">
                        <span><b>Total Person</b></span><br/>
                        <span class="val"><?php echo $persons ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="data-card">
                <div class="icon bg-red">
                    <i class="fas fa-landmark"></i>
                </div>
                <div class="content">
                    <div style="line-height: 32px;">
                        <span><b>Total Property</b></span><br/>
                        <span class="val"><?php echo $properties ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="data-card">
                <div class="icon bg-green">
                    <i class="fas fa-home"></i>
                </div>
                <div class="content">
                    <div style="line-height: 32px;">
                        <span><b>Total House</b></span><br/>
                        <span class="val"><?php echo $houses ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="data-card">
                <div class="icon bg-yellow">
                    <i class="fas fa-users"></i>
                </div>
                <div class="content">
                    <div style="line-height: 32px;">
                        <span><b>Total User</b></span><br/>
                        <span class="val"><?php echo $users ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>   
    <br>

    <!-- Upcoming Events -->
    <div class="row mb-3">
        <div class="col-md-12">
            <h5><b>Upcoming Events</b></h5>
            <br>
            <div class="data-container">
            <table class="table table-sm">
                    <thead class="table-header">
                        <th>Event Name</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Location</th>
                        <th>Public Event</th>
                    </thead>
                    <tbody>
        
                        <?php

                            include '../../DB/conn.php';

                            global $connection;
                            $conn = $connection;

                            $q = "SELECT * FROM `event` WHERE `date` >= CURDATE() ORDER BY `date` ASC";
                            $res = $conn->query($q);
                            
                            if (mysqli_num_rows($res) > 0) {
                                while ($row = mysqli_fetch_assoc($res)) {
                                    $p = $row["is_public"] == 1 ? 'Yes' : 'No';
                                    echo "<tr>
                                        <td>".$row["event_name"]."</td>
                                        <td>".$row["date"]."</td>
                                        <td>".$row["start_time"]."</td>
                                        <td>".$row["end_time"]."</td>
                                        <td>".$row["location"]."</td>
                                        <td>".$p."</td>

                                    </tr>";
                                    
                                }
                            }
                        ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br>

    <!-- Pending Accounts -->
    <div class="row mb-3">
        <div class="col-md-6">
            <h5><b>Pending Accounts</b></h5>
            <div class="data-container">
                <table class="table table-sm">
                    <thead class="table-header">
                        <th>Name</th>
                        <th>Email</th>
                        <th>NIC</th>
                        <th>Address</th>
                    </thead>
                    <tbody>
        
                        <?php

                            include '../../DB/conn.php';

                            global $connection;
                            $conn = $connection;

                            $q = "SELECT * FROM `user_request` WHERE `request_status` = 'pending'";
                            $res = $conn->query($q);
                            
                            if (mysqli_num_rows($res) > 0) {
                                while ($row = mysqli_fetch_assoc($res)) {
                                
                                    echo "<tr>
                                        <td>".$row["name"]."</td>
                                        <td>".$row["email"]."</td>
                                        <td>".$row["nic"]."</td>
                                        <td>".$row["address"]."</td>
                                    </tr>";
                                    
                                }
                            }
                        ?>

                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pending Certificates -->
        <div class="col-md-6">
            <h5><b>Pending Certificates</b></h5>
            <div class="data-container">
            <table class="table table-sm">
                    <thead class="table-header">
                        <th>Requestor</th>
                        <th>Certificate Name</th>
                        <th>Reason</th>
                        <th>Date</th>
                    </thead>
                    <tbody>
        
                        <?php

                            include '../../DB/conn.php';

                            global $connection;
                            $conn = $connection;

                            $q = "SELECT c.*, u.user_fullname FROM `certificate_request` c INNER JOIN `user` u "
                                . "ON c.person_id = u.iduser "
                                . "WHERE `request_status` = 'pending'";
                            $res = $conn->query($q);
                            
                            if (mysqli_num_rows($res) > 0) {
                                while ($row = mysqli_fetch_assoc($res)) {
                                
                                    echo "<tr>
                                        <td>".$row["user_fullname"]."</td>
                                        <td>".$row["certificate_name"]."</td>
                                        <td>".$row["reason_for_request"]."</td>
                                        <td>".str_replace("00:00:00", "", $row["request_date"])."</td>
                                    </tr>";
                                    
                                }
                            }
                        ?>

                    </tbody>
                </table>
            </div>
        </div>
        <br>
    </div>
    <br/>

    <!-- View User Contact US Details -->
    <div class="row mb-3">
            <div class="col-md-12">
                <h5><b>View User Contact Us Details</b></h5>
                <div class="data-container">
                <table class="table table-sm">
                        <thead class="table-header">
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                        </thead>
                        <tbody>
                            <?php
                                include '../../DB/conn.php';

                                global $connection;
                                $conn = $connection;

                                $q = "SELECT * FROM `contact_us`";
                                $res = $conn->query($q);

                                if (mysqli_num_rows($res) > 0) {
                                    while ($row = mysqli_fetch_assoc($res)) {
                                    
                                        echo "<tr>
                                            <td>".$row["name"]."</td>
                                            <td>".$row["email"]."</td>
                                            <td>".$row["subject"]."</td>
                                            <td>".$row["message"]."</td>
                                        </tr>";
                                        
                                    }
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
<link rel="stylesheet" href="css/dashboard.css"/>
