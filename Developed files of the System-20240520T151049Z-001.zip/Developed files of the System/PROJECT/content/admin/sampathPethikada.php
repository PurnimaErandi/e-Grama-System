<div class="container">  
  <h2><center>Sampath Pethikada</center></h2>
  <br>
  <div class="card-deck">
        <div class="card">
            <div class="card-body text-center">
                <p class="card-text topic topic-blue">
                    <b>Population</b> <span class="badge badge-primary" style="font-size: 85%;" id="population"></span>
                </p>
                <div>
                    <table>
                        <tbody>
                            <tr>
                                <td><i class="fas fa-male"></i></td>
                                <td>Male</td>
                                <td id="male"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-female" ></i></td>
                                <td>Female</td>
                                <td id="female"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body text-center">
                <p class="card-text topic topic-green"><b>Religion wise</b></p>
                <div>
                    <table>
                        <tbody>
                            <tr>
                                <td><i class="fas fa-dharmachakra"></i></td>
                                <td>Buddhism </td>
                                <td id="buddhist"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-om"></i></td>
                                <td>Hinduism</td>
                                <td id="hindu"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-star-and-crescent"></i></td>
                                <td>Islams</td>
                                <td id="islam"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-cross"></i></td>
                                <td >Catholics</td>
                                <td id="catholic"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-peace"></i></td>
                                <td>Other</td>
                                <td id="otherReligion"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body text-center">
                <p class="card-text topic topic-red"><b>Nationality wise</b></p>
                <div>
                    <table>
                        <tbody>
                            <tr>
                                <td><i class="fas fa-vihara"></i></td>
                                <td>Sinhalese</td>
                                <td id="sinhala"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-om"></i></td>
                                <td>Tamils</td>
                                <td id="tamil"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-mosque"></i></td>
                                <td>Muslims</td>
                                <td id="muslim"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-star-and-crescent"></i></td>
                                <td>Malay</td>
                                <td id="malay"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-yin-yang"></i></td>
                                <td>Burgher</td>
                                <td id="burgher"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-peace"></i></td>
                                <td>Other</td>
                                <td id="otherNationality"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="card-deck">
        <div class="card">
            <div class="card-body text-center">
                <p class="card-text topic topic-gray"><b>Liveliness wise</b></p>
                <div>
                    <table>
                        <tbody>
                            <tr>
                                <td><i class="fab fa-creative-commons-by"></i></td>
                                <td>Alive</td>
                                <td id="alive"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-skull-crossbones"></i></td>
                                <td>Dead</td>
                                <td id="dead"></td>
                            </tr>
                        </tbody>
                    </table>
                </div> 
            </div>
        </div>  
        <div class="card">
            <div class="card-body text-center">
                <p class="card-text topic topic-yellow"><b>Education wise</b></p>
                <div>
                    <table>
                        <tbody>
                            <tr>
                                <td><i class="fas fa-child"></i></td>
                                <td>1-5 Primary</td>
                                <td id="primary"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-chalkboard"></i></td>
                                <td>6-10 Secondary</td>
                                <td id="secondary"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-book-open"></i></td>
                                <td >Ordinary Level</td>
                                <td id="OL"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-book-reader"></i></td>
                                <td>Advanced Level</td>
                                <td id="AL"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-user-graduate"></i></td>
                                <td>Higher Studies</td>
                                <td id="higherStudy"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square"></i></td>
                                <td>Other</td>
                                <td id="otherEdu"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body text-center">
                <p class="card-text topic topic-navy"><b>Occupation wise</b></p>
                <div>
                    <table>
                        <tbody>
                            <tr>
                                <td><i class="fas fa-walking"></i></td>
                                <td>None</td>
                                <td id="none"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-seedling"></i></td>
                                <td>Cultivation</td>
                                <td id="culti"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-hammer"></i></td>
                                <td>Skilled Labour</td>
                                <td id="skilled"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-screwdriver"></i></td>
                                <td>Unskilled Labour</td>
                                <td id="unskilled"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-fish"></i></td>
                                <td>Fishing</td>
                                <td id="fishing"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-diagnoses"></i></td>
                                <td>Government Offices</td>
                                <td id="government"></td>
                            </tr>
                            <tr>
                                <td><i class="fa fa-hotel"></i></td>
                                <td>Private Sector</td>
                                <td id="private"> </td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-briefcase"></i></td>
                                <td>Small Business</td>
                                <td id="business"></td>
                            </tr>
                            <tr>
                                <td><i class="fab fa-apple-pay"></i></td>
                                <td>Services</td>
                                <td id="services"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-wallet"></i></td>
                                <td>Self-employee</td>
                                <td id="selfEmployee"></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square"></i></td>
                                <td>Others</td>
                                <td id="otherOccupation"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
  </div>
  <br>
<br>
<br>

<style>
    .card-body{
        padding: 0;
        padding-bottom: 1.25rem;
        box-shadow: 1px 1px 6px 3px rgb(0 0 0 / 30%);
    }
    p {
        font-size: 3.0rem;
    }

    tr td{
        text-align: left;
        padding-left: 10px;
        font-size: 1.0rem;
    }

    table i {
        font-size: 1.0rem;
        background-color: inherit;
    }

    .topic{
        border-radius: 0.25rem 0.25rem 0 0;
        line-height: 4rem;
    }

    table{
        margin: 0 auto;
        width: 75%;
    }

    .topic-blue{
        background-color: #cae1fa;
        color: #243364;
        font-size: 18px;
    }

    .topic-green{
        background-color: #e3fae9;
        color: #348772;
        font-size: 18px;
    }

    .topic-red{
        background-color: #f4dacf;
        color: #ac4139;
        font-size: 18px;
    }

    .topic-gray{
        background-color: #d3d7d4;
        color: #565a59;
        font-size: 18px;
    }

    .topic-yellow{
        background-color: #eeebb1;
        color: #9f842a;
        font-size: 18px;
    }

    .topic-navy{
        background-color: #bfc5d9;
        color: #2a359f;
        font-size: 18px;
    }

</style>

<script>
    $(document).ready(() => {
        loadData();
    })

    function loadData(){
        var data;
        $.ajax({
            type: 'post',
            url: './controls/admin/sampathpethikadaData.php',
            contentType: false,
            success: function(r){
                data = JSON.parse(r);
            },
            error: function(){
                system_alert('Something went wrong!');
            },
            complete: function(){
                fillData(data);
            }
        })
    }

    function fillData(x){
        $('#population').html(x.genderWise.Male + x.genderWise.Female);
        $('#male').html('Male' in x.genderWise ? x.genderWise.Male : 0);
        $('#female').html('Female' in x.genderWise ? x.genderWise.Female : 0);

        $('#buddhist').html('Buddhism' in x.religionWise ? x.religionWise.Buddhism : 0);
        $('#hindu').html('Hinduism' in x.religionWise ? x.religionWise.Hinduism : 0);
        $('#islam').html('Islam' in x.religionWise ? x.religionWise.Islam : 0);
        $('#catholic').html('Catholic' in x.religionWise ? x.religionWise.Catholic : 0);
        $('#otherReligion').html('Other' in x.religionWise ? x.religionWise.Other : 0);

        $('#sinhala').html('Sinhalese' in x.nationalityWise ? x.nationalityWise.Sinhalese : 0);
        $('#tamil').html('Tamils' in x.nationalityWise ? x.nationalityWise.Tamils : 0);
        $('#muslim').html('Muslims' in x.nationalityWise ? x.nationalityWise.Muslims : 0);
        $('#burgher').html('Burgher' in x.nationalityWise ? x.nationalityWise.Burgher : 0);
        $('#malay').html('Malay' in x.nationalityWise ? x.nationalityWise.Malay : 0);
        $('#otherNationality').html('Other' in x.nationalityWise ? x.nationalityWise.Other : 0);

        $('#alive').html('alive' in x.aliveWise ? x.aliveWise.alive : 0);
        $('#dead').html('dead' in x.aliveWise ? x.aliveWise.dead : 0);

        $('#primary').html('1-5 Primary' in x.educationWise ? x.educationWise['1-5 Primary'] : 0);
        $('#secondary').html('6-10 Secondary' in x.educationWise ? x.educationWise['6-10 Secondary'] : 0);
        $('#OL').html('Ordinary Level' in x.educationWise ? x.educationWise['Ordinary Level'] : 0);
        $('#AL').html('Advanced Level' in x.educationWise ? x.educationWise['Advanced Level'] : 0);
        $('#higherStudy').html('Higher Studies' in x.educationWise ? x.educationWise['Higher Studies'] : 0);
        $('#otherEdu').html('Other' in x.educationWise ? x.educationWise['Other'] : 0);

        $('#none').html('None' in x.occupationWise ? x.occupationWise['None'] : 0);
        $('#culti').html('Cultivation' in x.occupationWise ? x.occupationWise['Cultivation'] : 0);
        $('#skilled').html('Skilled Labour(Carpenters,Masons,Electricians etc.)' in x.occupationWise ? x.occupationWise['Skilled Labour(Carpenters,Masons,Electricians etc.)'] : 0);
        $('#unskilled').html('Unskilled Labour' in x.occupationWise ? x.occupationWise['Unskilled Labour'] : 0);
        $('#fishing').html('Fishing' in x.occupationWise ? x.occupationWise['Fishing'] : 0);
        $('#government').html('Government Offices' in x.occupationWise ? x.occupationWise['Government Offices'] : 0);
        $('#private').html('Private Sector' in x.occupationWise ? x.occupationWise['Private Sector'] : 0);
        $('#business').html('Small Business' in x.occupationWise ? x.occupationWise['Small Business'] : 0);
        $('#services').html('Services' in x.occupationWise ? x.occupationWise['Services'] : 0);
        $('#selfEmployee').html('Self-employee' in x.occupationWise ? x.occupationWise['Self-employee'] : 0);
        $('#otherOccupation').html('Others' in x.occupationWise ? x.occupationWise['Others'] : 0);
        
    }
</script>