
    <div class="container">
        <h2>Property Management</h2>

        <ul class="nav nav-tabs" role="tablist">

            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#prop">Property Management Details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#home">Household Basic Details</a>
            </li>
        </ul>
        <br>
        <div class="tab-content">
            <!-- Property info -->
            <div class="tab-pane fade show active" id="prop">
                <form id="propInfo" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="gnoffice">Grama Niladhari Office:</label>
                            <select class="form-control" id="gnoffce" name="gnoffice">
                                <option>- Please Select -</option>
                                <option>Batuwatta East GN Division</option>
                                <option>Batuwatta West GN Division</option>
                                <option>Batagama North GN Division</option>
                                <option>Dambuwa GN Division</option>
                                <option>Kandana East GN Division</option>
                                <option>Nagoda GN Division</option>
                                <option>Nedurupitya GN Division</option>
                                <option>Narangodapaluwa East GN Division</option>
                                <option>Narangodapaluwa West GN Division</option>
                                <option>Wishakawatta GN Division</option>
                                <option>Yakkaduwa GN Division</option>
                            </select>
                            <span class="val text-danger" id="val-gnoffce"></span>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="address">Address:</label>
                            <textarea class="form-control" rows="4" id="address" name="address"></textarea>
                            <span class="val text-danger" id="val-address"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="prchseoflnd">Purchase of Land:</label>
                            <input type="number" class="form-control" id="purchaseland" name="purchofland">
                            <span class="val text-danger" id="val-purchaseland"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="majorcrps">Major Crops:</label>
                            <input type="text" class="form-control" id="majorcrps" name="mcrops">
                            <span class="val text-danger" id="val-majorcrps"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="Lat">House Latitude:</label>
                            <input type="number" step="0.0001" class="form-control" id="lati" name="lati">
                            <span class="val text-danger" id="val-lati"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="Lang">House Longitude:</label>
                            <input type="number" step="0.0001" class="form-control"  id="long" name="long">
                            <span class="val text-danger" id="val-long"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <a class="btn btn-info btn-block inform-btn" id="setLoction">Set Current Location</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="village">Village/Street Name:</label>
                            <input type="text" class="form-control" id="vorstreet" name="villstrtname">
                            <span class="val text-danger" id="val-vorstreet"></span>
                        </div>
                    </div>

                    <hr/>

                    <h5>Other Infrastructure Details</h5>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="water">Water Supply:</label>
                            <select class="form-control" id="wter">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-wter"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="lghts">Lights:</label>
                            <select class="form-control" id="lghts">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-lghts"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="tolets">Toilets:</label>
                            <select class="form-control" id="tlets">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-tlets"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="garbage">Waste Disposal:</label>
                            <select class="form-control" id="grbge">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-grbge"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12 control-box">
                            <input type="button" class="btn btn-primary" id="save-p" value="Save"/>
                            <input type="reset" class="btn btn-dark" id="clear-p" value="Clear"/>
                        </div>
                    </div>
                </form>
            </div>

            <!-- House info -->
            <div class="tab-pane fade" id="home">
                <form id="houseInfo" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label>Select Address</label>
                            <select class="form-control form-control-xs" id="prop_load" required>
                                <option>- Please Select -</option>
                                <?php
                                        include '../../DB/conn.php';
                                        global $connection;
                                	    $query = "SELECT * FROM `property`";
                                        $result = mysqli_query($connection, $query);
                                	    if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                	            echo "<option value='" . $row['idproperty'] . "'>" . $row['address'] . "</option>";
                                	        }
                                	    }
                                ?>  
                                
                            </select>
                            <span class="val text-danger" id="val-prop_load"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <label>House Name</label>
                            <input type="text" class="form-control" id="hse" name='hname'>
                            <span class="val text-danger" id="val-hse"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="husestates">House Status:</label>
                            <select class="form-control" id="hsetus" name="husestates">
                                <option>- Please Select -</option>
                                <option>Freehold houses</option>
                                <option>Free of rent</option>
                                <option>Government-owned rent</option>
                                <option>Government owned taxes</option>
                                <option>Illegal</option>
                                <option>Private rental houses</option>
                                <option>Other</option> 
                            </select>
                            <span class="val text-danger" id="val-hsetus"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="husetype">House Type:</label>
                            <select class="form-control" id="htype" name="husetype">
                                <option>- Please Select -</option>
                                <option>Apartment</option>
                                <option>Flat</option>
                                <option>Line rooms</option>
                                <option>Single storey house</option>
                                <option>Two storey house</option>
                                <option>More than two storey house</option>
                                <option>Sub house</option>
                                <option>Shanty house</option>
                                <option>Other</option> 
                            </select>
                            <span class="val text-danger" id="val-htype"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="walls">Walls:</label>
                            <select class="form-control" id="wal" name="wals">
                                <option>- Please Select -</option>
                                <option>Bricks</option>
                                <option>Cement stones</option>
                                <option>Coconut branches</option>
                                <option>Glass</option>
                                <option>Kabok Stones</option>
                                <option>Stones</option>
                                <option>Palm branches</option>
                                <option>Partition Wall</option>
                                <option>Pottery & ceramics clay</option>
                                <option>Wood Paneling</option>
                                <option>Other</option>
                            </select>
                            <span class="val text-danger" id="val-wal"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="floor">Floor:</label>
                            <select class="form-control" id="floor" name="flr">
                                <option>- Please Select -</option>
                                <option>Cement</option>
                                <option>Concreate</option>
                                <option>Teraso</option>
                                <option>Granite</option>
                                <option>Sand</option>
                                <option>Pottery & ceramics clay</option>
                                <option>Wood</option>
                                <option>Other</option>
                            </select>
                            <span class="val text-danger" id="val-floor"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="roofs">Roofs:</label>
                            <select class="form-control" id="rof" name="roofs">
                                <option>- Please Select -</option>
                                <option>Aluminium sheets</option>
                                <option>Concreate</option>
                                <option>Coconut branches</option>
                                <option>Sheets</option>
                                <option>Asbastos</option>
                                <option>other</option>
                            </select>
                            <span class="val text-danger" id="val-roofs"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                <label for="date">House Built Date:</label>
                                <input type="date" class="form-control" id="date" name="date">
                                <span class="val text-danger" id="val-date"></span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="odetails">Other Details:</label>
                            <textarea class="form-control" rows="6" id="odetails" name="text"></textarea>
                            <span class="val text-danger" id="val-odetails"></span>
                        </div>
                    </div>

                    <hr/>

                    <h5>Other Infrastructure Details</h5>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="radio">Radio:</label>
                            <select class="form-control" id="rdio">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-rdio"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="televisn">Television:</label>
                            <select class="form-control" id="tv" >
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-tv"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="landline">Landline Phones:</label>
                            <select class="form-control" id="lndlne" >
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-lndlne"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="mphone">Mobile Phones:</label>
                            <select class="form-control" id="mobphone" >
                                <option value="0">No</option>
                                <<option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-mobphone"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="deskcomputer">Desktop Computer:</label>
                            <select class="form-control" id="deskcom" >
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-deskcom"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="laptop">Laptop:</label>
                            <select class="form-control" id="lptop">
                                 <option value="0">No</option>
                                 <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-lptop"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="interncon">Internet Connections:</label>
                            <select class="form-control" id="intercon">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-intercon"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="washmchn">Washing Machine:</label>
                            <select class="form-control" id="wmahine">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-wmahine"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="refrigertr">Refrigerator:</label>
                            <select class="form-control" id="refrig">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-refrig"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="aircondtnr"> Air Conditioner:</label>
                            <select class="form-control" id="aircondtr">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-aircondtr"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="gascker">Gas Cooker:</label>
                            <select class="form-control" id="gascker" >
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-gascker"></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="ricecker"> Rice Cooker:</label>
                            <select class="form-control" id="rcecoker">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                            <span class="val text-danger" id="val-rcecoker"></span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12 control-box">
                            <input type="button" class="btn btn-primary" id="submit-h" value="Save" />
                            <input type="reset" class="btn btn-dark" id="clear-h" value="Clear" />
                        <div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loader -->
    <div class="modal" id="loader" tabindex="-1" role="dialog" aria-labelledby="lblLoader" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
                <div class="modal-body" style="text-align: center;">
                    <img src="./img/res/loader-img.gif" width="32" height="32">
                    <span style="margin-left: 10px;">Saving data...</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Error -->
    <div class="modal" id="error" tabindex="-1" role="dialog" aria-labelledby="lblError" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="color: #505050; font-size: 0.8rem;">
                <div class="modal-body" style="text-align: center;">
                    <img src="./img/res/error-trans.png" width="32" height="32">
                    <span style="margin-left: 10px;">Something went wrong while communicating with server...</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Location picker -->
    <div class="modal fade" id="locationPicker" tabindex="-1" role="dialog" aria-labelledby="locationPickerLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="locationPickerLabel">Location Picker</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div id="map"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCMrsWm_ka2vGqme0Uv5IDFYk0frGQ74OY&callback=initMap&libraries=&v=weekly" async differ></script>
    <script src="./js/property-management.js"></script>
    <script>
        var lati = $('#lati');
        var longi = $('#long');

        $(document).ready(() => {
            $('#setLoction').click(() => { $('#locationPicker').modal('show'); initMap(); })
        });

        function initMap(){
            const initial = { lat: 7.0415740944018115, lng: 79.939904131782 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 15,
                center: initial,
            });

            let tagWindow = new google.maps.InfoWindow({
                content: "Click on the map where you want to select",
                position: initial,
            });

            tagWindow.open(map);

            map.addListener('click', e => {
                tagWindow.close();

                tagWindow = new google.maps.InfoWindow({
                    position: e.latLng,
                });

                var loc = e.latLng.toJSON();
                tagWindow.setContent(JSON.stringify(loc, null, 2));
                tagWindow.open(map);

                lati.val(loc.lat.toFixed(5));
                longi.val(loc.lng.toFixed(5));

                $('#locationPicker').modal('hide');
            });
        }
    </script>
    <style>
        .select2-container{
            width: 100%!important;
        }
        .control-box{
            text-align: right;
        }
        .inform-btn {
            color: white!important;
        }
        #map{
            width: 100%;
            height: 400px;
            background-color: #ddd;
            border-radius: 8px;
        }
    </style>
