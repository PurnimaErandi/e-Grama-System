var divList;

$(document).ready(() => {
    fillDivs();

    $('#gov').click(() => {
        $('#govSec').toggle(this.checked);
    });

    $('#clear').click(() => {
        clearAll();
    });

    $('#print').click(() => {
        if(!isAllValidated()){
            $('.val').html('');
            $('#districtList').focus();
            alert(`Complete the form before print!`);
        }
        else{
            print();
        } 
    });

    $('#gnDiv').change(() => {
        validate_GN_Div();
    });

    $('#regDiv').keyup(() => {
        validate_RegDiv();
    });

    $('#deathDate').change(() => {
        validate_deathDate();
    });

    $('#place').change(() => {
        validate_deathPlace();
    });
    
    $('#nicno').change(() => {
        validate_nicno();
    });

    $('#fullname').keyup(() => {
        validate_fullname();
    });

    $('#gender').change(() => {
        validate_gender();
    });

    $('#nationality').keyup(() => {
        validate_nationality();
    });

    $('#age').change(() => {
        validate_age();
    });

    $('#profession').keyup(() => {
        validate_profRank();
    });

    $('#reason').keyup(() => {
        validate_causeDeath();
    });

    $('#nameinfo').keyup(() => {
        validate_nameInfo();
    });

    $('#addressinfo').keyup(() => {
        validate_addressInfo();
    });

    $('#submit').click(() => {
        if(isAllValidated()){
            var win = $('#confirm-window');
            win.modal('show');
        }
    });

    $('#save-form').click(() => {
        var l = $('#person-list');
        if(l.val() == null || l.val() == '')
            alert('Something went wrong!');
        else{
            var form = document.getElementById("death-form");
            var data = new FormData(form);
            data.append('requested_person_id', $('#person-list').val());
            
            $.ajax({
                type: 'post',
                url: './controls/admin/save_deathcertificate.php',
                processData: false,
                contentType: false,
                data: data,
                success: function(r){
                    alert(r);
                    //form.reset();
                },
                error: function(){
                    alert('Something went wrong!');
                },
                complete: function(){
                    l.prop("selectedIndex", 0).val();
                }
            });
        }
    })
});

function addValidation(validationIndicator, message){
    validationIndicator.html(message);
}

function removeValidation(validationIndicator){
    validationIndicator.html('');
}

function loadDivs(){
    divList = [
        "",
        "Mahawatta Grama Niladhari Division", 
        "Dandugama Grama Niladhari Division",
        "Dehiyagatha Grama Niladhari Division",
        "Dehiyagatha Grama Niladhari Division",
        "Kudahakapola Grama Niladhari Division",
        "Kudahakapola Grama Niladhari Division",
        "Gallawatta Grama Niladhari Division", 
        "Ekala Grama Niladhari Division",
        "Vishakawatta Grama Niladhari Division", 
        "Peralanda Grama Niladhari Division",
        "Thewatta Grama Niladhari Division",
        "Thudella North Grama Niladhari Division",
        "Thudella West Grama Niladhari Division",
        "Thudella South Grama Niladhari Division",
        "Yakkaduwa Grama Niladhari Division",
        "Thewatta Grama Niladhari Division",
        "Ketakewatta Grama Niladhari Division",
        "Thumpeliya Grama Niladhari Division",
        "Uswatta Grama Niladhari Division",
        "Batuwatta West Grama Niladhari Division",
        "Batuwatta East Grama Niladhari Division",
        "Narangodapaluwa West Grama Niladhari Division",
        "Narangodapaluwa East Grama Niladhari Division",
        "Walpola East Grama Niladhari Division",
        "Nagoda Grama Niladhari Division"
    ];
}

function fillDivs(){
    loadDivs();
    var divListSelect = $('#gnDiv');
    divListSelect.empty();
    $.each(divList, (i)=>{
        divListSelect.append(`<option value="${divList[i]}">${divList[i]}</option>`);
    });
    divListSelect.select2();
}

function clearAll(){
    $('input[type="text"]').val('');
    $('textarea').val('');
    $('input[type="date"]').val('');
    $('input[type="number"]').val('');
    $('.val').html('');
    $('#gov').prop('checked', false);
    $('#govSec').toggle(false);

    loadDivs();
}

/* field validation */

function validate_GN_Div(){
    if($('#gnDiv').val() === ''){
        addValidation($('#gnDivVal'), 'Grama Niladhari division is required');
        $('#gnDiv').focus();
        return false;
    }
    removeValidation($('#gnDivVal'));
    return true;
}

function validate_RegDiv(){
    if($('#regDiv').val() === ''){
        addValidation($('#regDivVal'), 'Registrar division is required');
        $('#regDiv').focus();
        return false;
    }
    removeValidation($('#regDivVal'));
    return true;
}

function validate_deathDate(){
    if($('#deathDate').val() === ''){
        addValidation($('#deathDateVal'), 'Date of death is required');
        $('#deathDate').focus();
        return false;
    }

    var death = Date.parse($('#deathDate').val());
    var today = Date.parse(new Date());
    if(death > today){
        addValidation($('#deathDateVal'), 'Date of death cannot be a future date');
        $('#deathDate').focus();
        return false;
    }
    removeValidation($('#deathDateVal'));
    return true;
}

function validate_deathPlace(){
    if($('#place').val() === ''){
        addValidation($('#placeVal'), 'Place of death is required');
        $('#place').focus();
        return false;
    }
    removeValidation($('#placeVal'));
    return true;
}
function validate_nicno(){
    // if($('#nicno').val() == ''){
    //     addValidation($('#nicnoVal'), 'NIC number is required');
    //     $($('#nicno')).focus();
    //     return false;
    // }
    var len = $('#nicno').val().length
    if(!(len == 10 || len == 12)){
        addValidation($('#nicnoVal'), 'Invalid NIC');
        $($('#nicno')).focus();
        return false;
    }
    var regex = len == 10 ? /[1-9]{1}[0-9]{8}[vVxX]{1}/
        : len == 12 ? /[1-9]{1}[0-9]{11}/ : '';
    if(!regex.test($('#nicno').val())){
        addValidation($('#nicnoVal'), 'Incorrect NIC format');
        $($('#nicno')).focus();
        return false;
    }
    removeValidation($('#nicnoVal'));
    return true;
}

function validate_fullname(){
    if($('#fullname').val() === ''){
        addValidation($('#fullnameVal'), 'Full name is required');
        $('#fullname').focus();
        return false;
    }
    removeValidation($('#fullnameVal'));
    return true;
}

function validate_gender(){
    if($('#gender').val() === ''){
        addValidation($('#genderVal'), 'Gender is required');
        $('#gender').focus();
        return false;
    }
    removeValidation($('#genderVal'));
    return true;
}

function validate_nationality(){
    if($('#nationality').val() === ''){
        addValidation($('#nationalityVal'), 'Nationality is required');
        $('#nationality').focus();
        return false;
    }
    removeValidation($('#nationalityVal'));
    return true;
}

function validate_age(){
    if($('#age').val() === ''){
        addValidation($('#ageVal'), 'Age is required');
        $($('#age')).focus();
        return false;
    }

    var age = parseInt($('#age').val());
    if(age <= 0){
        addValidation($('#ageVal'), 'Invalid age');
        $($('#age')).focus();
        return false;
    }
    removeValidation($('#ageVal'));
    return true;
}

function validate_profRank(){
    if($('#profession').val() === ''){
        addValidation($('#professionVal'), 'Profession is required');
        $('#profession').focus();
        return false;
    }
    removeValidation($('#professionVal'));
    return true;
}

function validate_causeDeath(){
    if($('#reason').val() === ''){
        addValidation($('#reasonVal'), 'Cause of death is required');
        $('#reason').focus();
        return false;
    }
    removeValidation($('#reasonVal'));
    return true;
}

function validate_nameInfo(){
    if($('#nameinfo').val() === ''){
        addValidation($('#nameinfoVal'), 'Name information is required');
        $('#nameinfo').focus();
        return false;
    }
    removeValidation($('#nameinfoVal'));
    return true;
}

function validate_addressInfo(){
    if($('#addressinfo').val() === ''){
        addValidation($('#addressinfoVal'), 'Address information is required');
        $('#addressinfo').focus();
        return false;
    }
    removeValidation($('#addressinfoVal'));
    return true;
}

function isAllValidated(){
    return validate_GN_Div() & validate_RegDiv() & validate_deathDate() & validate_deathPlace()
    & validate_fullname() & validate_gender() & validate_nationality() & validate_age() 
    & validate_profRank() & validate_causeDeath() & validate_nameInfo() & validate_addressInfo();
}


