var onEdit, currentId;


$(document).ready(() => {
    loadSampleData();

    $('#add-disaster').click(() => { openAidWindow(); } )

    $('#submit').click(() => { submit(); })

    /* Validation events */
    $('#date').on('keyup change', () => { validateDate() })
    $('#remark').on('keyup change', () => { validateRemark() })
    $('#locLt').on('keyup change', () => { validateLocation() })
    $('#locLg').on('keyup change', () => { validateLocation() })
    $('#disaster').on('keyup change', () => { validateType() })
    $('#damages').on('keyup change', () => { validateDamg() })

    $('#setLoc').click(() => { $('#locationPicker').modal('show'); initMap(); });
});

function openAidWindow(){
    onEdit = false;
    clearAll();
    var win = $('#add-disaster-window');
    win.modal('show');
}

function loadSampleData(){
    var d;
    $.ajax({
        type: 'post',
        url: './controls/admin/get_disaster.php',
        processData: false,
        contentType: false,
        async: false,
        success: function(r){
            d = JSON.parse(r);
        },
        error: function(){
            system_alert("Something went wrong!");
        },
        complete: function(){
            $.each(d, i => {
                var y = {
                        position: {
                            lat: d[i].Latitude, 
                            lng: d[i].Longitude
                        },
                        tag: d[i].Remark
                    };
                locs.push(y);
            });
            loadPageContent(d);
        }
    });
}

function deleteDisaster(id){
    var data = new FormData();
    data.append('dataId', id);
    $.ajax({
        type: 'post',
        url: './controls/admin/delete_disasterData.php',
        processData: false,
        contentType: false,
        data: data,
        success: function(r){
            system_alert(r);
        },
        error: function(){
            system_alert("Something went wrong!");
        },
        complete: function(){
            clearAll();
            onEdit = false;
            currentId = -1;
        }
    });
}

function editDisaster(id){
    onEdit = true;
    var d;
    currentId = id;
    var data = new FormData();
    data.append('dataId', id);
    $.ajax({
        type: 'post',
        url: './controls/admin/get_disasterData.php',
        processData: false,
        contentType: false,
        data: data,
        success: function(r){
            d = JSON.parse(r)
        },
        error: function(){
            system_alert("Something went wrong!");
        },
        complete: function(){
            clearAll();
            $('#date').val(d.Date);
            $('#remark').val(d.Remark);
            $('#locLt').val(d.Latitude);
            $('#locLg').val(d.Longitude);
            $('#disaster').val(d.DisasterType);
            $('#damages').val(d.Damages);
            $('#other').val(d.Other);
            $('#add-disaster-window').modal('show');
        }
    });
}

function loadPageContent(x){
    var t = $('.disaster-table');
    t.empty();
    $.each(x, i => { 
        var row =
        `<tr>
            <td>
                <button class="btn btn-sm btn-danger" title="Delete" onclick="deleteDisaster(${x[i].Id})">
                    <i class="fa fa-trash"></i>
                </button>
                <button class="btn btn-sm btn-primary" title="Edit" onclick="editDisaster(${x[i].Id})">
                    <i class="fa fa-pencil-alt"></i>
                </button>
            </td>
            <td>${x[i].Date}</td>
            <td>${x[i].Remark}</td>
            <td>${x[i].DisasterType}</td>
            <td>${x[i].Damages}</td>
            <td>${x[i].Other}</td>
        </tr>`;
        t.append(row);
    });
}

function submit(){
    if(onEdit){
        if(isValid()){
            var form = document.getElementById("disaster-form");
            var data = new FormData(form);
            data.append('dataId', currentId);
            
            $.ajax({
                type: 'post',
                url: './controls/admin/update_disasterData.php',
                processData: false,
                contentType: false,
                data: data,
                success: function(r){
                    system_alert(r);
                },
                error: function(){
                    system_alert("Something went wrong!");
                },
                complete: function(){
                    clearAll();
                    $('#add-disaster-window').modal('hide');
                }
            });
        }
        else{
            $('.in-err').filter(':first').focus();
        }
    }
    else{
        if(isValid()){
            var form = document.getElementById("disaster-form");
            var data = new FormData(form);
            
            $.ajax({
                type: 'post',
                url: './controls/admin/save_disasterDetails.php',
                processData: false,
                contentType: false,
                data: data,
                success: function(r){
                    system_alert(r);
                },
                error: function(){
                    system_alert("Something went wrong!");
                },
                complete: function(){
                    clearAll();
                    $('#add-disaster-window').modal('hide');
                }
            });
        }
        else{
            $('.in-err').filter(':first').focus();
        }  
    }

}

function clearAll(){
    $('input[type="text"]').val('');
    $('input[type="date"]').val('');
    $('textarea').val('');
}

var locs = new Array();
function initMap() {
    const myLatlng = { lat: 7.0415740944018115, lng: 79.939904131782 };
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: myLatlng
    });

    const mainMap = new google.maps.Map(document.getElementById("mainMap"), {
        zoom: 12,
        center: myLatlng
    });

    if(locs.length > 0){
        $.each(locs, i => {
            var x = new google.maps.Marker({
                position: locs[i].position,
                title: locs[i].tag
            });
            x.setMap(mainMap);
        });
    }

    let infoWindow = new google.maps.InfoWindow({
        content: "Click on the map where you want select",
        position: myLatlng
    });
    
    infoWindow.open(map);
    
    map.addListener("click", (mapsMouseEvent) => {
        infoWindow.close();
        
        infoWindow = new google.maps.InfoWindow({
            position: mapsMouseEvent.latLng
        });
        
        var loc = mapsMouseEvent.latLng.toJSON();
        infoWindow.setContent(JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2));
        infoWindow.open(map);

        var latid = $('#locLt');
        var longd = $('#locLg');

        latid.val(loc.lat.toFixed(16));
        longd.val(loc.lng.toFixed(16));
        $('#locationPicker').modal('hide');
        locations.push(
            {
                position: {lat: loc.lat, lng: loc.lng},
                tag: 'My Location'
            }
        );
        initMap();
    });
}

/* validation helpers */
function addValidation(valElem, msg){
    valElem.html(msg);
}

function removeValidation(valElem){
    valElem.html('');
}

function isValid(){
    return validateDate() & validateRemark() & validateLocation()
    & validateType() & validateDamg();
}

/* Validations */
function validateDate(){
    var i = $('#date');
    var v = $('#dateVal');

    if(i.val() == ''){
        addValidation(v, 'Date is required');
        return false;
    }

    var today = new Date();
    var d = new Date(i.val());
    if(d > today){
        addValidation(v, 'Date cannot be in future');
        return false;
    }

    removeValidation(v);
    return true;
}

function validateRemark(){
    var i = $('#remark');
    var v = $('#remarkVal');

    if(i.val() == ''){
        addValidation(v, 'Remark is required');
        return false;
    }

    removeValidation(v);
    return true;
}

function validateLocation(){
    var i = $('#locLt');
    var j = $('#locLg');
    var v = $('#locVal');

    if(i.val() == '' || j.val() == ''){
        addValidation(v, 'Location is required');
        return false;
    }

    removeValidation(v);
    return true;
}

function validateType(){
    var i = $('#disaster');
    var v = $('#disasterVal');

    if(i.val() == ''){
        addValidation(v, 'Disaster type is required');
        return false;
    }

    removeValidation(v);
    return true;
}

function validateDamg(){
    var i = $('#damages');
    var v = $('#damagesVal');

    if(i.val() == ''){
        addValidation(v, 'Damages info is required');
        return false;
    }

    removeValidation(v);
    return true;
}

