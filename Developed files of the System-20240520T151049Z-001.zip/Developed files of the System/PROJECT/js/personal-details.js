var cnt = 0, editId = null;
var aidList = new Array();

$(document).ready(function () {
    $('#add-aid').click(() => { openAddAidWindow(); });

    $('#add').click(() => { addAid(); });

    $('#edit-save').click(() => { editAid(); })

    $('.del').click((e) => {
        $(e.target).parent('.info').remove();
    });

    var isChild = document.getElementById('isChild');
    $('#isChild').change(() => {
        if(isChild.checked){
            $('[data-hide-on-child="true"]').addClass('hide');
            $('[data-hide-on-child="false"]').removeClass('hide');
        }
        else{
            $('[data-hide-on-child="false"]').addClass('hide');
            $('[data-hide-on-child="true"]').removeClass('hide');
        }
    })
    
    clearForm();
    
    /* Add aid validation events */
    $('#typeOfAid').change(() => {
        validateAidType();
    });

    $('#accNo').keyup(() => {
        validateAccNo();
    });

    $('#donatNo').keyup(() => {
        validateDonatNo();
    });

    $('#donatAmnt').on('keyup change', () => {
        validateAmount();
    });

    $('#place').keyup(() => {
        validatePlace();
    });

    $('#otherDet').keyup(() => {
        validateDetails();
    });


    /* Edit aid validation events */
    $('#e-typeOfAid').change(() => {
        validateAidTypeE();
    });

    $('#e-accNo').keyup(() => {
        validateAccNoE();
    });

    $('#e-donatNo').keyup(() => {
        validateDonatNoE();
    });

    $('#e-donatAmnt').on('keyup change', () => {
        validateAmountE();
    });

    $('#e-place').keyup(() => {
        validatePlaceE();
    });

    $('#e-otherDet').keyup(() => {
        validateDetailsE();
    });

    $('#edit-aid-window').on('hidden.bs.modal', (e) => {
        editId = null;
    });

    /* Form validation events */
    $('#nmeofprsn').keyup(() => {
        validateName();
    });

    $('#hseno').keyup(() => {
        validateHouse();
    });

    $('#status').change(() => {
        validateStatus();
    });

    $('#gender').change(() => {
        validateGender();
    });

    $('#dateofbirth').change(() => {
        validateDoB();
    });

    $('#brthplce').keyup(() => {
        validateBirthPlace();
    });

    $('#idno').keyup(() => {
        validateNic();
    });

    $('#telno').keyup(() => {
        validateTel();
    });
    
    $('#email').keyup(() => {
        validateEmail();
    });
    
    $('#religions').change(() => {
        validateRel();
    });

    $('#nationality').change(() => {
        validateNation();
    });

    $('#education').change(() => {
        validateEdu();
    });

    $('#occupation').change(() => {
        validateOccu();
    });
    $('#physcalhlth').change(() => {
        validatePhy();
    });
    $('#vehcls').change(() => {
        validateVehi();
    });

    $('#langknwlge').change(() => {
        validateLang();
    });

    $('#itknwlege').change(() => {
        validateIT();
    });

    $('#otherskls').keyup(() => {
        validateOther();
    });

    $('#guardian').change(() => {
        validateGuard();
    });

    /* Submit form */
    $('#submit').click(() => {
        submit();
    });

    $('#clear').click(() => {
        clearForm();
    });

    $('#error').on('shown.bs.modal', () => {
        $('#loader').modal('hide');
    });
});

function addAid(){
    if(isValidate()){
        cnt += 1;
        var type = $('#typeOfAid').val();
        var acc = $('#accNo').val();
        var donateNo = $('#donatNo').val();
        var amount = $('#donatAmnt').val();
        var place = $('#place').val();
        var details = $('#otherDet').val();

        aidList.push({
            "id": cnt,
            "type": type,
            "account": acc,
            "donationNo": donateNo,
            "amount": amount,
            "place": place,
            "details": details
        });

        var item = `
        <div class="row info" id="_i${cnt}">
            <div class="col-md-1">
                <span title="Edit aid info" class="rec-btn edt" id="_e${cnt}" onclick="openEditAidWindow(${cnt})"><i class="fa fa-edit"></i></span>
                <span title="Delete aid info" class="rec-btn del" id="_d${cnt}" onclick="removeAid(${cnt})"><i class="fa fa-trash"></i></span>
            </div>
            <div class="col-md-2" id="_t${cnt}">${type}</div>
            <div class="col-md-1" id="_n${cnt}">${donateNo}</div>
            <div class="col-md-2" id="_a${cnt}">${acc}</div>
            <div class="col-md-2" id="_m${cnt}">${parseFloat(amount).toFixed(2)}</div>
            <div class="col-md-2" id="_p${cnt}">${place}</div>
            <div class="col-md-2" id="_l${cnt}">${details}</div>
        </div>`;
        $('.item-container').append(item);
        $('#add-aid-window').modal('hide');
    }
    else{
        $('.modal .in-err').filter(':first').focus();
    }
    
}

function editAid(){
    if(isValidateE()){
        var type = $('#e-typeOfAid').val();
        var acc = $('#e-accNo').val();
        var donateNo = $('#e-donatNo').val();
        var amount = $('#e-donatAmnt').val();
        var place = $('#e-place').val();
        var details = $('#e-otherDet').val();

        var index = aidList.findIndex(a => a.id == editId);
        aidList[index].type = type;
        aidList[index].account = acc;
        aidList[index].donationNo = donateNo;
        aidList[index].amount = amount;
        aidList[index].place = place;
        aidList[index].details = details;

        $(`#_t${editId}`).html(type);
        $(`#_a${editId}`).html(acc);
        $(`#_n${editId}`).html(donateNo);
        $(`#_m${editId}`).html(parseFloat(amount).toFixed(2));
        $(`#_p${editId}`).html(place);
        $(`#_l${editId}`).html(details);
        $('#edit-aid-window').modal('hide');
    }
    else{
        $('.in-err').filter(':first').focus();
    }
}

function removeAid(id){
    $(`#_i${id}`).remove();
    var index = aidList.findIndex(a => a.id == id);
    aidList.splice(index, 1);
}

function openAddAidWindow(){
    clearValidations();
    $('#add-aid-window input[type="text"]').val('');
    $('#add-aid-window input[type="number"]').val('0.00');
    $('#otherDet').val('');
    $('#typeOfAid').val("Civil");
    var a = $('#add-aid-window');
    a.modal('show');
}

function openEditAidWindow(id){
    clearValidations();
    $('#edit-aid-window input[type="text"]').val('');
    $('#edit-aid-window input[type="number"]').val('0.00');
    $('#e-otherDet').val('');
    $('#e-typeOfAid').val("Civil");

    var index = aidList.findIndex(a => a.id == id);
    $('#e-typeOfAid').val(aidList[index].type);
    $('#e-accNo').val(aidList[index].account);
    $('#e-donatNo').val(aidList[index].donationNo);
    $('#e-donatAmnt').val(aidList[index].amount);
    $('#e-place').val(aidList[index].place);
    $('#e-otherDet').val(aidList[index].details);

    var a = $('#edit-aid-window');
    editId = id;
    a.modal('show');
}

function submit(){
    if(isValidateF()){
        var data = new FormData();
        data.append('persname', $('#nmeofprsn').val());
        data.append('houseno', $('#hseno').val());
        data.append('stts', $('#status').val());
        data.append('gndr', $('#gender').val());
        data.append('dob', $('#dateofbirth').val());
        data.append('birthplace', $('#brthplce').val());
        data.append('nic', $('#idno').val());
        data.append('telno', $('#telno').val());
        data.append('email', $('#email').val());
        data.append('relgns', $('#religions').val());
        data.append('natnalty', $('#nationality').val());
        data.append('edctn', $('#education').val());
        data.append('occptn', $('#occupation').val());
        data.append('langknlg', JSON.stringify($('#langknwlge').val()));
        data.append('itknlg', JSON.stringify($('#itknwlege').val()));
        data.append('physcal', JSON.stringify($('#physcalhlth').val()));
        data.append('vehicls', JSON.stringify($('#vehcls').val()));
        data.append('otherskills', $('#otherskls').val());
        data.append('aidlist', JSON.stringify(aidList));
        data.append('isAlive', $('#isAlive').val());
        data.append('isChild', document.getElementById('isChild').checked ? 1 : 0);
        data.append('guardian', $('#guardian').val());

      
        $.ajax({
            type: 'POST',
            url: './controls/admin/save_personalDetails.php', // send this to your action url
            data: data,
            caches: false,
            async: true,
            processData: false,
            contentType: false,
            beforeSend: function(){
                $('#loader').modal('show');
            },
            success: function(data){
                $('#loader').modal('hide');
                clearForm();
                if (data == 1) {
                    clearForm();
                    system_alert("Saved success");
                } else {
                    system_alert(data);
                    changePath("./content/admin/personalDetails.php");
                }
            },
            error: function(){
                $('#error').modal('show');
            }
        });
    }
    else{
        $('.in-err').filter(':first').focus();
    }
}

function clearForm(){
    $('input[type="text"]').val('');
    $('input[type="date"]').val('');
    $("select").prop("selectedIndex", 0).val();
    $("#isAlive").prop("selectedIndex", 1).val();
    $('textarea').val('');
    $('.info').remove();
    $('.selectpicker').selectpicker('deselectAll');
    $('.selectpicker').selectpicker('refresh');
    $('.val').html('');
    $('.form-control').removeClass('in-err');
    cnt = 0;
    aidList = [];
}

/* ===================================================================== */
function addValidation(valIn, validationIndicator, message){
    validationIndicator.html(message);
    valIn.addClass('in-err');
}

function removeValidation(valIn, validationIndicator){
    validationIndicator.html('');
    valIn.removeClass('in-err');
}

function isValidate(){
    return validateAidType() & validateAccNo() & validateDonatNo() & validateAmount()
        & validatePlace() & validateDetails()
}

function isValidateE(){
    return validateAidTypeE() & validateAccNoE() & validateDonatNoE() & validateAmountE()
        & validatePlaceE() & validateDetailsE()
}

function isValidateF(){
    return validateName() & validateHouse() & validateStatus() & validateGender() &
    validateDoB() & validateBirthPlace() & validateNic() & validateTel() & validateEmail() &
    validateRel() & validateNation() & validateEdu() & validateOccu() &
    validatePhy() & validateVehi() & validateLang() & validateIT() & validateOther() & validateGuard();
}

function clearValidations(){
    removeValidation($('#typeOfAid'), $('#typeOfAidVal'));
    removeValidation($('#e-typeOfAid'), $('#e-typeOfAidVal'));
    removeValidation($('#accNo'), $('#accNoVal'));
    removeValidation($('#e-accNo'), $('#e-accNoVal'));
    removeValidation($('#donatNo'), $('#donatNoVal'));
    removeValidation($('#e-donatNo'), $('#e-donatNoVal'));
    removeValidation($('#donatAmnt'), $('#donatAmntVal'));
    removeValidation($('#e-donatAmnt'), $('#e-donatAmntVal'));
    removeValidation($('#place'), $('#placeVal'));
    removeValidation($('#e-place'), $('#e-placeVal'));
    removeValidation($('#otherDet'), $('#otherDetVal'));
    removeValidation($('#e-otherDet'), $('#e-otherDetVal'));
}

/* =============== Validation functions (Add aid window) =============== */
function validateAidType(){
    if($('#typeOfAid').val() == ''){
        addValidation($('#typeOfAid'), $('#typeOfAidVal'), 'Type of aid is required');
        $('#typeOfAid').focus();
        return false;
    }
    removeValidation($('#typeOfAid'), $('#typeOfAidVal'));
    return true;
}

function validateAccNo(){
    if($('#accNo').val() == ''){
        addValidation($('#accNo'), $('#accNoVal'), 'Account number is required');
        $('#accNo').focus();
        return false;
    }
    removeValidation($('#accNo'), $('#accNoVal'));
    return true;
}

function validateDonatNo(){
    if($('#donatNo').val() == ''){
        addValidation($('#donatNo'), $('#donatNoVal'), 'Donation number is required');
        $('#donatNo').focus();
        return false;
    }
    removeValidation($('#donatNo'), $('#donatNoVal'));
    return true;
}

function validateAmount(){
    if($('#donatAmnt').val() == ''){
        addValidation($('#donatAmnt'), $('#donatAmntVal'), 'Donation amount is required');
        $('#donatAmnt').focus();
        return false;
    }

    if($('#donatAmnt').val() < 0 || $('#donatAmnt').val() == 0){
        addValidation($('#donatAmnt'), $('#donatAmntVal'), 'Invalid donation amount');
        $('#donatAmnt').focus();
        return false;
    }
    removeValidation($('#donatAmnt'), $('#donatAmntVal'));
    return true;
}

function validatePlace(){
    if($('#place').val() == ''){
        addValidation($('#place'), $('#placeVal'), 'Obtaining place is required');
        $('#place').focus();
        return false;
    }
    removeValidation($('#place'), $('#placeVal'));
    return true;
}

function validateDetails(){
    if($('#otherDet').val() == ''){
        addValidation($('#otherDet'), $('#otherDetVal'), 'Other details is required');
        $('#otherDet').focus();
        return false;
    }
    removeValidation($('#otherDet'), $('#otherDetVal'));
    return true;
}

/* =============== Validation functions (Edit aid window) =============== */
function validateAidTypeE(){
    if($('#e-typeOfAid').val() == ''){
        addValidation($('#e-typeOfAid'), $('#e-typeOfAidVal'), 'Type of aid is required');
        $('#e-typeOfAid').focus();
        return false;
    }
    removeValidation($('#e-typeOfAid'), $('#e-typeOfAidVal'));
    return true;
}

function validateAccNoE(){
    if($('#e-accNo').val() == ''){
        addValidation($('#e-accNo'), $('#e-accNoVal'), 'Account number is required');
        $('#e-accNo').focus();
        return false;
    }
    removeValidation($('#e-accNo'), $('#e-accNoVal'));
    return true;
}

function validateDonatNoE(){
    if($('#e-donatNo').val() == ''){
        addValidation($('#e-donatNo'), $('#e-donatNoVal'), 'Donation number is required');
        $('#e-donatNo').focus();
        return false;
    }
    removeValidation($('#e-donatNo'), $('#e-donatNoVal'));
    return true;
}

function validateAmountE(){
    if($('#e-donatAmnt').val() == ''){
        addValidation($('#e-donatAmnt'), $('#e-donatAmntVal'), 'Donation amount is required');
        $('#e-donatAmnt').focus();
        return false;
    }

    if($('#e-donatAmnt').val() < 0 || $('#e-donatAmnt').val() == 0){
        addValidation($('#e-donatAmnt'), $('#e-donatAmntVal'), 'Invalid donation amount');
        $('#e-donatAmnt').focus();
        return false;
    }
    removeValidation($('#e-donatAmnt'), $('#e-donatAmntVal'));
    return true;
}

function validatePlaceE(){
    if($('#e-place').val() == ''){
        addValidation($('#e-place'), $('#e-placeVal'), 'Obtaining place is required');
        $('#e-place').focus();
        return false;
    }
    removeValidation($('#e-place'), $('#e-placeVal'));
    return true;
}

function validateDetailsE(){
    if($('#e-otherDet').val() == ''){
        addValidation($('#e-otherDet'), $('#e-otherDetVal'), 'Other details is required');
        $('#e-otherDet').focus();
        return false;
    }
    removeValidation($('#e-otherDet'), $('#e-otherDetVal'));
    return true;
}

/* =============== Validation functions (form) =============== */
function validateName(){
    if($('#nmeofprsn').val() == ''){
        addValidation($('#nmeofprsn'), $('#nmeofprsnVal'), 'Name of the person is required');
        $('#nmeofprsn').focus();
        return false;
    }
    removeValidation($('#nmeofprsn'), $('#nmeofprsnVal'));
    return true;
}

function validateHouse(){
    if($('#hseno').val() == ''){
        addValidation($('#hseno'), $('#hsenoVal'), 'House No. is required');
        $('#hseno').focus();
        return false;
    }
    removeValidation($('#hseno'), $('#hsenoVal'));
    return true;
}

function validateStatus(){
    if($('#status').val() == ''){
        addValidation($('#status'), $('#statusVal'), 'Status is required');
        $('#status').focus();
        return false;
    }
    removeValidation($('#status'), $('#statusVal'));
    return true;
}

function validateGender(){
    if($('#gender').val() == ''){
        addValidation($('#gender'), $('#genderVal'), 'Gender is required');
        $('#gender').focus();
        return false;
    }
    removeValidation($('#gender'), $('#genderVal'));
    return true;
}

function validateDoB(){
    if($('#dateofbirth').val() == ''){
        addValidation($('#dateofbirth'), $('#dateofbirthVal'), 'Date of birth is required');
        $('#dateofbirth').focus();
        return false;
    }
    var dob = $('#dateofbirth').val();
    var d = new Date(dob);
    if(d > new Date()){
        addValidation($('#dateofbirth'), $('#dateofbirthVal'), 'Date of birth cannot be in future');
        $('#dateofbirth').focus();
        return false;
    }
    removeValidation($('#dateofbirth'), $('#dateofbirthVal'));
    return true;
}

function validateBirthPlace(){
    if($('#brthplce').val() == ''){
        addValidation($('#brthplce'), $('#brthplceVal'), 'Birth place is required');
        $('#brthplce').focus();
        return false;
    }
    removeValidation($('#brthplce'), $('#brthplceVal'));
    return true;
}

function validateNic(){
    if(isChild.checked){
        removeValidation($('#idno'), $('#idnoVal'));
        return true;
    }

    if($('#idno').val() == ''){
        addValidation($('#idno'), $('#idnoVal'), 'NIC number is required');
        $('#idno').focus();
        return false;
    }
    var len = $('#idno').val().length
    if(!(len == 10 || len == 12)){
        addValidation($('#idno'), $('#idnoVal'), 'Invalid NIC number');
        $($('#idno')).focus();
        return false;
    }
    var regex = len == 10 ? /[1-9]{1}[0-9]{8}[vVxX]{1}/
        : len == 12 ? /[1-9]{1}[0-9]{11}/ : '';
    if(!regex.test($('#idno').val())){
        addValidation($('#idno'), $('#idnoVal'), 'Incorrect NIC number format');
        $($('#idno')).focus();
        return false;
    }
    removeValidation($('#idno'), $('#idnoVal'));
    return true;
}

function validateTel(){
    if(isChild.checked){
        removeValidation($('#telno'), $('#telnoVal'));
        return true;
    }

    if($('#telno').val() == ''){
        addValidation($('#telno'), $('#telnoVal'), 'Tel no is required');
        $('#telno').focus();
        return false;
    }
    var len = $('#telno').val().length
    if(!(len == 10)){
        addValidation($('#telno'), $('#telnoVal'), 'Invalid telphone number');
        $($('#telno')).focus();
        return false;
    }
    removeValidation($('#telno'), $('#telnoVal'));
    return true;
}
function validateEmail(){
    if(isChild.checked){
        removeValidation($('#email'), $('#emailVal'));
        return true;
    }

    if($('#email').val() == ''){
        addValidation($('#email'), $('#emailVal'), 'Email is required');
        $('#email').focus();
        return false;
    }
    var rx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(!rx.test($('#email').val())){
        addValidation($('#email'), $('#emailVal'), 'Invalid email address');
        $('#email').focus();
        return false;
    }
    removeValidation($('#email'), $('#emailVal'));
    return true;
}

function validateRel(){
    if($('#religions').val() == ''){
        addValidation($('#religions'), $('#religionsVal'), 'Religion is required');
        $('#religions').focus();
        return false;
    }
    removeValidation($('#religions'), $('#religionsVal'));
    return true;
}

function validateNation(){
    if($('#nationality').val() == ''){
        addValidation($('#nationality'), $('#nationalityVal'), 'Nationality is required');
        $('#nationality').focus();
        return false;
    }
    removeValidation($('#nationality'), $('#nationalityVal'));
    return true;
}

function validateEdu(){
    if($('#education').val() == ''){
        addValidation($('#education'), $('#educationVal'), 'Education info is required');
        $('#education').focus();
        return false;
    }
    removeValidation($('#education'), $('#educationVal'));
    return true;
}

function validateOccu(){
    if($('#occupation').val() == ''){
        addValidation($('#occupation'), $('#occupationVal'), 'Occupation info is required');
        $('#occupation').focus();
        return false;
    }
    removeValidation($('#occupation'), $('#occupationVal'));
    return true;
}

function validatePhy(){
    if($('#physcalhlth').val() == ''){
        addValidation($('#physcalhlth'), $('#physcalhlthVal'), 'Physical and mental situation is required');
        $('#physcalhlth').focus();
        return false;
    }
    removeValidation($('#physcalhlth'), $('#physcalhlthVal'));
    return true;
}

function validateVehi(){
    if($('#vehcls').val() == ''){
        addValidation($('#vehcls'), $('#vehclsVal'), 'Vehicle information are required');
        $('#vehcls').focus();
        return false;
    }
    removeValidation($('#vehcls'), $('#vehclsVal'));
    return true;
}

function validateLang(){
    if($('#langknwlge').val() == ''){
        addValidation($('#langknwlge'), $('#langknwlgeVal'), 'Language knowledge info is required');
        $('#langknwlge').focus();
        return false;
    }
    removeValidation($('#langknwlge'), $('#langknwlgeVal'));
    return true;
}

function validateIT(){
    if($('#itknwlege').val() == ''){
        addValidation($('#itknwlege'), $('#itknwlegeVal'), 'IT knowledge info is required');
        $('#itknwlege').focus();
        return false;
    }
    removeValidation($('#itknwlege'), $('#itknwlegeVal'));
    return true;
}

function validateOther(){
    if($('#otherskls').val() == ''){
        addValidation($('#otherskls'), $('#othersklsVal'), 'Other skills info is required');
        $('#otherskls').focus();
        return false;
    }
    removeValidation($('#otherskls'), $('#othersklsVal'));
    return true;
}

function validateGuard(){
    if(isChild.checked){
        if($('#guardian').val() == null || $('#guardian').val() == ''){
            addValidation($('#guardian'), $('#guardianVal'), 'Child\'s guardian is required');
            $('#guardian').focus();
            return false;
        }

        removeValidation($('#guardian'), $('#guardianVal'));
        return true;
    }
    else{
        removeValidation($('#guardian'), $('#guardianVal'));
        return true;
    }
}