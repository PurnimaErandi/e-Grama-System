var ds = ['', 'Colombo', 'Gampaha', 'Kalutara'];
var divsList = [
    {
        "District": "",
        "Divisions": [""]
    },
    {
        "District": "Colombo",
        "Divisions": ["Colombo Divisional Secretariat", "Dehiwala Divisional Secretariat", "Homagama Divisional Secretariat", "kaduwela Divisional Secretariat", "Kesbewa Divisional Secretariat", "Kolonnawa Divisional Secretariat", "Kotte Divisional Secretariat", "Maharagama Divisional Secretariat", "Moratuwa Divisional Secretariat", "Padukka Divisional Secretariat", "Ratmalana Divisional Secretariat", "Seethawaka Divisional Secretariat", "Thimbirigasyaya Divisional Secretariat"]
    },
    {
        "District": "Gampaha",
        "Divisions": ["Attanagalla Divisional Secretariat", "Biyagama Divisional Secretariat", "Divulapitiya Divisional Secretariat", "Dompe Divisional Secretariat", "Gampaha Divisional Secretariat", "Ja-Ela Divisional Secretariat", "Katana Divisional Secretariat", "Kelaniya Divisional Secretariat", "Mahara Divisional Secretariat", "Minuwangoda Divisional Secretariat", "Mirigama Divisional Secretariat" , "Negombo Divisional Secretariat", "Wattala Divisional Secretariat"]
    },
    {
        "District": "Kalutara",
        "Divisions": ["Agalawatta Divisional Secretariat", "Bandaragama Divisional Secretariat", "Beruwala Divisional Secretariat", "Bulathsinhala Divisional Secretariat", "Bulathsinhala Divisional Secretariat", "Dodangoda Divisional Secretariat", "Horana Divisional Secretariat", "Ingiriya Divisional Secretariat", "Kalutara Divisional Secretariat", "Madurawela Divisional Secretariat","Mathugama Divisional Secretariat", "Millaniya Divisional Secretariat", "Palindanuwara Divisional Secretariat", "Panadura Divisional Secretariat", "Walallavita Divisional Secretariat"]
    }
];

function addValidation(validationIndicator, message){
    validationIndicator.html(message);
}

function removeValidation(validationIndicator){
    validationIndicator.html('');
}

function kwonnApplicantStatusByGN(){
    if($('#gnKnown').val() == "0"){
        $('#sinceDate').prop("disabled", true);
    }
    else{
        $('#sinceDate').prop("disabled", false);
    }
}

function loadDistrictsAndDivs(){
    var dsElem = $('#districtList');
    var divElem = $('#divSecList');
    dsElem.empty();
    divElem.empty();
    $.each(ds, (i) => {
        dsElem.append(
            `<option value="${ds[i]}">${ds[i]}</option>`
        );
    });
    var selectedDis = $('#districtList').val();
    var divs = divsList.filter((ds) => {
        return ds.District == selectedDis;
    });

    $.each(divs[0].Divisions, (i) => {
        divElem.append(
            `<option id=${divs[0].Divisions[i]}>${divs[0].Divisions[i]}</option>`
        );
    });
}

function loadDivs(district){
    var divElem = $('#divSecList');
    divElem.empty();
    var divs = divsList.filter((ds) => {
        return ds.District == district;
    });

    $.each(divs[0].Divisions, (i) => {
        divElem.append(
            `<option id=${divs[0].Divisions[i]}>${divs[0].Divisions[i]}</option>`
        );
    });
}

function clearAll(){
    $('input[type="text"]').val('');
    $('textarea').val('');
    $('input[type="date"]').val('');
    $('input[type="number"]').val('');
    $('input[type="file"]').val('');
    $('#sigLbl').html('Select file...');
    $('.val').html('');

    loadDistrictsAndDivs();
}

$(document).ready(() => {
    loadDistrictsAndDivs();
    kwonnApplicantStatusByGN();

    $('#print').click(() => {
        if(!isAllValidated()){
            $('.val').html('');
            $('#districtList').focus();
            alert(`Complete the form before print!`);
        }
        else{
            print();
        }
        
    });

    $('#clear').click(() => {
        clearAll();
    });

    $('#districtList').change(() => {
        loadDivs($('#districtList').val());
    });

    $('#divNum').keyup(function() {
        validate_1_c();
    });

    $('#name').keyup(function() {
        validate_2_a();
    });

    $('#address').keyup(function() {
        validate_2_b();
    });

    $('#age').change(function() {
        validate_2_c();
    });

    $('#isSL').keyup(function() {
        validate_2_e();
    });

    $('#religion').keyup(function() {
        validate_2_f();
    });

    $('#occu').keyup(function() {
        validate_2_g();
    });

    $('#res').keyup(function() {
        validate_2_h();
    });

    $('#nic').keyup(function() {
        validate_2_i();
    });

    $('#elecReg').keyup(function() {
        validate_2_j();
    });

    $('#fatherNameAddr').keyup(function() {
        validate_2_k();
    });

    $('#certPurpose').keyup(function() {
        validate_2_l();
    });

    $('#residPeriod').keyup(function() {
        validate_3_a();
    });

    $('#natureResEvd').keyup(function() {
        validate_3_b();
    });

    $('#convByLaw').keyup(function() {
        validate_3_c();
    });

    $('#charc').keyup(function() {
        validate_3_e();
    });

    $('#remark').keyup(function() {
        validate_4_remark();
    });

    $('#gnKnown').change(() => {
        kwonnApplicantStatusByGN();
    });

    $("#sinceDate").change(() => {
        validate_1_e();
    });

    $('#submit').click(() => {
        if(isAllValidated()){
            var win = $('#confirm-window');
            win.modal('show');
        }
    });
    
    $('#save-form').click(() => {
        var l = $('#person-list');
        if(l.val() == null || l.val() == '')
            alert('Something went wrong!');
        else{
            var form = document.getElementById("char-cert");
            var data = new FormData(form);
            data.append('requested_person_id', $('#person-list').val());
            
            $.ajax({
                type: 'post',
                url: './controls/admin/save_charCertificate.php',
                processData: false,
                contentType: false,
                data: data,
                success: function(r){
                    alert(r);
                    //form.reset();
                },
                error: function(){
                    alert('Something went wrong!');
                },
                complete: function(){
                    l.prop("selectedIndex", 0).val();
                }
            });
        }
    })
});

/* field validation */

function validate_1_c(){
    if($('#divNum').val() == ''){
        addValidation($('#divNumVal'), 'Division number is required');
        $($('#divNum')).focus();
        return false;
    }
    removeValidation($('#divNumVal'));
    return true;
}

function validate_1_e(){
    if($('#gnKnown').val() == "1" && $("#sinceDate").val() == ''){
        addValidation($('#sinceDateVal'), 'Known date is required');
        $($('#sinceDate')).focus();
        return false;
    }
    
    removeValidation($('#sinceDateVal'));
    return true;
}

function validate_2_a(){
    if($('#name').val() == ''){
        addValidation($('#nameVal'), 'Name is required');
        $($('#name')).focus();
        return false;
    }
    removeValidation($('#nameVal'));
    return true;
}

function validate_2_b(){
    if($('#address').val() == ''){
        addValidation($('#addressVal'), 'Address is required');
        $($('#address')).focus();
        return false;
    }
    removeValidation($('#addressVal'));
    return true;
}

function validate_2_c(){
    if($('#age').val() == ''){
        addValidation($('#ageVal'), 'Age is required');
        $($('#age')).focus();
        return false;
    }

    var age = parseInt($('#age').val());
    if(age <= 0){
        addValidation($('#ageVal'), 'Invalid age');
        $($('#age')).focus();
        return false;
    }
    removeValidation($('#ageVal'));
    return true;
}

function validate_2_e(){
    if($('#isSL').val() == ''){
        addValidation($('#isSLVal'), 'Specify descendet of Sri Lanka');
        $($('#isSL')).focus();
        return false;
    }
    removeValidation($('#isSLVal'));
    return true;
}

function validate_2_e(){
    if($('#isSL').val() == ''){
        addValidation($('#isSLVal'), 'Specify descendet of Sri Lanka');
        $($('#isSL')).focus();
        return false;
    }
    removeValidation($('#isSLVal'));
    return true;
}

function validate_2_f(){
    if($('#religion').val() == ''){
        addValidation($('#religionVal'), 'Religion is required');
        $($('#religion')).focus();
        return false;
    }
    removeValidation($('#religionVal'));
    return true;
}

function validate_2_g(){
    if($('#occu').val() == ''){
        addValidation($('#occuVal'), 'Present occupation is required');
        $($('#occu')).focus();
        return false;
    }
    removeValidation($('#occuVal'));
    return true;
}

function validate_2_h(){
    if($('#res').val() == ''){
        addValidation($('#resVal'), 'Period of resident is required');
        $($('#res')).focus();
        return false;
    }
    removeValidation($('#resVal'));
    return true;
}

function validate_2_i(){
    if($('#nic').val() == ''){
        addValidation($('#nicVal'), 'NIC number is required');
        $($('#nic')).focus();
        return false;
    }
    var len = $('#nic').val().length
    if(!(len == 10 || len == 12)){
        addValidation($('#nicVal'), 'Invalid NIC');
        $($('#nic')).focus();
        return false;
    }
    var regex = len == 10 ? /[1-9]{1}[0-9]{8}[vVxX]{1}/
        : len == 12 ? /[1-9]{1}[0-9]{11}/ : '';
    if(!regex.test($('#nic').val())){
        addValidation($('#nicVal'), 'Incorrect NIC format');
        $($('#nic')).focus();
        return false;
    }
    removeValidation($('#nicVal'));
    return true;
}

function validate_2_j(){
    if($('#elecReg').val() == ''){
        addValidation($('#elecRegVal'), 'Number of electorial registration is required');
        $($('#elecReg')).focus();
        return false;
    }
    removeValidation($('#elecRegVal'));
    return true;
}

function validate_2_k(){
    if($('#fatherNameAddr').val() == ''){
        addValidation($('#fatherNameAddrVal'), 'Father\'s name and address is required');
        $($('#fatherNameAddr')).focus();
        return false;
    }
    removeValidation($('#fatherNameAddrVal'));
    return true;
}

function validate_2_l(){
    if($('#certPurpose').val() == ''){
        addValidation($('#certPurposeVal'), 'Purpose is required');
        $($('#certPurpose')).focus();
        return false;
    }
    removeValidation($('#certPurposeVal'));
    return true;
}

function validate_2_m(){
    var file = $('#sig');
    var fileLabel = $('#sigLbl');
    if(file.val() == ''){
        fileLabel.html('Select file...');
        addValidation($('#sigVal'), 'Upload your signature');
        return false;
    }

    removeValidation($('#sigVal'));
    var fileName = file.val().split('\\').pop();
    var ext = fileName.split('.').pop();
    var types = ['jpg', 'png', 'jpeg', 'png', 'pdf'];
    var fact = 2;
    var maxSize = fact * 1024 * 1024;

    var isValidType = types.includes(ext.toLowerCase());
    var isValidSize = file[0].files[0].size <= maxSize;

    if(!isValidType){
        file.val('');
        fileLabel.html('Select file...');
        addValidation($('#sigVal'), 'Incorrect file format')
        return false;
    }

    if(!isValidSize){
        file.val('');
        fileLabel.html('Select file...');
        addValidation($('#sigVal'), `File size should be less than ${fact} MB`);
        return false;
    }

    fileLabel.html(fileName);
    return true;
}

function validate_3_a(){
    if($('#residPeriod').val() == ''){
        addValidation($('#residPeriodVal'), 'Resisent period is required');
        $($('#residPeriod')).focus();
        return false;
    }
    removeValidation($('#residPeriodVal'));
    return true;
}

function validate_3_b(){
    if($('#natureResEvd').val() == ''){
        addValidation($('#natureResEvdVal'), 'Evidences proofs are required');
        $($('#natureResEvd')).focus();
        return false;
    }
    removeValidation($('#natureResEvdVal'));
    return true;
}

function validate_3_c(){
    if($('#convByLaw').val() == ''){
        addValidation($('#convByLawVal'), 'Convictional information is required');
        $($('#convByLaw')).focus();
        return false;
    }
    removeValidation($('#convByLawVal'));
    return true;
}

/*function validate_3_d(){
    if($('#act').val() == ''){
        addValidation($('#actVal'), 'Public interests information is required');
        $($('#act')).focus();
        return false;
    }
    removeValidation($('#actVal'));
    return true;
}*/

function validate_3_e(){
    if($('#charc').val() == ''){
        addValidation($('#charcVal'), 'Character information is required');
        $($('#charc')).focus();
        return false;
    }
    removeValidation($('#charcVal'));
    return true;
}

function validate_4_remark(){
    if($('#remark').val() == ''){
        addValidation($('#remarkVal'), 'Remark is required');
        $($('#remark')).focus();
        return false;
    }
    removeValidation($('#remarkVal'));
    return true;
}

function isAllValidated(){
    return validate_1_c() & validate_1_e() & validate_2_a() & validate_2_b() & validate_2_c()
    & validate_2_e() & validate_2_f() & validate_2_g() & validate_2_h() & validate_2_i() 
    & validate_2_j() & validate_2_k() & validate_2_l() &  validate_3_a()
    & validate_3_b() & validate_3_c() & validate_3_e() & validate_4_remark();
}
