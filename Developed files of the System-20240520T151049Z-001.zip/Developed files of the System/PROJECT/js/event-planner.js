$(document).ready(() => {
    $('.add').click(() => { openAddEvent(); })
    $('#create').click(() => { create(); })

    $('#name').on('change keyup', () => { valName(); })
    $('#date').on('change', () => { valDate(); })
    $('#sTime').on('change', () => { valSTime(); })
    $('#eTime').on('change', () => { valETime(); })
    $('#loc').on('change keyup', () => { valLoc(); })
})

function openAddEvent(){
    var addEvent = $('#addEvent');
    addEvent.modal('show');
}

function create(){
    if(isValid()){
        var data = new FormData(document.getElementById('data'));
        data.append('pub', $('#pub').is(':checked'));
        
        $.ajax({
            type: 'post',
            url: './controls/admin/save_event.php',
            contentType: false,
            processData: false,
            data: data,
            success: function(r){
                system_alert(r);
                $('#addEvent').modal('hide');
            },
            error: function(){
                system_alert('Something went wrong!');
            }
        })
    }
}

function remove(id){
    var data = new FormData();
    data.append('Id', id);
    
    $.ajax({
        type: 'post',
        url: './controls/admin/delete_eventData.php',
        contentType: false,
        processData: false,
        data: data,
        success: function(r){
            system_alert(r);
        },
        error: function(){
            system_alert('Something went wrong!');
        }
    })
}

function addVal(val, msg){
    val.html(msg);
}

function removeVal(val){
    val.html('');
}

function isValid(){
    return valName() & valDate() & valSTime() & 
    valETime() & valTimeRange() & valLoc();
}

/* Validation func */
function valName(){
    var i = $('#name');
    var v = $('#nameVal');
    if(i.val() == null || i.val() == ''){
        addVal(v, 'Event name is required');
        return false;
    }

    removeVal(v);
    return true;
}

function valDate(){
    var i = $('#date');
    var v = $('#dateVal');
    if(i.val() == null || i.val() == ''){
        addVal(v, 'Event date is required');
        return false;
    }

    var d = new Date(i.val());
    var t = new Date();
    if(d <= t){
        addVal(v, 'Event date cannot be in past');
        return false;
    }

    removeVal(v);
    return true;
}

function valSTime(){
    var i = $('#sTime');
    var v = $('#sTimeVal');
    if(i.val() == null || i.val() == ''){
        addVal(v, 'Event start time is required');
        return false;
    }

    removeVal(v);
    return true;
}

function valETime(){
    var i = $('#eTime');
    var v = $('#eTimeVal');
    if(i.val() == null || i.val() == ''){
        addVal(v, 'Event end time is required');
        return false;
    }

    removeVal(v);
    return true;
}

function valLoc(){
    var i = $('#loc');
    var v = $('#locVal');
    if(i.val() == null || i.val() == ''){
        addVal(v, 'Event location is required');
        return false;
    }

    removeVal(v);
    return true;
}

function valTimeRange(){
    var s = $('#sTime').val();
    var e = $('#eTime').val();
    if(translateTime(s) > translateTime(e)){
        system_alert('Start time must be earlier than end time');
        return false
    }

    return true;
}

function translateTime(timeStr){
    var h = parseInt(timeStr.substr(0, 2));
    var m = parseInt(timeStr.substr(3, 2));
    return (h * 60) + m;
}