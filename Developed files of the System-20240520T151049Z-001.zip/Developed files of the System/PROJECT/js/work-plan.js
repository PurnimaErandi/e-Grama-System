$(document).ready(function (e) {
            //$("#work_plan_forms").on('submit', (function (e) {
               // e.preventDefault();
               // $.ajax({
                   // url: "./controls/work_plan.php", // Url to which the request is send
                   // type: "POST", // Type of request to be s", // Url to which the request is send
                    //data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    //contentType: false, // The content type used when sending data to the server.
                    //cache: false, // To unable request pages to be cached
                    //processData: false, // To send DOMDocument or non processed data file it is set to false
                    //success: function (data)   // A function to be called if request succeeds
                    //{
                        //if (data == "1") {
                            //system_alert("Saved success");
                        //} else {
                            //system_alert(data);
                            //changePath("./content/workPlans");
                        //}
                    //}
                //});})
            //);

            /* Validation events */
            $('#date').change(() => {
                validateDate();
            });

            $('#time').change(() => {
                validateTime();
            });

            $('#typeofwork').change(() => {
                validateWorkType();
            });

            $('#descriptn').keyup(() => {
                validateDescription();
            });

            $('#save').click(() => {
                submit();
            });

            $('#cancel').click(() => {
                clear();
            });

        });

        function addValidation(valIn, validationIndicator, message){
            validationIndicator.html(message);
            valIn.addClass('in-err');
        }

        function removeValidation(valIn, validationIndicator){
            validationIndicator.html('');
            valIn.removeClass('in-err');
        }

        /* Validation functions */
        function validateDate(){
            if($('#date').val() == ''){
                addValidation($('#date'), $('#dateVal'), 'Date is required');
                $('#date').focus();
                return false;
            }
            removeValidation($('#date'), $('#dateVal'));
            return true;
        }

        function validateTime(){
            if($('#time').val() == ''){
                addValidation($('#time'), $('#timeVal'), 'Time is required');
                $('#time').focus();
                return false;
            }
            removeValidation($('#time'), $('#timeVal'));
            return true;
        }

        function validateWorkType(){
            if($('#typeofwork').val() == ''){
                addValidation($('#typeofwork'), $('#typeofworkVal'), 'Type of work is required');
                $('#typeofwork').focus();
                return false;
            }
            removeValidation($('#typeofwork'), $('#typeofworkVal'));
            return true;
        }

        function validateDescription(){
            if($('#descriptn').val() == ''){
                addValidation($('#descriptn'), $('#descriptnVal'), 'Description is required');
                $('#descriptn').focus();
                return false;
            }
            removeValidation($('#descriptn'), $('#descriptnVal'));
            return true;
        }

        /* Validate on submition */
        function isValidate(){
            return validateDate() & validateTime() & validateWorkType() & validateDescription();
        }

        /* Submit form */
        function submit(){
            if(isValidate()){
                
                var data = new FormData();
                data.append('date', $('#date').val());
                data.append('time', $('#time').val());
                data.append('typeofwork', $('#typeofwork').val());
                data.append('descriptn', $('#descriptn').val());
                $.ajax({
                    url: "./controls/admin/work_plan.php",
                    type: "POST", 
                    data: data,
                    contentType: false,
                    cache: false, 
                    processData: false,
                    success: function (data)
                    {
                        if (data == "1") {
                            clear();
                            system_alert("Saved success");
                        } else {
                            system_alert(data);
                            changePath("./content/admin/workPlans");
                        }
                    },
                    error: function(){
                        system_alert('Something went wrong while communicating with server.');
                    }
                })
            }
            else{
                $('.in-err').filter(':first').focus();
            }
        }

        function clear(){
            removeValidation($('#date'), $('#dateVal'));
            removeValidation($('#time'), $('#timeVal'));
            removeValidation($('#typeofwork'), $('#typeofworkVal'));
            removeValidation($('#descriptn'), $('#descriptnVal'));
            $('#date').val('');
            $('#typeofwork option[value=Seminars]').attr('selected','selected');
            $('#descriptn').val('');
            $('#time').val('');
        }