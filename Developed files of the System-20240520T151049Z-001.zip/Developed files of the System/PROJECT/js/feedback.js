var selectedMood = 0;
var allMoods = $('.fbtn');

$(document).ready(() => {
    $('#m1').click(() => { mood($('#m1')); valMood(); })
    $('#m2').click(() => { mood($('#m2')); valMood(); })
    $('#m3').click(() => { mood($('#m3')); valMood(); })
    $('#m4').click(() => { mood($('#m4')); valMood(); })
    $('#m5').click(() => { mood($('#m5')); valMood(); })

    $('#type').change(() => { valType(); })
    $('#feed').on('keyup change', () => { valFeed(); })

    $('#submit').click(() => { submit(); })
})

function toggleClasses(elem){
    $('.fbtn').removeClass('selected');
    elem.addClass('selected');
}

function mood(btn){
    toggleClasses(btn);
    selectedMood = btn.attr('data-mood');
}

function addValidation(valElem, msg){
    valElem.html(msg);
}

function removeValidation(valElem){
    valElem.html('');
}

function isValid(){
    return valType() & valFeed() & valMood();
}

function submit(){
    if(isValid()){
        var data = new FormData();
        data.append('rate', selectedMood);
        data.append('type', $('#type').val());
        data.append('feedback', $('#feed').val());
        data.append('isAnnonymous', $('#sendAnon').is(':checked').toString());

        var x = `rate: ${data.getAll('rate')} | type: ${data.getAll('type')} |
        feed: ${data.getAll('feedback')} | isAnon: ${data.getAll('isAnnonymous')}`
        
        $.ajax({
            type: 'post',
            url: './controls/user/send_feedback.php',
            processData: false,
            contentType: false,
            data: data,
            success: function(r){
                r = JSON.parse(r);
                Swal.fire({
                    title: r.title,
                    html: r.msg,
                    icon: r.s
                });
                clearePage();
            },
            error: function(){
                Swal.fire({
                    title: 'Send Fail',
                    html: 'Something went wrong!',
                    icon: 'error'
                });
            }
        })
    }
}

function valType(){
    if($('#type').val() == '' || $('#type').val() == null){
        addValidation($('#typeVal'), 'Set your feedback type');
        return false;
    }

    removeValidation($('#typeVal'));
    return true;
}

function valFeed(){
    if($('#feed').val() == '' || $('#feed').val() == null){
        addValidation($('#feedVal'), 'Enter your feedback');
        return false;
    }

    removeValidation($('#feedVal'));
    return true;
}

function valMood(){
    if(selectedMood <= 0){
        addValidation($('#moodVal'), 'Select your rating');
        return false;
    }

    removeValidation($('#moodVal'));
    return true;
}

function clearePage(){
    selectedMood = 0;
    $('.fbtn').removeClass('selected');
    $('#type').prop('selectedIndex', 0);
    $('#feed').val('');
    $('input[type="checkbox"]').prop('checked', false);
}