var user;

$(document).ready(() => {
    db();

    $('#save').click(() => { changePassword(); })

    /* Form validation events */
    $('#oldPassword').on('keyup change', () => { validateOldPass(); })
    $('#newPassword').on('keyup change', () => { validateNewPass(); })
})

function addValidation(valIn, validationIndicator, message, label){
    validationIndicator.html(message);
    valIn.css({ 'border-color': 'red' });
    label.css({ 'color': 'red' });
    valIn.addClass('in-err');
}

function removeValidation(valIn, validationIndicator, label){
    validationIndicator.html('');
    valIn.css({ 'border-color': '#ced4da' });
    label.css({ 'color': 'black' });
    valIn.removeClass('in-err');
}

function changePassword(){
    if(isValid()){
        var data = new FormData();
        data.append('password', $('#newPassword').val());
        data.append('oldPassword', $('#oldPassword').val());
        $.ajax({
            type: 'POST',
            url: './controls/admin/updatePassword.php',
            async: false,
            data: data,
            contentType: false,
            processData: false,
            success: function(response){
                alert(response);
            },
            error: function(){
                alert('Something went wrong!');
            }
        });
    }
    else{
        $('.in-err').filter(':first').focus();
    }
}

function isValid(){
    return validateOldPass() & validateNewPass();
}

function loadData(){
    $('.prof-title').html(user.userName);
    $('.prof-email').html(user.userEmail);
    if(user.profImg == ''){
        $('.prof-image-src').attr('src', './img/res/prof-default.jpg');
    }
    else{
        user.profImg = user.profImg.replace("/..", "");
        $('.prof-image-src').attr('src', user.profImg);
    }
}

function db(){
    var x;
    $.ajax({
        type: 'post',
        url: './controls/admin/getProfileData.php',
        processData: false,
        contentType: false,
        async: true,
        success: function(data){
            x = JSON.parse(data);
        },
        error: function(){
            system_alert("Something went wrong!");
        },
        complete: function(){
            user = {
                'userName': x.title,
                'userEmail': x.email,
                'profImg': x.image
            };
            loadData();
        }
    });
}

/* Form validations */
function validateOldPass(){
    if($('#oldPassword').val() == ''){
        addValidation($('#oldPassword'), $('#val-oldPassword'), 
        'Old password is required', $('#lbl-oldPassword'));
        $('#oldPassword').focus();
        return false;
    }
    removeValidation($('#oldPassword'), $('#val-oldPassword'), $('#lbl-oldPassword'));
    return true;
}

function validateNewPass(){
    if($('#newPassword').val() == ''){
        addValidation($('#newPassword'), $('#val-newPassword'), 
        'New password is required', $('#lbl-newPassword'));
        $('#newPassword').focus();
        return false;
    }

    removeValidation($('#newPassword'), $('#val-newPassword'), $('#lbl-newPassword'));
    return true;
}