var roles;

$(document).ready(() => {
    //fillUsers();
    searchUser();

    $('#addUser').click(() => { openAddUserWindow(); })

    /* Validation events */
    $('#uname').on('keyup change', () => { validateUsername(); })
    $('#profpic').change(() => { validateProfPic(); })
    $('#pword').on('keyup change', () => { validatePass(); })
    $('#repass').on('keyup change', () => { validateRetypePass(); })
    $('#fullname').on('keyup change', () => { validateFullname(); })
    $('#email').on('keyup change', () => { validateEmail(); })
    $('#nic').on('keyup change', () => { validateNic(); })

    $('#submit').click(() => { submit(); })
})

function openAddUserWindow(){
    //roles = loadUserRoles();
    $('#urole').empty();
    //var r;
    $.ajax({
        type: 'get',
        url: './controls/admin/get_userRole.php',
        async: false,
        cache: false,
        dataType: 'JSON',
        success: function (data) {
            roles = data;
        },
        error: function () {
            console.error('something went wrong!');
        },
        complete: function() {
            $.each(roles, i => {
                $('#urole').append(`<option value="${roles[i].roleId}">${roles[i].role}</option>`)
            });
            clearForm();
            var win = $('#add-user-window');
            win.modal('show');
        }
    }); 
}

/* Validation helper functions */

function addValidation(valIn, validationIndicator, message){
    validationIndicator.html(message);
    valIn.addClass('in-err');
}

function removeValidation(valIn, validationIndicator){
    validationIndicator.html('');
    valIn.removeClass('in-err');
}

function isValidate(){
    return validateUsername() & validatePass() & validateProfPic() &
    validateRetypePass() & validateFullname() & validateEmail() &
    validateNic();
}

function submit(){
    if(isValidate()){
        var form = document.getElementById('userData');
        var data = new FormData(form);
        $.ajax({
            type: 'post',
            url: './controls/admin/user-register.php',
            processData: false,
            contentType: false,
            data: data,
            success: function (data) {
                if (data == "1") {
                    system_alert("Saved success");
                } else {
                    system_alert(data);
                    changePath("./content/admin/users");
                }
            },
            error: function (){
                alert('Oh no!');
            }
        });
        clearForm();
        $('#add-user-window').modal('hide');
        $('#searchUser').val('');
        //fillUsers();
    }
    else{
        $('.in-err').filter(':first').focus()
    }
}

/* Form validations */

function validateUsername(){
    if($('#uname').val() == ''){
        addValidation($('#uname'), $('#unameVal'), 'Username is required');
        $('#uname').focus();
        return false;
    }
    removeValidation($('#uname'), $('#unameVal'));
    return true;
}

function validatePass(){
    if($('#pword').val() == ''){
        addValidation($('#pword'), $('#pwordVal'), 'Password is required');
        $('#pword').focus();
        return false;
    }
    var pLength = 8;
    if($('#pword').val().length < pLength){
        addValidation($('#pword'), $('#pwordVal'), `Password must have at least ${pLength} characters`);
        $('#pword').focus();
        return false;
    }
    removeValidation($('#pword'), $('#pwordVal'));
    return true;
}

function validateRetypePass(){
    if($('#repass').val() == ''){
        addValidation($('#repass'), $('#repassVal'), 'Retyping password is required');
        $('#repass').focus();
        return false;
    }
    if($('#pword').val() != $('#repass').val()){
        addValidation($('#repass'), $('#repassVal'), 'Password does not match');
        $('#repass').focus();
        return false;
    }

    removeValidation($('#repass'), $('#repassVal'));
    return true;
}

function validateFullname(){
    if($('#fullname').val() == ''){
        addValidation($('#fullname'), $('#fullnameVal'), 'Full Name is required');
        $('#fullname').focus();
        return false;
    }
    removeValidation($('#fullname'), $('#fullnameVal'));
    return true;
}

function validateEmail(){
    if($('#email').val() == ''){
        addValidation($('#email'), $('#emailVal'), 'Email is required');
        $('#email').focus();
        return false;
    }
    var rx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(!rx.test($('#email').val())){
        addValidation($('#email'), $('#emailVal'), 'Invalid email address');
        $('#email').focus();
        return false;
    }
    removeValidation($('#email'), $('#emailVal'));
    return true;
}

function validateNic(){
    if($('#nic').val() == ''){
        addValidation($('#nic'), $('#nicVal'), 'NIC is required');
        $('#nic').focus();
        return false;
    }
    var nicOld = /[1-9]{1}[0-9]{8}[vVxX]{1}/;
    var nicNew = /[1-9]{1}[0-9]{6}[0]{1}[0-9]{4}/;
    if(!($('#nic').val().length == 10 || $('#nic').val().length == 12)){
        addValidation($('#nic'), $('#nicVal'), 'NIC format error');
        $('#nic').focus();
        return false;
    }
    if($('#nic').val().length == 10 && !nicOld.test($('#nic').val())){
        addValidation($('#nic'), $('#nicVal'), 'Invalid NIC Number');
        $('#nic').focus();
        return false;
    }
    if($('#nic').val().length == 12 && !nicNew.test($('#nic').val())){
        addValidation($('#nic'), $('#nicVal'), 'Invalid NIC Number');
        $('#nic').focus();
        return false;
    }
    removeValidation($('#nic'), $('#nicVal'));
    return true;
}

function validateProfPic(){
    var upIn = $('#profpic');
    var uLbl = $('#lbl-profpic');
    var uVal = $('#profpicVal');
    var types = ['jpg', 'png', 'jpeg'];
    var maxSize = 2 * 1024 * 1024;
    const label = 'Select File...';

    if(upIn.val() == ''){
        uLbl.html(label);
        uVal.html('Profile picture is required');
        return false;
    }

    uVal.html('');
    var filename = upIn.val().split('\\').pop();
    var ext = filename.split('.').pop();

    if(!types.includes(ext.toLowerCase())){
        upIn.val('');
        uVal.html(label);
        var tList = types.toString().replaceAll(',', '/ ').toUpperCase();
        uVal.html(`Any ${tList} type is required`);
        return false;
    }

    if(upIn[0].files[0].size > maxSize){
        upIn.val('');
        uVal.html(label);
        uVal.html(`Cannot exceed maximum file size of ${maxSize / Math.pow(1024, 2)} MB`);
        return false;
    }

    uLbl.html(filename);
    return true;
}

function loadUserRoles(){
    var r;
    $.ajax({
        type: 'POST',
        url: './controls/admin/get_userRole.php',
        async: false,
        success: function (data) {
            r = data;
            console.log(data);
            console.log('Hi');
        },
        error: function () {
            console.error('something went wrong!');
        }
    });
    return r;
}

function fillUsers(){
    var users = loadUsers();
    var table = $('.user-list-body');
    table.empty();
    table.html('');

    $.each(users, i => {
        var user = `
        <tr>
            <td class="data-middle">
                <i class="fa fa-trash del" onclick="remove(${users[i].userid})" title="Delete User"></i>
            </td>
            <td class="data-middle">
                <div class="img-cont">
                    <a href="${users[i].profpic}" target="_blank">
                        <img class="prof-pic-src" src="${users[i].profpic}" width="64" height="64" alt="profile-pic"/>
                    </a>
                </div>
            </td>
            <td class="data-middle data">${users[i].username}</td>
            <td class="data-middle data">${users[i].fullname}</td>
            <td class="data-middle data">${users[i].email}</td>
            <td class="data-middle data">${users[i].nic}</td>
            <td class="data-middle data">${users[i].role}</td>
        </tr>`;
        table.append(user);
    });
    
}

function clearForm(){
    $('input[type="text"]').val('');
    $('input[type="password"]').val('');;
    $('input[type="file"]').val('');
    $('input[type="email"]').val('');
    $('#lbl-profpic').html('Select File...');
    $('.val').html('');
    $("select")[0].selectedIndex = 0;
}

function searchUser() {
    $('#searchUser').keyup(function () {
        var val = $(this).val().toLowerCase();
        $(".user-list-body tr").filter(function () {
            $(this).toggle(
                $('.data', this).text().toLowerCase().indexOf(val) > -1
            );
        });
    });
}

function loadUsers(){
    var u;
    $.ajax({
        type: 'get',
        url: './controls/admin/get_all_users.php',
        async: false,
        cache: false,
        dataType: 'JSON',
        success: function (data) {
            u = data;
        },
        error: function () {
            console.error('something went wrong!');
        }
    });
    return u;
}

function remove(id){
    var data = new FormData();
    data.append('userId', id);
    
    $.ajax({
        type: 'post',
        url: './controls/admin/remove_user.php',
        async: false,
        processData: false,
        data: data,
        contentType: false,
        cache: false,
        success: function (data) {
            if(data == "1"){
                system_alert("User successfully removed!");
            }
            else{
                system_alert(data);
            }
        },
        error: function () {
            console.error('something went wrong!');
        }
    });
}