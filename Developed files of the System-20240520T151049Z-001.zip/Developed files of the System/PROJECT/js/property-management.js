$(document).ready(() => {
    $('#prop_load').select2();
    setSelect2Styles();
    $('#error').on('shown.bs.modal', () => { $('#loader').modal('hide'); });
    $('input[type="reset"]').click(() => { clearValidation(); })

    /* House validation events */
    $('#prop_load').on('change', () => { validateAddH(); })
    $('#hse').on('keyup change', () => { validateNameH(); })
    $('#date').on('keyup change', () => { validateDateH(); })
    $('#odetails').on('keyup change', () => { validateOtherDet(); })
    $('#submit-h').click(() => { submitHouse(); })

    /* Property validation events */
    $('#address').on('keyup change', () => { validateAddP(); })
    $('#purchaseland').on('keyup change', () => { validateArea(); })
    $('#majorcrps').on('keyup change', () => { validateCrop(); })
    $('#lati').on('keyup change', () => { validateLati(); })
    $('#long').on('keyup change', () => { validateLong(); })
    $('#vorstreet').on('keyup change', () => { validateStName(); })
    $('#save-p').click(() => { submitProperty(); })
})

function setSelect2Styles(){
    var wr = $('.select2-selection');
    var ct = $('.select2-selection__rendered');
    wr.css({ 'height': 'calc(2.25rem + 2px)' });
    wr.css({ 'border': '1px solid #ced4da' })
    ct.css({ 'line-height': '35px' });
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {
    $("#lati").val(position.coords.latitude);
    $("#long").val(position.coords.longitude);
    validateLati();
    validateLong();
}

function addValidation(valIn, validationIndicator, message){
    validationIndicator.html(message);
    valIn.addClass('in-err');
}

function removeValidation(valIn, validationIndicator){
    validationIndicator.html('');
    valIn.removeClass('in-err');
}

function isValidateH(){
    return validateAddH() & validateNameH() & validateDateH() & validateOtherDet();
}

function isValidateP(){
    return validateAddP() & validateArea() & validateCrop() & validateLati()
    & validateLong() & validateStName();
}

function clearValidation(){
    $('.val').html('');
}

/* House validations */
function validateAddH(){
    if($('#prop_load').val() == ''){
        addValidation($('#prop_load'), $('#val-prop_load'), 'Address is required');
        $('#prop_load').focus();
        return false;
    }
    removeValidation($('#prop_load'), $('#val-prop_load'));
    return true;
}

function validateNameH(){
    if($('#hse').val() == ''){
        addValidation($('#hse'), $('#val-hse'),);
        $('#hse').focus();
        return false;
    }
    removeValidation($('#hse'), $('#val-hse'));
    return true;
}

function validateDateH(){
    if($('#date').val() == ''){
        addValidation($('#date'), $('#val-date'), 'House built date is required');
        $('#date').focus();
        return false;
    }
    removeValidation($('#date'), $('#val-date'));
    return true;
}

function validateOtherDet(){
    if($('#odetails').val() == ''){
        addValidation($('#odetails'), $('#val-odetails'), 'Other details are required');
        $('#odetails').focus();
        return false;
    }
    removeValidation($('#odetails'), $('#val-odetails'));
    return true;
}

function submitHouse(){
    if(isValidateH()){
        var data = new FormData(document.getElementById('houseInfo'));
        data.append('address_id', $('#prop_load').val());
        data.append('radio', $('#rdio').val());
        data.append('television', $('#tv').val());
        data.append('landline', $('#lndlne').val());
        data.append('mobilephone', $('#mobphone').val());
        data.append('deskcomputer', $('#deskcom').val());
        data.append('laptop', $('#lptop').val());
        data.append('internconnctn', $('#intercon').val()); 
        data.append('washmachine', $('#wmahine').val());
        data.append('refrigertr', $('#refrig').val());
        data.append('aircondtner', $('#aircondtr').val());
        data.append('gascooker', $('#gascker').val());
        data.append('ricecooker', $('#rcecoker').val());
    
        $.ajax({
            url: "./controls/admin/save_household.php",
                type: "POST",
                data: data,
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function(){
                    $('#loader').modal('show');
                },
                success: function(data){
                    $('#loader').modal('hide');
                    if(data == "1"){
                        document.getElementById('houseInfo').reset();
                        system_alert("Saved success");
                    }
                    else{
                        system_alert(data);
                    }
                },
                error: function(){
                    $('#error').modal('show');
                }
        })
    }
    else{
        $('.in-err').filter(':first').focus();
    }
}

/* Property validation */
function validateAddP(){
    if($('#address').val() == ''){
        addValidation($('#address'), $('#val-address'), 'Address is required');
        $('#address').focus();
        return false;
    }
    removeValidation($('#address'), $('#val-address'));
    return true;
}

function validateArea(){
    if($('#purchaseland').val() == ''){
        addValidation($('#purchaseland'), $('#val-purchaseland'), 'Land area is required');
        $('#purchaseland').focus();
        return false;
    }
    var area = parseFloat($('#purchaseland').val());
    if(area <= 0){
        addValidation($('#purchaseland'), $('#val-purchaseland'), 'Invalid area value');
        $('#purchaseland').focus();
        return false;
    }
    
    removeValidation($('#purchaseland'), $('#val-purchaseland'));
    return true;
}

function validateCrop(){
    if($('#majorcrps').val() == ''){
        addValidation($('#majorcrps'), $('#val-majorcrps'), 'Major Crops are required');
        $('#majorcrps').focus();
        return false;
    }
    removeValidation($('#majorcrps'), $('#val-majorcrps'));
    return true;
}

function validateLati(){
    if($('#lati').val() == ''){
        addValidation($('#lati'), $('#val-lati'), 'Latitude is required');
        $('#lati').focus();
        return false;
    }
    var n = parseFloat($('#lati').val());
    if(n < -90 || n > 90){
        addValidation($('#lati'), $('#val-lati'), 'Invalid latitude value');
        $('#lati').focus();
        return false;
    }
    
    removeValidation($('#lati'), $('#val-lati'));
    return true;
}

function validateLong(){
    if($('#long').val() == ''){
        addValidation($('#long'), $('#val-long'), 'Longitude is required');
        $('#long').focus();
        return false;
    }
    var n = parseFloat($('#long').val());
    if(n < -180 || n > 180){
        addValidation($('#long'), $('#val-long'), 'Invalid Longitude value');
        $('#long').focus();
        return false;
    }
    
    removeValidation($('#long'), $('#val-long'));
    return true;
}

function validateStName(){
    if($('#vorstreet').val() == ''){
        addValidation($('#vorstreet'), $('#val-vorstreet'), 'Village/Street are required');
        $('#vorstreet').focus();
        return false;
    }
    removeValidation($('#vorstreet'), $('#val-vorstreet'));
    return true;
}

function submitProperty(){
    if(isValidateP()){
        var data = new FormData(document.getElementById('propInfo'));
        data.append("water", $('#wter').val());
        data.append("lights", $('#lghts').val());
        data.append("toilets", $('#tlets').val());
        data.append("garbage", $('#grbge').val());
        
        $.ajax({
            url: "./controls/admin/save_property.php",
                type: "POST",
                data: data,
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function(){
                    $('#loader').modal('show');
                },
                success: function(data){
                    $('#loader').modal('hide');
                    if(data == "1"){
                        document.getElementById('propInfo').reset();
                        system_alert("Saved success");
                    }
                    else{
                        system_alert(data);
                    }
                },
                error: function(){
                    $('#error').modal('show');
                }
        })
    }
    else{
        $('.in-err').filter(':first').focus();
    }
}