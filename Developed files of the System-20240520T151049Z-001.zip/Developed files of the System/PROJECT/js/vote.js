$(document).ready(() => {
    loadData();
    searchData();

    $('input[data-chkId]').change(e => {
        toggleRemark(e.target.checked, e.target.getAttribute('data-chkId'));
        if(!e.target.checked){
            saveOnCheck(e.target.getAttribute('data-chkId'));
        }
    });

    $('button[data-btnId]').click(e => {
        var dataId = e.target.getAttribute('data-btnId');
        save(dataId);
    })
})

function loadData(){
    var data;

    $.ajax({
        type: 'post',
        url: './controls/admin/get_voteList.php',
        contentType: false,
        async: false,
        success: function(r){
            data = JSON.parse(r);
        },
        error: function(){
            system_alert('Something went wrong!');
        },
        complete: function(){
            fillData(data);
        }
    });
}

function save(dataId){
    // add record to eligibility mapping
    if($(`input[data-textId="${dataId}"]`).val() == ''){
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
        toastr.error("Fill remark before saving!", "Data Error");
        return;
    }
    
    console.log($(`input[data-textId="${dataId}"]`).val());

    var data = new FormData();
    data.append('dataId', dataId);
    data.append('remark', $(`input[data-textId="${dataId}"]`).val());
    $.ajax({
        type: 'post',
        url: './controls/admin/update_voteData.php',
        contentType: false,
        processData: false,
        data: data,
        success: function(r){
            toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
            toastr.success(r, "Save Success");
        },
        error: function(){
            system_alert('Something went wrong!');
        }
    });
}

function saveOnCheck(dataId){
    var data = new FormData();
    data.append('dataId', dataId);
    
    $.ajax({
        type: 'post',
        url: './controls/admin/delete_voteData.php',
        contentType: false,
        processData: false,
        data: data,
        success: function(r){
            toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
            toastr.success(r, "Save Success");
            loadData();
        },
        error: function(){
            system_alert('Something went wrong!');
        }
    });
}

function fillData(data){
    var t = $('.table-body');
    t.empty();

    $.each(data, i => {
        var r = `
        <tr class="data-row">
            <td>
                <input type="checkbox" data-chkId="${data[i].Id}">
            </td>
            <td class="index">${data[i].Name}</td>
            <td class="index">${data[i].Address}</td>
            <td class="index">${data[i].Nic}</td>
            <td class="index">${data[i].DoB}</td>
            <td class="index">${data[i].Gender}</td>
            <td class="index">${data[i].TelNo}</td>
            <td id="_${data[i].Id}">
                <input type="text" class="index" value="${data[i].Remark}" style="display:none" />
                <div class="input-group" data-inId="${data[i].Id}">
                    <input type="text" data-textId="${data[i].Id}" class="form-control form-control-sm index" value="${data[i].Remark}" placeholder="Remark...">
                    <div class="input-group-append">
                        <button data-btnId="${data[i].Id}" class="btn btn-sm btn-danger">
                            <i data-btnId="${data[i].Id}" class="fa fa-save"></i>
                        </button>
                    </div>
                </div>
            </td>
        </tr>`;
        t.append(r);
        $(`input[data-chkId="${data[i].Id}"]`).prop('checked', data[i].IsRemoved);
        toggleRemark(data[i].IsRemoved, data[i].Id);
    });
}

function toggleRemark(_switch, dataId){
    $(`div[data-inId="${dataId}"] *`).prop('disabled', !_switch);
    if(!_switch)
        $(`button[data-btnId="${dataId}"]`).removeClass('btn-danger').addClass('btn-secondary');
    else
        $(`button[data-btnId="${dataId}"]`).addClass('btn-danger').removeClass('btn-secondary');
}

function searchData() {
    $('#data-search').keyup(function () {
        var val = $(this).val().toLowerCase();
        $("tbody .data-row").filter(function () {
            console.log($(this));
            $(this).toggle(
                $('.index', this).text().toLowerCase().indexOf(val) > -1 ||
                this.children[7].firstElementChild.value.toLowerCase().indexOf(val) > -1
            );
        });
    });
}