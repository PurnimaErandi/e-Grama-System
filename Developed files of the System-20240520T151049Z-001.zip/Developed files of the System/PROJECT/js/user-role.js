var roles = new Array();
var counter = 0;

$(document).ready(() => {
    disableEditing($('.edit'));
    loadRoles();

    $('#add-role').click(() => { openAddRoleWindow(); })
    $('#roleName').on('keyup change', () => { validateRoleName(); })
    $('#addRole').click(() => { submitRoleName(); })
    $('.edit').click(() => { toggleEditMode(); })
    $('#view-role-window').on('shown.bs.modal', () => { $('.role-container').scrollTop(0, 0); })
})

function addValidation(valIn, validationIndicator, message){
    validationIndicator.html(message);
    valIn.css({ 'border-color': 'red' });
    valIn.addClass('in-err');
}

function removeValidation(valIn, validationIndicator){
    validationIndicator.html('');
    valIn.css({ 'border-color': '#ced4da' });
    valIn.removeClass('in-err');
}

function submitRoleName(){
    if(validateRoleName()){
        var roleName = $('#roleName').val();

        var role = {
            'roleId': counter++,
            'roleName': roleName,
            'functions': {
                'systemData': {
                    'funcName': 'systemData',
                    's1': 'personalDetails',
                    's2': 'propertyManagement',
                    's3': 'workPlan',
                    's4': 'aidInfo',
                    'personalDetails': [false, false, false, false],
                    'propertyManagement': [false, false, false, false],
                    'workPlan': [false, false, false, false],
                    'aidInfo': [false, false, false, false]
                },
                'certificates': {
                    'funcName': 'certificates',
                    's1': 'charCert',
                    's2': 'deathCert',
                    's3': 'residCert',
                    'charCert': [false, false, false, false],
                    'deathCert': [false, false, false, false],
                    'residCert': [false, false, false, false]
                },
                'userManagement': {
                    'funcName': 'userManagement',
                    's1': 'users',
                    's2': 'userRoles',
                    's3': 'myProfile',
                    'users': [false, false, false, false],
                    'userRoles': [false, false, false, false],
                    'myProfile': [false, false, false, false]
                },
                'disasterRecoveryNode': {
                    'funcName': 'disasterRecoveryNode',
                    's1': 'disasterRecovery',
                    'disasterRecovery': [false, false, false, false]
                }
            }
        };

        var data = new FormData();
        data.append('role', JSON.stringify(role));

        $.ajax({
            type: 'POST',
            url: './controls/admin/save_privilages.php',
            async: false,
            data: data,
            contentType: false,
            processData: false,
            success: function(response){
                alert(response);
            },
            error: function(){
                alert('Something went wrong!');
            }
        });

        var row = 
            `<tr>
                <td>${role.roleName}</td>
                <td>
                    <button style="margin-right:5px;color:white" title="Check Privileges" class="btn btn-sm btn-warning" onclick="openRolePrivileges(${role.roleId})">
                        <i class="fa fa-key"></i>
                    </button>
                    <button style="margin-right:5px" title="Delete Privileges" class="btn btn-sm btn-danger" onclick="deleteRole(${role.roleId})">
                        <i class="fa fa-trash-alt"></i>
                    </button>
                </td>
            </tr>`;
        $('.role-table').append(row);
        $('#add-role-window').modal('hide');
        loadRoles();
    }
    else{
        $('.in-err').filter(':first').focus();
    }
}

function loadRoles(){
    var roleList;
    $('.role-table').empty();
    $('.role-table').hide();
    $.ajax({
        type: 'POST',
        url: './controls/admin/get_roles.php',
        async: false,
        contentType: false,
        processData: false,
        success: function(response){
            roleList = JSON.parse(response);
        },
        error: function(){
            alert('Something went wrong!');
        }
    });

    $.each(roleList, i => {
        var row = 
        `<tr>
            <td>${roleList[i].roleName}</td>
            <td>
                <button style="margin-right:5px;color:white" title="Check Privileges" class="btn btn-sm btn-warning" onclick="openRolePrivileges(${roleList[i].roleId})">
                    <i class="fa fa-key"></i>
                </button>
                <button style="margin-right:5px" title="Delete Privileges" class="btn btn-sm btn-danger" onclick="deleteRole(${roleList[i].roleId})">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        </tr>`;
        $('.role-table').append(row);
    });
    
    $('#add-role-window').modal('hide');
    $('.role-table').fadeIn(500);
}

function validateRoleName(){
    if($('#roleName').val() == ''){
        addValidation($('#roleName'), $('#roleNameVal'), 'Role name is required');
        $('#roleName').focus();
        return false;
    }
    removeValidation($('#roleName'), $('#roleNameVal'));
    return true;
}

function openRolePrivileges(roleId){
    disableEditing($('.edit'));
    $('.role-view-controls').html('');
    $('.role-view-controls').append(
        `<button class="btn btn-sm btn-primary" onclick="saveRole(${roleId})">Save</button>`
    );

    var data = new FormData(); var prev
    data.append('roleId', roleId);
    $.ajax({
        type: 'POST',
        url: './controls/admin/get_privilages.php',
        data: data,
        contentType: false,
        processData: false,
        async: false,
        success: function(response){
            prev = JSON.parse(response);
        },
        error: function(){
            alert('Something went wrong!');
        },
        complete: function(){
            if(prev != null){
                setRole(prev);
                $('#view-role-window').modal('show');
            }
        }
    });
}

function openAddRoleWindow(){
    $('#add-role-window input').val('')
    removeValidation($('#roleName'), $('#roleNameVal'));
    $('#add-role-window').modal('show');
}

function deleteRole(roleId){
    var data = new FormData();
    data.append('roleId', roleId);
    $.ajax({
        type: 'POST',
        url: './controls/admin/delete_role.php',
        data: data,
        async: false,
        contentType: false,
        processData: false,
        success: function(response){
            alert(response);    
            $('#view-role-window').modal('hide');
            loadRoles();
        },
        error: function(){
            alert('Something went wrong!');
        }
    });
}

function toggleEditMode(){
    var e = $('.edit');
    if(e.hasClass('editmode-on')){
        disableEditing(e);
    }
    else{
        enableEditing(e);
    }
}

function disableEditing(e){
    e.removeClass('editmode-on').addClass('edit-off');
    e.prop('title', 'Turn on edit mode');
    $('#view-role-window input[type="checkbox"]').prop('disabled', true);
    $('.icon').removeClass('fa-ban').addClass('fa-pencil-alt');
    $('.role-view-controls').hide();
}

function enableEditing(e){
    e.addClass('editmode-on').removeClass('edit-off');
    e.prop('title', 'Turn off edit mode');
    $('#view-role-window input[type="checkbox"]').prop('disabled', false);
    $('.icon').addClass('fa-ban').removeClass('fa-pencil-alt');
    $('.role-view-controls').show();
}

function saveRole(roleId){
    //var i = roles.findIndex(t => t.roleId == roleId);
    var prev = {
        "roleId": roleId,
        "functions": {
            "systemData": {
                'funcName': 'systemData',
                's1': 'personalDetails',
                's2': 'propertyManagement',
                's3': 'workPlan',
                's4': 'aidInfo',
                "personalDetails": new Array(),
                "propertyManagement": new Array(),
                "workPlan": new Array(),
                "aidInfo": new Array()
            },
            "certificates": {
                'funcName': 'certificates',
                's1': 'charCert',
                's2': 'deathCert',
                's3': 'residCert',
                "charCert": new Array(),
                "deathCert": new Array(),
                "residCert": new Array()
            },
            "userManagement": {
                'funcName': 'userManagement',
                's1': 'users',
                's2': 'userRoles',
                's3': 'myProfile',
                "users": new Array(),
                "userRoles": new Array(),
                "myProfile": new Array()
            },
            "disasterRecoveryNode": {
                'funcName': 'disasterRecoveryNode',
                's1': 'disasterRecovery',
                "disasterRecovery": new Array()
            }
        }
    };

    prev.functions.systemData.personalDetails = [
        get($('#perDet-C')), get($('#perDet-V')), get($('#perDet-M')), get($('#perDet-D'))
    ];
    prev.functions.systemData.propertyManagement = [
        get($('#propMng-C')), get($('#propMng-V')), get($('#propMng-M')), get($('#propMng-D'))
    ];
    prev.functions.systemData.workPlan = [
        get($('#wrkPln-C')), get($('#wrkPln-V')), get($('#wrkPln-M')), get($('#wrkPln-D'))
    ];
    prev.functions.systemData.aidInfo = [
        get($('#aidDet-C')), get($('#aidDet-V')), get($('#aidDet-M')), get($('#aidDet-D'))
    ];

    prev.functions.certificates.charCert = [
        get($('#charCert-C')), get($('#charCert-V')), get($('#charCert-M')), get($('#charCert-D'))
    ];
    prev.functions.certificates.deathCert = [
        get($('#deathCert-C')), get($('#deathCert-V')), get($('#deathCert-M')), get($('#deathCert-D'))
    ];
    prev.functions.certificates.residCert = [
        get($('#resCert-C')), get($('#resCert-V')), get($('#resCert-M')), get($('#resCert-D'))
    ];

    prev.functions.userManagement.users = [
        get($('#user-C')), get($('#user-V')), get($('#user-M')), get($('#user-D'))
    ];
    prev.functions.userManagement.userRoles = [
        get($('#uRole-C')), get($('#uRole-V')), get($('#uRole-M')), get($('#uRole-D'))
    ];
    prev.functions.userManagement.myProfile = [
        get($('#myProf-C')), get($('#myProf-V')), get($('#myProf-M')), get($('#myProf-D'))
    ];

    prev.functions.disasterRecoveryNode.disasterRecovery = [
        get($('#disast-C')), get($('#disast-V')), get($('#disast-M')), get($('#disast-D'))
    ];

    var data = new FormData();
    data.append('privilage', JSON.stringify(prev));
    $.ajax({
        type: 'POST',
        url: './controls/admin/update_privilages.php',
        data: data,
        async: false,
        contentType: false,
        processData: false,
        success: function(response){
            alert(response);    
            $('#view-role-window').modal('hide');
        },
        error: function(){
            alert('Something went wrong!');
        }
    });
}

function setRole(prev){
    //var i = roles.findIndex(t => t.roleId == roleId);
    var sysData = prev.functions.systemData;
    set($('#perDet-C'), sysData.personalDetails[0]);
    set($('#perDet-V'), sysData.personalDetails[1]);
    set($('#perDet-M'), sysData.personalDetails[2]);
    set($('#perDet-D'), sysData.personalDetails[3]);

    set($('#propMng-C'), sysData.propertyManagement[0]);
    set($('#propMng-V'), sysData.propertyManagement[1]);
    set($('#propMng-M'), sysData.propertyManagement[2]);
    set($('#propMng-D'), sysData.propertyManagement[3]);

    set($('#wrkPln-C'), sysData.workPlan[0]);
    set($('#wrkPln-V'), sysData.workPlan[1]);
    set($('#wrkPln-M'), sysData.workPlan[2]);
    set($('#wrkPln-D'), sysData.workPlan[3]);

    set($('#aidDet-C'), sysData.aidInfo[0]);
    set($('#aidDet-V'), sysData.aidInfo[1]);
    set($('#aidDet-M'), sysData.aidInfo[2]);
    set($('#aidDet-D'), sysData.aidInfo[3]);

    var cert = prev.functions.certificates;
    set($('#charCert-C'), cert.charCert[0]);
    set($('#charCert-V'), cert.charCert[1]);
    set($('#charCert-M'), cert.charCert[2]);
    set($('#charCert-D'), cert.charCert[3]);

    set($('#deathCert-C'), cert.deathCert[0]);
    set($('#deathCert-V'), cert.deathCert[1]);
    set($('#deathCert-M'), cert.deathCert[2]);
    set($('#deathCert-D'), cert.deathCert[3]);

    set($('#resCert-C'), cert.residCert[0]);
    set($('#resCert-V'), cert.residCert[1]);
    set($('#resCert-M'), cert.residCert[2]);
    set($('#resCert-D'), cert.residCert[3]);

    var umng = prev.functions.userManagement;
    set($('#user-C'), umng.users[0]);
    set($('#user-V'), umng.users[1]);
    set($('#user-M'), umng.users[2]);
    set($('#user-D'), umng.users[3]);

    set($('#uRole-C'), umng.userRoles[0]);
    set($('#uRole-V'), umng.userRoles[1]);
    set($('#uRole-M'), umng.userRoles[2]);
    set($('#uRole-D'), umng.userRoles[3]);

    set($('#myProf-C'), umng.myProfile[0]);
    set($('#myProf-V'), umng.myProfile[1]);
    set($('#myProf-M'), umng.myProfile[2]);
    set($('#myProf-D'), umng.myProfile[3]);

    var dis = prev.functions.disasterRecoveryNode;
    set($('#disast-C'), dis.disasterRecovery[0]);
    set($('#disast-V'), dis.disasterRecovery[1]);
    set($('#disast-M'), dis.disasterRecovery[2]);
    set($('#disast-D'), dis.disasterRecovery[3]);
}

function get(c){
    return c.prop('checked');
}

function set(e, v){
    e.prop('checked', v);
}