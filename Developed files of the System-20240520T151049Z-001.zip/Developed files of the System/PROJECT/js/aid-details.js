var onEdit = false;

$(document).ready(() => {
    loadPageContent();

    $('#add-aid').click(() => { openAidWindow(); } )

    $('#submit').click(() => { submit(); })

    /* Validation events */

    $('#pName').on('change keyup', () => { validateName(); } )

    $('#accNo').on('change keyup', () => { validateAccNo(); } )

    $('#amount').on('change keyup', () => { validateAmount(); } )
    $('#amount').change(() => { setFormat(); })

    $('#place').on('change keyup', () => { validatePlace(); } )

    $('#date').on('change keyup', () => { validateDate(); } )

    $('#other').on('change keyup', () => { validateOther(); } )
});

function openAidWindow(){
    onEdit = false;
    clearAll();
    var win = $('#add-aid-window');
    var houseNo = $('#houseNo');
    var aidType = $('#aidType');
    win.modal('show');
}

function loadPageContent(){
    var x = loadSampleData();
    var t = $('.aid-table');
    t.empty();
    $.each(x, i => { 

        var d = x[i].Date.toString().replace(" 00:00:00", '');

        var row =
        `<tr>
            <td>
                <button class="btn btn-sm btn-danger" title="Delete" onclick="deleteAid(${x[i].Id})">
                    <i class="fa fa-trash"></i>
                </button>
                <button class="btn btn-sm btn-primary" title="Edit" onclick="editAid(${x[i].Id})">
                <i class="fa fa-pencil-alt"></i>
                </button>
            </td>
            <td>${x[i].HouseNo}</td>
            <td>${x[i].PersonName}</td>
            <td>${x[i].AidType}</td>
            <td>${x[i].AccNo}</td>
            <td class="text-primary">${parseFloat(x[i].Amount).toFixed(2)}</td>
            <td>${d}</td>
            <td>${x[i].Place}</td>
            <td>${x[i].Other}</td>
        </tr>`;
        t.append(row);
    });
}

var editId = -1;
function submit(){
    if(onEdit){
        if(isValidate()){
            var form = document.getElementById("aid-form");
            var data = new FormData(form);
            data.set('aidType', $('#aidType').val());
            data.append('Id', editId);
            
            $.ajax({
                type: 'post',
                url: './controls/admin/update_aidsData.php',
                processData: false,
                contentType: false,
                data: data,
                success: function(r){
                    system_alert(r);
                },
                error: function(){
                    system_alert("Something went wrong!");
                }
            });
            
            clearAll();
            $('#add-aid-window').modal('hide');
        }
        else{
            $('.in-err').filter(':first').focus();
        }
    }
    else{
        if(isValidate()){
            var form = document.getElementById("aid-form");
            var data = new FormData(form);
            data.set('aidType', $('#aidType').val());
            
            $.ajax({
                type: 'post',
                url: './controls/admin/save_aids.php',
                processData: false,
                contentType: false,
                data: data,
                success: function(r){
                    system_alert(r);
                },
                error: function(){
                    system_alert("Something went wrong!");
                }
            });
            
            clearAll();
            $('#add-aid-window').modal('hide');
        }
        else{
            $('.in-err').filter(':first').focus();
        }
    }
}

function loadSampleData(){
    var x;
    
    $.ajax({
        type: 'post',
        url: './controls/admin/get_special_aids.php',
        processData: false,
        contentType: false,
        async: false,
        success: function(r){
            x = JSON.parse(r);
        },
        error: function(){
            system_alert("Something went wrong!");
        }
    });
    return x;
}

function deleteAid(id){
    var x = new FormData();
    x.append("id", id);
    
    $.ajax({
        type: 'post',
        url: './controls/admin/delete_special_aids.php',
        processData: false,
        contentType: false,
        data: x,
        success: function(r){
            system_alert(r);
        },
        error: function(){
            system_alert("Something went wrong!");
        }
    });
}

function editAid(id){
    onEdit = true;
    clearAll();
    var win = $('#add-aid-window');

    var data = new FormData();
    data.append('Id', id);
    var aidEditData;
    editId = id;
    
    $.ajax({
        type: 'post',
        url: './controls/admin/get_aidsData.php',
        processData: false,
        contentType: false,
        data: data,
        async: false,
        success: function(r){
            aidEditData = JSON.parse(r);
        },
        error: function(){
            system_alert("Something went wrong!");
        },
        complete: function(){
            var houseNo = $('#houseNo');
            var aidType = $('#aidType');

            $('#hName').val(aidEditData.HouseNo);
            $('#pName').val(aidEditData.PersonName);
            $('#aidType').val(aidEditData.AidType);
            $('#accNo').val(aidEditData.AccNo);
            $('#amount').val(aidEditData.Amount);
            $('#place').val(aidEditData.Place);
            $('#date').val(aidEditData.Date.replace(' 00:00:00', ''));
            $('#other').val(aidEditData.Other);

            win.modal('show');
        }
    });
}

/* Validation heplers */

function addValidation(valIn, validationIndicator, message){
    validationIndicator.html(message);
    valIn.addClass('in-err');
}

function removeValidation(valIn, validationIndicator){
    validationIndicator.html('');
    valIn.removeClass('in-err');
}

function isValidate(){
    return validateName() & validateAccNo() & validateAmount() & validatePlace() &
    validateDate() & validateOther();
}

function clearAll(){
    $('input[type="text"]').val('');
    $('input[type="number"]').val(parseFloat(0).toFixed(2));
    $('textarea').val('');
    $('input[type="date"]').val('');
    $('.val').html('');
}

/* Validations */

function validateName(){
    if($('#pName').val() == ''){
        addValidation($('#pName'), $('#pNameVal'), 'Person name is required');
        $('#pName').focus();
        return false;
    }
    removeValidation($('#pName'), $('#pNameVal'));
    return true;
}

function validateAccNo(){
    if($('#accNo').val() == ''){
        addValidation($('#accNo'), $('#accNoVal'), 'Account number is required');
        $('#accNo').focus();
        return false;
    }
    removeValidation($('#accNo'), $('#accNoVal'));
    return true;
}

function validateAmount(){
    if($('#amount').val() == ''){
        addValidation($('#amount'), $('#amountVal'), 'Amount is required');
        $('#amount').focus();
        return false;
    }

    if($('#amount').val() < 0 || $('#amount').val() == 0){
        addValidation($('#amount'), $('#amountVal'), 'Invalid donation amount');
        $('#amount').focus();
        return false;
    }
    removeValidation($('#amount'), $('#amountVal'));
    return true;
}

function setFormat(){
    var x = $('#amount');
    if(x.val() != null){
        x.val(parseFloat(x.val()).toFixed(2));
    }
}

function validatePlace(){
    if($('#place').val() == ''){
        addValidation($('#place'), $('#placeVal'), 'Obtained place is required');
        $('#place').focus();
        return false;
    }
    removeValidation($('#place'), $('#placeVal'));
    return true;
}

function validateDate(){
    if($('#date').val() == ''){
        addValidation($('#date'), $('#dateVal'), 'Date is required');
        $('#date').focus();
        return false;
    }
    removeValidation($('#date'), $('#dateVal'));
    return true;
}

function validateOther(){
    if($('#other').val() == ''){
        addValidation($('#other'), $('#otherVal'), 'Other details is required');
        $('#other').focus();
        return false;
    }
    removeValidation($('#other'), $('#otherVal'));
    return true;
}