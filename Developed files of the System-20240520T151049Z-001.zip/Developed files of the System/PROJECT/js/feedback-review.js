$(document).ready(() => {
    loadChartData();
    loadData();
})

function loadData(){
    var data;

    $.ajax({
        type: 'POST',
        url: './controls/admin/loadFeedbackData.php',
        contentType: false,
        success: function(r){
            data = JSON.parse(r);
        },
        error: function(){
            system_alert('Somthing went wrong!');
        },
        complete: function(){
            fillData(data);
        }
    });
}

function loadChartData(){
    var data;

    $.ajax({
        type: 'POST',
        url: './controls/admin/loadFeedbackRatings.php',
        contentType: false,
        async: false,
        success: function(r){
            data = JSON.parse(r);
        },
        error: function(){
            system_alert('Somthing went wrong!');
        },
        complete: function(){
            for(i = 1; i <= 5; i++){
                var k = data.findIndex(r => r.rateIndex == i);
                if(k < 0) {
                    data.push({ "rateIndex": i, "count": 0 });
                }
            }

            data.sort((b, a) => { 
                return a.rateIndex < b.rateIndex ? -1 :
                a.rateIndex > b.rateIndex ? 1 : 0
            });

            var wf = 0;
            var f = 0;
            $.each(data, i => {
                wf += data[i].rateIndex * data[i].count;
                f += data[i].count;
            })

            drawRatingsChart(data.map(x => x.count), (wf / f).toFixed(1));
        }
    });
}

function fillData(c){
    var list = $('.feed-container');
    list.empty();

    $.each(c, i => {
        var row = 
        `<div class="feedback">
            <div class="name">${c[i].sender} <span class="date"> - ${c[i].date}</span></div>
            <div class="type ${c[i].type.toLowerCase()}">${c[i].type}</div>
            <div class="msg">${c[i].comment}</div>
        </div>`;

        list.append(row);
    });
}

function drawRatingsChart(chartData, average){
    average = isNaN(average) ? 0 : average;
    debugger;
    $('.count').html(average);
    setMood(average);

    var canvas = $('#rates');
    var ratingData = chartData;
    var colors = [
        'rgb(40 167 69 / 0.7)',
        'rgb(95 167 40 / 70%)',
        'rgb(191 193 44 / 70%)',
        'rgb(193 106 44 / 70%)',
        'rgb(193 44 44 / 70%)'
    ];

    var settings = {
        type: 'bar',
        data: {
            labels: ['5', '4', '3', '2', '1'],
            datasets: [
                {
                    label: 'Ratings',
                    data: ratingData,
                    backgroundColor: colors
                }
            ]
        },
        options: {
            scales: {
                y: { beginAtZero: true, grid:{display: false} },
                x: { beginAtZero: true, grid:{display: false} },
            },
            indexAxis: 'y'

        }
    };
    new Chart(canvas, settings);
}

function setMood(n){
    var i = $('.average i');
    n = Math.round(n);
    switch(n){
        case 1: i.removeClass().addClass('fa fa-angry angry'); break;
        case 2: i.removeClass().addClass('fa fa-frown-open neutral'); break;
        case 3: i.removeClass().addClass('fa fa-meh neutral'); break;
        case 4: i.removeClass().addClass('fa fa-smile neutral'); break;
        case 5: i.removeClass().addClass('fa fa-grin neutral'); break;
    }
}