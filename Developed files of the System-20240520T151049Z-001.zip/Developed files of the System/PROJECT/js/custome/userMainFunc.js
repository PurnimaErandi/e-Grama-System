var currentPath = "./content/userDashboard.php";

jQuery(function ($) {

    $(".sidebar-dropdown > a").click(function () {
        $(".sidebar-submenu").slideUp(200);
        if (
                $(this)
                .parent()
                .hasClass("active")
                ) {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
                    .parent()
                    .removeClass("active");
        } else {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
                    .next(".sidebar-submenu")
                    .slideDown(200);
            $(this)
                    .parent()
                    .addClass("active");
        }
    });

    $("#close-sidebar").click(function () {
        $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function () {
        $(".page-wrapper").addClass("toggled");
    });
});


$(document).ready(function () {

    $("#userdashboardBtn").click(function () {
        changePath('./content/user/userDashboard.php');
    });
    $("#characCertfcte").click(function () {
        changePath('./content/user/certificate-request-user.php');
    });
    $("#deathCertfcte").click(function () {
        changePath('./content/user/cert-req-user-death.php');
    });
    $("#residenceCertfcte").click(function () {
        changePath('./content/user/cert-req-user-residence.php');
    });
    $("#feedbackText").click(function () {
        changePath('./content/user/feedbackForm.php');
    });
    $("#obtainID").click(function () {
        changePath('./content/user/obtainID.php');
    });
    $("#obtainMarriage").click(function () {
        changePath('./content/user/obtainMarriage.php');
    });
    $("#ObtainIDCopies").click(function () {
        changePath('./content/user/ObtainIDCopies.php');
    });
    $("#obtainBirth").click(function () {
        changePath('./content/user/obtainBirth.php');
    });
    $("#regMarriages").click(function () {
        changePath('./content/user/regMarriages.php');
    });
    $("#obtainHouse").click(function () {
        changePath('./content/user/obtainHouse.php');
    });
    $("#obtainTransport").click(function () {
        changePath('./content/user/obtainTransport.php');
    });
    $("#passwordChange").click(function () {
        changePath('./content/user/passwordChange.php');
    });
    $("#contactBtn").click(function () {
        changePath('./content/user/contactUs.php');
    });
    $("#regOrganizationBtn").click(function () {
        changePath('./content/user/regOrganization.php');
    });
    $("#covidInfoBtn").click(function () {
        changePath('./content/user/covidInfo.php');
    });
    $("#viewChildBtn").click(function () {
        changePath('./content/user/viewChildren.php');
    });
 
    //logout
    $("#logout").click(function () {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                location.reload();
            }
        };
        xhttp.open("GET", "./controls/logout.php", true);
        xhttp.send();
    });
});

function onLoad() {
    $("#loadingPoint").css("display", "block");
}
function outLoad() {
    $("#loadingPoint").css("display", "none");
}

function endLoad() {
    setTimeout(outLoad, 1000);
}
function loadPage() {
    onLoad();
    $("#content").load(currentPath);
    endLoad();
}
function changePath(path) {
    currentPath = path;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            //location.reload();
            loadPage();
        }
    };
    xhttp.open("GET", "./controls/changePath.php?path=" + path, true);
    xhttp.send();
    
};







