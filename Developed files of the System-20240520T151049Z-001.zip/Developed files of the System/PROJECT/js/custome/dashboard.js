$(document).ready(function() {
    $('#visitUser').DataTable();
} );
function viewUser(){
    $('#farmerBio').css('display','block');
}
function farmerVisit(){
    $('#farmerVisit').css('display','block');
}
