function system_alert(text){
    $('#alertMsg').html(text);
    $('#alertPoint').css('display', 'block');
}
function closeAnimation(){
    $('#alert').removeClass('zoomOutDown');
    $('#alertPoint').css('display', 'none');
}
$(document).ready(function(){
    $("#alertClose").click(function(){
        $('#alert').addClass('zoomOutDown');
        setTimeout(closeAnimation,1000);
    });
    $("#alertCloseTop").click(function(){
        $('#alert').addClass('zoomOutDown');
        setTimeout(closeAnimation,1000);
    });
});

function closeAny(idly,iddiv){
    $('#' + iddiv).removeClass('zoomOutDown');
    $('#' + idly).css('display', 'none');
}