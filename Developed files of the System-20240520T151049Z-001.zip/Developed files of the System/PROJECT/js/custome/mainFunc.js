var currentPath = "./content/admin/dashboard.php";

jQuery(function ($) {

    $(".sidebar-dropdown > a").click(function () {
        $(".sidebar-submenu").slideUp(200);
        if (
                $(this)
                .parent()
                .hasClass("active")
                ) {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
                    .parent()
                    .removeClass("active");
        } else {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
                    .next(".sidebar-submenu")
                    .slideDown(200);
            $(this)
                    .parent()
                    .addClass("active");
        }
    });

    $("#close-sidebar").click(function () {
        $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function () {
        $(".page-wrapper").addClass("toggled");
    });
});


$(document).ready(function () {

    $("#dashboardBtn").click(function () {
        changePath('./content/admin/dashboard.php');
    });
    $("#workHistory").click(function () {
        changePath('./content/admin/workHistory.php');
    });
    $("#householderDetails").click(function () {
        changePath('./content/admin/householderDetails.php');
    });
    $("#personalDetails").click(function () {
       changePath('./content/admin/personalDetails.php');
    });
    $("#workPlans").click(function () {
        changePath('./content/admin/workPlans.php');
    });
    $("#deathCertificate").click(function () {
        changePath('./content/admin/dethCertificate.php');
    });
    $("#characCertificate").click(function () {
        changePath('./content/admin/characCertificate.php');
    });
    $("#residenceCertificate").click(function () {
        changePath('./content/admin/residenceCertificate.php');
    });
    $("#pDetails").click(function () {
        changePath('./content/admin/pDetails.php');
    });
    $("#workhisView").click(function () {
        changePath('./content/admin/workhisView.php');
    });
    $("#propdtlsView").click(function () {
        changePath('./content/admin/propdtlsView.php');
    });
    $("#wPlan").click(function () {
        changePath('./content/admin/wPlans.php');
    });
    $("#propManagementnew").click(function () {
        changePath('./content/admin/propManagementnew.php');
    });
    $("#publicassist").click(function () {
        changePath('./content/admin/publicassist.php');
    });
    $("#aidsdetails").click(function () {
        changePath('./content/admin/aidsdetails.php');
    });
    $("#propdtlsView").click(function () {
        changePath('./content/admin/propdtlsView.php');
    });
    $("#myProfile").click(function () {
        changePath('./content/admin/myProfle.php');
    });
    $("#userRoles").click(function () {
        changePath('./content/admin/userRoles.php');
    });
     $("#users").click(function () {
        changePath('./content/admin/users.php');
    });
    $("#voteRegistryBtn").click(function () {
        changePath('./content/admin/voteRegistry.php');
    });
    $("#accountRequest").click(function () {
        changePath('./content/admin/accountRequestAdmin.php');
    });
    $("#certificateRequest").click(function () {
        changePath('./content/admin/certificate-request-admin.php');
    });
    $("#dstrRcvrBtn").click(function () {
        changePath('./content/admin/disasterRecovery.php');
    });
    $("#revFeedbackBtn").click(function () {
        changePath('./content/admin/reviewFeedback.php');
    });
    $("#eventBtn").click(function () {
        changePath('./content/admin/eventPlanner.php');
    });
    $("#sampathpethikadaBtn").click(function () {
        changePath('./content/admin/sampathPethikada.php');
    });

    
    //logout
    $("#logout").click(function () {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                location.reload();
            }
        };
        xhttp.open("GET", "./controls/logout.php", true);
        xhttp.send();
    });
});

function onLoad() {
    $("#loadingPoint").css("display", "block");
}
function outLoad() {
    $("#loadingPoint").css("display", "none");
}

function endLoad() {
    setTimeout(outLoad, 1000);
}
function loadPage() {
    onLoad();
    $("#content").load(currentPath);
    endLoad();
}
function changePath(path) {
    currentPath = path;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            loadPage();
        }
    };
    xhttp.open("GET", "./controls/changePath.php?path=" + path, true);
    xhttp.send();
};





