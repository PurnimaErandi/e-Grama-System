<?php
$host = "localhost";
$user_name = "root";
$password="";
$DB_name="project";
$port="3306";

$connection= mysqli_connect($host,$user_name,$password,$DB_name,$port);

if($connection->connect_error)
{
	echo"error";
	die();
}


