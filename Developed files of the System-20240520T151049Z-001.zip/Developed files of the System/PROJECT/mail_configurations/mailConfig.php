<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '..\..\mail_service\PHPMailer.php';
require '..\..\mail_service\SMTP.php';
require '..\..\mail_service\Exception.php';

function sendEmail($to, $name, $mail, $subject){
    $email = new PHPMailer();
    $appMail = "myemail.com";

    $email->isSMTP();
    $email->Host = "smtp.gmail.com";
    $email->Mailer = "smtp";
    $email->SMTPAuth = true;
    $email->Username = $appMail;
    $email->Password = 'myPassword';
    $email->Port = 587;
    $email->SMTPSecure = "tls";

    $email->isHTML(true);
    $email->setFrom($appMail);
    $email->addAddress($to, $name);
    $email->Subject = $subject;
    $email->msgHTML($mail);

    try{
        $email->send();
        return '<div style="color:green">Mail Sent!</div>';
    }
    catch(Exception $e){
        echo '<div style="color:red'.$e->errorMessage().'!</div>';
    }

}
