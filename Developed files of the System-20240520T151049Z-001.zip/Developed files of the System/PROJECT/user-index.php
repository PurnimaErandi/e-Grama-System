<?php
session_start();
if (isset($_SESSION['LogId'])) {
    if ($_SESSION['LogId'] == '') {
        header("Location:./login/user-login.php");
    } else {
        $adminId = $_SESSION['LogId'];
        $adminName = $_SESSION['fullName'];
    }
} else {
    header("Location:./login/user-login.php");
}

if (isset($_SESSION['adminCurrentPagePath'])) {
    $currentPath = $_SESSION['adminCurrentPagePath'];
} else {
    $currentPath = "./content/user/userDashboard.php";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/custome/popper.min.js"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <link rel="stylesheet" href="css/bootstrap-select.min.css">
        <script src="js/bootstrap-select.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/custome/style.css" rel="stylesheet">
        <link href="css/custome/animation.css" rel="stylesheet">
        <script src="js/custome/usermainFunc.js"></script>
        <script src="js/custome/alert.js"></script>

        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>


        <title>Dashboard</title>

    </head>
    <body>
        <div class="overlay" id="loadingPoint">
            <img id="loaderImg" src="img/loading.gif">
        </div>
        <div class="overlayMsg" id="alertPoint">
            <div id="alert" class="zoomInDown">
                <a class="btn btn-danger" id="alertCloseTop" style="float: right;"><i class="fa fa-times"></i></a>

                <div style="margin-top: 20px;padding: 20px;">
                    <centre>
                        <p id="alertMsg">
                        </p>
                    </centre>
                    <centre id="customizedBtn">
                        <a class="btn btn-primary" id="alertClose" >Ok</a>
                    </centre>
                </div>
            </div>
        </div>
        <div class="page-wrapper chiller-theme toggled">
            <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
                <i class="fas fa-bars"></i>
            </a>
            <nav id="sidebar" class="sidebar-wrapper"  style="background-color:#000033; width: 270px;">
                <div class="sidebar-content">
                    <div class="sidebar-brand">
                        <a href="#" id="headingName"  style="color:#ffffff;">Dashboard</a>
                        <div id="close-sidebar">
                            <i class="fas fa-times"></i>
                        </div>
                    </div>
                    <div class="sidebar-header" style="text-align: center;">
                        <div class="user-info">
                            <span class="user-name"  style="color:#ffffff;"> 
                                <strong><?php echo $adminName; ?></strong>
                            </span>
                            <span class="user-role"  style="color:#ffffff;">User</span>
                            <span class="user-status">
                                    <i class="fa fa-circle"></i>
                                    <span>Online</span>
                            </span>
                        </div>
                    </div>
                
                    <div class="sidebar-menu">
                        <ul>
                            <li class="header-menu">
                                <span id="menuText"  style="color:#ffffff;"><b>Menu</b></span>
                            </li>
                            <li>
                                <a href="#" id="userdashboardBtn">
                                    <i class="fas fa-tachometer-alt" style="background-color:#000000;"></i>
                                    <span id="homeText"  style="color:#ffffff;"><b>Dashboard</b></span>
                                </a>

                            </li>
                            
                            <li class="sidebar-dropdown">
                                   <a href="#">
                                        <i class="fa fa-certificate" style="background-color:#000000;"></i>
                                        <span id="downloadsText"  style="color:#ffffff;"><b>Request Certificate</b></span>        
                                    </a>
                                    <div class="sidebar-submenu"  style="background-color:#0d0d0d;">
                                        <ul>
                                            <li>
                                                <a href="#" id="characCertfcte"  style="color:#ffffff;">Character Certificate</a>
                                            </li>
                                            <li>
                                                <a href="#" id="deathCertfcte"  style="color:#ffffff;">Death Certificate</a>
                                            </li>   
                                            <li>
                                                <a href="#" id="residenceCertfcte"  style="color:#ffffff;">Certificate of Residence</a>
                                            </li>
                                        </ul>
                                    </div>
                                
                            </li>

                            <li class="sidebar-dropdown">
                                   <a href="#">
                                        <i class="fas fa-file-alt" style="background-color:#000000;"></i>
                                        <span id="downloadsText"  style="color:#ffffff;"><b>Prerequisites</b></span>        
                                    </a>
                                    <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                        <ul>
                                            <li>
                                                <a href="#" id="obtainID"  style="color:#ffffff;">Obtaining a New ID</a>
                                            </li>
                                            <li>
                                                <a href="#" id="ObtainIDCopies"  style="color:#ffffff;">Obtaining Duplicate ID Copies</a>
                                            </li>
                                            <li>
                                                <a href="#" id="obtainBirth"  style="color:#ffffff;">Obtain a Copy of Birth Certificate</a>
                                            </li>
                                            <li>
                                                <a href="#" id="regMarriages"  style="color:#ffffff;">Registration of Marriages (General)</a>
                                            </li>
                                            <li>
                                                <a href="#" id="obtainMarriage"  style="color:#ffffff;">Obtain a Copy of Marriage Certificate</a>
                                            </li>   
                                            <li>
                                                <a href="#" id="obtainHouse"  style="color:#ffffff;">Obtaining Housing Relief in Disaster</a>
                                            </li>
                                            <li>
                                                <a href="#" id="obtainTransport"  style="color:#ffffff;">Obtaining Transport Permits for Sand Clay, Gravel</a>
                                            </li>
                                        </ul>
                                    </div>
                                
                            </li>
                            <li>
                                <a href="#"  id="regOrganizationBtn">
                                    <i class="fas fa-clipboard-list"  style="background-color:#000000;"></i>
                                    <span id="regOrganizationText" style="color:#ffffff;"><b>Registered Organizations</b></span>
                                </a>
                            </li>
                            <li>
                                <a href="#"  id="covidInfoBtn">
                                    <i class="fas fa-virus"  style="background-color:#000000;"></i>
                                    <span id="covidInfoText" style="color:#ffffff;"><b>Covid19 Information</b></span>
                                </a>
                            </li>
                            <li>
                                <a href="#"  id="feedbackBtn">
                                    <i class="fas fa-comment-alt"  style="background-color:#000000;"></i>
                                    <span id="feedbackText" style="color:#ffffff;"><b>Feedback</b></span>
                                </a>
                            </li>

                            <li>
                                <a href="#"  id="contactBtn">
                                    <i class="fas fa-phone-alt"  style="background-color:#000000;"></i>
                                    <span id="contactText" style="color:#ffffff;"><b>Contact Us</b></span>
                                </a>
                            </li>

                            <li>
                                <a href="#"  id="viewChildBtn">
                                    <i class="fas fa-child"  style="background-color:#000000;"></i>
                                    <span id="viewChildtText" style="color:#ffffff;"><b>View Children</b></span>
                                </a>
                            </li>

                            <li class="sidebar-dropdown">
                                   <a href="#">
                                        <i class="fas fa-cog" style="background-color:#000000;"></i>
                                        <span id="downloadsText"  style="color:#ffffff;"><b>Account Settings</b></span>        
                                    </a>
                                    <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                        <ul>
                                            <li>
                                                <a href="#" id="passwordChange"  style="color:#ffffff;">Password Change</a>
                                            </li>
                                        </ul>
                                    </div>
                            </li>
                        </ul>
                    </div>
                    <!-- sidebar-menu  -->
                </div>
                <!-- sidebar-content  -->
                <div class="sidebar-footer">
                   
                    <a href="#" id="logout">
                        <i class="fa fa-power-off" style="color:#000000;"></i>
                    </a>
                </div>
            </nav>

            <!-- sidebar-wrapper  -->
            <main class="page-content">
                <div class="container-fluid" id="content">

                </div>

            </main>
            
            <!-- page-content" -->
        </div>

        <script>
            var currentPath = "<?php echo $currentPath; ?>";
            loadPage();
        </script>
    </body>
</html>
