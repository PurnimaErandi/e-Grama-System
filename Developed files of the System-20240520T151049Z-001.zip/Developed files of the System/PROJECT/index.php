<?php
session_start();
if (isset($_SESSION['LogId'])) {
    if ($_SESSION['LogId'] == '') {
        header("Location:./login/login.php");
    } else {
        $adminId = $_SESSION['LogId'];
        $adminName = $_SESSION['fullName'];
        $adminImg = $_SESSION['profileImage'];
        
        $adminImg = str_replace("/..", "", $adminImg);
    }
} else {
    header("Location:./login/login.php");
}

if (isset($_SESSION['adminCurrentPagePath'])) {
    $currentPath = $_SESSION['adminCurrentPagePath'];
} else {
    $currentPath = "./content/admin/dashboard.php";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/custome/popper.min.js"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="css/bootstrap-select.min.css">
        <script src="js/bootstrap-select.min.js"></script>
        <link href="css/custome/style.css" rel="stylesheet">
        <link href="css/custome/animation.css" rel="stylesheet">
        <script src="js/custome/mainFunc.js"></script>
        <script src="js/custome/alert.js"></script>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script>
        

        <link href="css/select2.min.css" rel="stylesheet" />
        <script src="js/select2.min.js"></script>


        <title>Dashboard</title>

    </head>
    <body>
        <div class="overlay" id="loadingPoint">
            <img id="loaderImg" src="img/loading.gif">
        </div>
        <div class="overlayMsg" id="alertPoint">
            <div id="alert" class="zoomInDown">
                <a class="btn btn-danger" id="alertCloseTop" style="float: right;"><i class="fa fa-times"></i></a>

                <div style="margin-top: 20px;padding: 20px;">
                    <centrer>
                        <p id="alertMsg">
                        </p>
                    </centre>
                    <centrer id="customizedBtn">
                        <a class="btn btn-primary" id="alertClose" >Ok</a>
                    </centre>
                </div>
            </div>
        </div>
        <div class="page-wrapper chiller-theme toggled">
            <a id="show-sidebar" class="btn btn-sm btn-dark" href="#" style="background-color:#030303;" >
                <i class="fas fa-bars"></i>
            </a>
            <nav id="sidebar" class="sidebar-wrapper" style="background-color:#0d0d0d;">
                <div class="sidebar-content">
                    <div class="sidebar-brand">
                        <a href="#" id="headingName" style="color:#e6b800;">Dashboard</a>
                        <div id="close-sidebar">
                            <i class="fas fa-times"></i>
                        </div>
                    </div>
                    <div class="sidebar-header" >
                        <div class="user-pic">
                            <img class="img-responsive img-rounded" src="<?php echo $adminImg; ?>"
                                 alt="User Image">
                        </div>
                        
                        <div class="user-info">
                            <span class="user-name" style="color:#ffffff;"> 
                                <strong><?php echo $adminName; ?></strong>
                            </span>  
                            
                            <span class="user-role" style="color:#ffffff;">Administrator</span>
                            <span class="user-status">
                                <i class="fa fa-circle"></i>
                                <span>Online</span>
                            </span>
                            
                        </div>
                    </div>
                
                    <div class="sidebar-menu">
                        <ul>
                            <li class="header-menu">
                                <span id="menuText" style="color:#e6b800;">Menu</span>
                            </li>
                            <li>
                                <a href="#" id="dashboardBtn" style="color:#000000;">
                                    <i class="fa fa-tachometer-alt"  style="background-color:#e6b800;"></i>
                                    <span id="homeText" style="color:#ffffff;">Dashboard</span>
                                </a>
                            </li>
                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="fa fa-address-book" style="background-color:#e6b800; color:#000000;"></i>
                                    <span id="dataEntryText" style="color:#ffffff;">Data Entry</span>
                                </a>
                                <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                    <ul>
                                        <li>
                                            <a href="#" id="personalDetails" style="color:#ffffff;">Persons Registration</a>
                                        </li>
                                        <li>
                                            <a href="#" id="propManagementnew" style="color:#ffffff;">Property Registration</a>
                                        </li>
                                        <li>
                                            <a href="#" id="workPlans" style="color:#ffffff;">Work Plans</a>
                                        </li> 
                                        <li>
                                            <a href="#" id="workHistory" style="color:#ffffff;">Work History</a>
                                        </li> 
                                        <li>
                                            <a href="#" id="aidsdetails" style="color:#ffffff;">Aids & Other Details</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="sidebar-dropdown">
                                   <a href="#">
                                         <i class="fa fa-bars" style="background-color:#e6b800; color:#000000;"></i>
                                        <span id="dataViewText" style="color:#ffffff;">Data View</span>        
                                     </a>
                                    <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                        <ul>
                                            
                                            <li>
                                                <a href="#" id="pDetails" style="color:#ffffff;">Persons Registration </a>
                                            </li>
                                            
                                            <li>
                                                <a href="#" id="propdtlsView" style="color:#ffffff;">Property Registration </a>
                                            </li>
                                            
                                            <li>
                                                <a href="#" id="wPlan" style="color:#ffffff;">Work Plan Details</a>
                                            </li>
                                            <li>
                                                <a href="#" id="workhisView" style="color:#ffffff;">Work History</a>
                                            </li> 
                                        </ul>
                                    </div>
                            </li>

                            <li>
                                <a href="#"  id="voteRegistryBtn" style="color:#000000;">
                                    <i class="fas fa-list-alt" style="background-color:#e6b800;"></i>
                                    <span id="voteRegistryText" style="color:#ffffff;">Vote Registry</span>
                                </a>
                            </li>

                            <li>
                                <a href="#"  id="sampathpethikadaBtn" style="color:#000000;">
                                    <i class="fa fa-database" style="background-color:#e6b800;"></i>
                                    <span id="sampathpethikadaText" style="color:#ffffff;">Sampath Pethikada</span>
                                </a>
                            </li>
                            
                            <li>
                                <a href="#" id="dstrRcvrBtn" style="color:#000000;">
                                    <i class="fas fa-house-damage" style="background-color:#e6b800;"></i>
                                    <span id="dstrRcvrText" style="color:#ffffff;">Disaster Management</span> 
                                </a>
                            </li>
                            
                            <li class="sidebar-dropdown">
                                   <a href="#" >
                                        <i class="fa fa-certificate" style="background-color:#e6b800; color:#000000;"></i>
                                        <span id="certificateText" style="color:#ffffff;">Certificates</span>        
                                    </a>
                                    <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                        <ul>
                                            <li>
                                                <a href="#"" id="characCertificate" style="color:#ffffff;">Character Certificate</a>
                                            </li>
                                            <li>
                                                <a href="#"   id="deathCertificate" style="color:#ffffff;">Death Certificate</a>
                                            </li>   
                                            <li>
                                                <a href="#"  id="residenceCertificate" style="color:#ffffff;">Certificate of Residence</a>
                                            </li>
                                        </ul>
                                    </div>
                                
                            </li>
                            
                            <li class="sidebar-dropdown">
                                   <a href="#">
                                        <i class="fa fa-user-circle" style="background-color:#e6b800; color:#000000;"></i>
                                        <span id="userAccuntText" style="color:#ffffff;">Request Management</span>        
                                    </a>
                                    <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                        <ul>
                                            <li>
                                                <a href="#" id="accountRequest" style="color:#ffffff;">Account Requests</a>
                                            </li>
                                            <li>
                                                <a href="#" id="certificateRequest" style="color:#ffffff;">Certificate Requests</a>
                                            </li>
                                        </ul>
                                    </div>
                            </li>

                            <li>
                                <a href="#"  id="revFeedbackBtn" style="color:#000000;">
                                    <i class="fas fa-comment-alt" style="background-color:#e6b800;"></i>
                                    <span id="revFeedbackText" style="color:#ffffff;">Review Feedback</span>
                                </a>
                            </li>

                            <li>
                                <a href="#"  id="eventBtn" style="color:#000000;">
                                    <i class="far fa-calendar-minus" style="background-color:#e6b800;"></i>
                                    <span id="eventText" style="color:#ffffff;">Event Planner</span>
                                </a>
                            </li>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="fa fa-user" style="background-color:#e6b800; color:#000000;"></i>
                                    <span id="userText" style="color:#ffffff;">User Management</span>
                                </a>
                                <div class="sidebar-submenu" style="background-color:#0d0d0d;">
                                    <ul>
                                        <li>
                                            <a href="#" id="users" style="color:#ffffff;">Manage Users</a>
                                        </li>
                                        <!-- <li>
                                            <a href="#" id="userRoles" style="color:#ffffff;">User Roles</a>
                                        </li> -->
                                        <li>
                                            <a href="#" id="myProfile" style="color:#ffffff;">Edit My Profile</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                        </ul>
                    </div>
                    <!-- sidebar-menu  -->
                </div>
                <!-- sidebar-content  -->
                <div class="sidebar-footer"  style="background-color:#e6b800;">
                    <a href="#" style="color:#000000;" id="logout">
                        <i class="fa fa-power-off"></i>
                    </a>
                </div>
            </nav>
            <!-- sidebar-wrapper  -->
            <main class="page-content" style="background-color:#f2f2f2;">
                <div class="container-fluid" id="content">

                </div>

            </main>
            <!-- page-content" -->
        </div>

        <script>
            var currentPath = "<?php echo $currentPath; ?>";
            loadPage();
        </script>
    </body>
</html>
